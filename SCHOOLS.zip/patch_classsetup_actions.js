import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

const stateAdditions = `
  const [classForm, setClassForm] = useState<Partial<ClassData> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleSaveClass = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!classForm) return;
    
    const isEdit = classForm.id && classes.some(c => c.id === classForm.id);
    const method = isEdit ? 'PUT' : 'POST';
    const url = isEdit ? '/api/classes/' + classForm.id : '/api/classes';
    
    const payload = { ...classForm };
    if (!isEdit && !payload.id) {
       payload.id = 'CLS' + Math.floor(Math.random() * 10000);
       payload.totalStudents = 0;
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        fetchClasses();
        setClassForm(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const confirmDeleteClass = async () => {
    if (deleteConfirmId) {
      try {
        const res = await fetch('/api/classes/' + deleteConfirmId, { method: 'DELETE' });
        if (res.ok) {
          fetchClasses();
          setDeleteConfirmId(null);
        }
      } catch (e) {
        console.error(e);
      }
    }
  };
`;

code = code.replace("  const [isBulkMode, setIsBulkMode] = useState(false);", "  const [isBulkMode, setIsBulkMode] = useState(false);\n" + stateAdditions);

code = code.replace(
  `<button className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20">`,
  `<button onClick={() => setClassForm({ className: '', section: '', classTeacher: 'Unassigned' })} className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20">`
);

code = code.replace(
  `<button onClick={(e) => e.stopPropagation()} className="flex items-center gap-1.5 px-3 py-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Edit size={16} /> Edit
                      </button>`,
  `<button onClick={(e) => { e.stopPropagation(); setClassForm(cls); }} className="flex items-center gap-1.5 px-3 py-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Edit size={16} /> Edit
                      </button>`
);

code = code.replace(
  `<button onClick={(e) => e.stopPropagation()} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Trash2 size={16} /> Delete
                      </button>`,
  `<button onClick={(e) => { e.stopPropagation(); setDeleteConfirmId(cls.id); }} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Trash2 size={16} /> Delete
                      </button>`
);

// Add the modals at the end of the file, just before the closing </div> of ClassSetup
const modalsStr = `
      {/* Class Form Modal */}
      {classForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setClassForm(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            
            <h3 className="text-xl font-bold text-white mb-6">
              {classForm.id ? 'Edit Class' : 'Add New Class'}
            </h3>
            
            <form onSubmit={handleSaveClass} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Class Name *</label>
                <input 
                  required
                  type="text" 
                  placeholder="e.g. Class 11"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.className || ''} 
                  onChange={e => setClassForm({...classForm, className: e.target.value})} 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Section *</label>
                <input 
                  required
                  type="text" 
                  placeholder="e.g. A"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.section || ''} 
                  onChange={e => setClassForm({...classForm, section: e.target.value})} 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Class Teacher</label>
                <input 
                  type="text" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.classTeacher || ''} 
                  onChange={e => setClassForm({...classForm, classTeacher: e.target.value})} 
                />
              </div>
              
              <div className="flex gap-4 pt-2">
                <button 
                  type="button" 
                  onClick={() => setClassForm(null)}
                  className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-indigo-500/20"
                >
                  Save Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-sm w-full mx-4 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">Delete Class</h3>
            <p className="text-gray-400 mb-8">Are you sure you want to delete this class? Students in this class will need to be reassigned.</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDeleteClass}
                className="flex-1 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-colors shadow-lg shadow-red-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
`;

code = code.replace(/    <\/div>\n  \);\n}\n*$/, modalsStr + '\n    </div>\n  );\n}\n');

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', code);
console.log('ClassSetup.tsx patched with modals');
