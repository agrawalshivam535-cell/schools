const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Dashboard.tsx', 'utf-8');

const statCardFuncRx = /function StatCard\(\{ title, value, color \}: \{ title: string, value: string \| number, color: string \}\) \{([\s\S]*?)return \([\s\S]*?<motion\.div([\s\S]*?)className=\{([\s\S]*?)\}>([\s\S]*?)<\/motion\.div>\s*\);\s*\}/m;

const newStatCard = `function StatCard({ title, value, color }: { title: string, value: string | number, color: string }) {
  const colorMap: Record<string, string> = {
    indigo: 'border-indigo-500 text-indigo-400 hover:shadow-indigo-500/20',
    purple: 'border-purple-500 text-purple-400 hover:shadow-purple-500/20',
    emerald: 'border-emerald-500 text-emerald-400 hover:shadow-emerald-500/20',
    blue: 'border-blue-500 text-blue-400 hover:shadow-blue-500/20',
    red: 'border-red-500 text-red-400 hover:shadow-red-500/20',
  };
  return (
    <motion.div 
      variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 24 } } }}
      whileHover={{ y: -5, scale: 1.02 }}
      className={"bg-[#0f0f0f]/60 backdrop-blur-xl border border-white/5 p-5 flex flex-col justify-center border-l-4 rounded-xl shadow-xl transition-all duration-300 " + colorMap[color].split(' ').slice(0,1).join('') + " " + colorMap[color].split(' ').slice(2).join('')}
    >
      <span className="text-sm font-medium text-gray-400">{title}</span>
      <span className={"text-3xl font-extrabold mt-2 " + colorMap[color].split(' ')[1]}>{value}</span>
    </motion.div>
  );
}`;

content = content.replace(statCardFuncRx, newStatCard);
fs.writeFileSync('src/components/tabs/Dashboard.tsx', content);
console.log('Fixed Tailwind dynamic classes');
