const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `                const displayMarks = STANDARD_EXAMS.map(examName => {
                  const existingExam = marks.find((m: any) => m.examName === examName);
                  if (existingExam) return existingExam;
                  return {
                    examName,
                    total: 0,
                    obtained: 0,
                    isBlank: true,
                    subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
                  };
                });`;

const replacement = `                const displayMarks = STANDARD_EXAMS.map(examName => {
                  const existingExam = marks.find((m: any) => m.examName === examName);
                  if (existingExam) {
                    const paddedSubjects = STANDARD_SUBJECTS.map(subjName => {
                      const found = existingExam.subjects.find((s: any) => s.name === subjName);
                      return found ? found : { name: subjName, obtained: '-' };
                    });
                    return {
                      ...existingExam,
                      subjects: paddedSubjects
                    };
                  }
                  return {
                    examName,
                    total: 0,
                    obtained: 0,
                    isBlank: true,
                    subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
                  };
                });`;

if (!code.includes(target)) {
  console.error("Could not find target in Students.tsx!");
  process.exit(1);
}

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched Students.tsx");
