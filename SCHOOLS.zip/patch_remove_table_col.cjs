const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// Replace table header
content = content.replace(
  `<th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Month</th>\\n`,
  ``
);

// Replace colSpan
content = content.replace(
  `<td colSpan={5} className="p-8 text-center text-gray-500">No payments recorded.</td>`,
  `<td colSpan={4} className="p-8 text-center text-gray-500">No payments recorded.</td>`
);

// Replace table row
const rowTarget = `<td className="p-5 text-sm">
                            <span className="font-medium text-white">{p.forMonth || '-'}</span>
                            {p.isPartial && <span className="ml-2 text-xs font-bold text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded uppercase">Partial</span>}
                          </td>`;

content = content.replace(rowTarget, ``);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched to remove table column");
