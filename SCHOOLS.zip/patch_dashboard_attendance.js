import fs from 'fs';
let serverCode = fs.readFileSync('server.ts', 'utf-8');

serverCode = serverCode.replace(
  `attendancePct: "95%",`,
  `// compute attendance
      attendancePct: (() => {
        let present = 0;
        let total = 0;
        attendanceRecords.forEach(ar => {
          ar.records.forEach(r => {
            total++;
            if (r.status === 'Present') present++;
          });
        });
        return total === 0 ? "100%" : Math.round((present/total)*100) + "%";
      })(),`
);

fs.writeFileSync('server.ts', serverCode);
console.log('patched dashboard attendance');
