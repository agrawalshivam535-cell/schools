const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Integrations.tsx', 'utf-8');

content = content.replace(
  "const activateTelegram = async () => {",
  "const activateTelegram = async () => {\n    setSetupStatus('success');\n    return;"
);

content = content.replace(
  "Step 1: Activate System Webhook",
  "Step 1: System Status"
);

content = content.replace(
  "Turn on the background listener so your server can instantly process messages from parents.",
  "The backend server is automatically polling for incoming messages in real-time."
);

content = content.replace(
  "Activate Telegram Hook",
  "System Active & Polling"
);

fs.writeFileSync('src/components/tabs/Integrations.tsx', content);
