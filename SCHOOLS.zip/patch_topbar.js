import fs from 'fs';
let code = fs.readFileSync('src/components/Topbar.tsx', 'utf-8');

// Also import LogOut
code = code.replace(
  "import { Menu, Settings } from 'lucide-react';",
  "import { Menu, Settings, LogOut } from 'lucide-react';"
);

// Add onLogout to props
code = code.replace(
  "  title: string;",
  "  title: string;\n  onLogout?: () => void;"
);

// Add onLogout to destructuring
code = code.replace(
  "export function Topbar({ user, onOpenSidebar, title }: TopbarProps) {",
  "export function Topbar({ user, onOpenSidebar, title, onLogout }: TopbarProps) {"
);

// Add logout button
const logoutButton = `
        </div>
        {onLogout && (
          <button 
            onClick={onLogout}
            className="p-2 text-gray-400 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors"
            title="Sign Out"
          >
            <LogOut size={20} />
          </button>
        )}
      </div>
`;
code = code.replace(/<\/div>\s*<\/div>\s*<\/div>/m, logoutButton + "\n    </div>");

fs.writeFileSync('src/components/Topbar.tsx', code);
