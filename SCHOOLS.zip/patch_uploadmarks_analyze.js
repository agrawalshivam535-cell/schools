import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const regex = /const response = await fetch\('\/api\/exams\/analyze', \{[\s\S]*?throw new Error\("Server returned an invalid response\."\);\s*\}/m;

const replacement = `const response = await fetch('/api/exams/jobs/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: file.name,
          fileData: base64data,
          mimeType: 'image/jpeg',
          className: uploadClass,
          section: uploadSection,
          subject: uploadSubject,
          examType: uploadExamType,
          maxMarks: uploadMaxMarks
        })
      });

      let data;
      try {
        data = await response.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }
      
      setIsUploading(false);
      if (onUploadSuccess) onUploadSuccess();
      return; // Skip the rest of the function since it's background processed
`;

code = code.replace(regex, replacement);

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
