import fs from 'fs';

let upload = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const oldHandleAnalyze = `  const handleAnalyze = async () => {
    if (!file) return;
    setIsUploading(true);
    setAnalyzedData(null);
    setIsSaved(false);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        
        const response = await fetch('/api/exams/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileData: base64data,
            mimeType: file.type,
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            }
          })
        });

        const data = await response.json();
        if (response.ok && Array.isArray(data)) {
          setAnalyzedData(data);
        } else {
          console.error('API Error:', data);
          alert(data.error || 'Failed to analyze document');
          setAnalyzedData(null);
        }
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      setIsUploading(false);
    }
  };`;

const newHandleAnalyze = `  const handleAnalyze = async () => {
    if (!file) return;
    setIsUploading(true);
    setAnalyzedData(null);
    setIsSaved(false);

    try {
      const base64data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            resolve(reader.result.split(',')[1]);
          } else {
            reject(new Error("Failed to read file"));
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      
      const response = await fetch('/api/exams/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: base64data,
          mimeType: file.type,
          answers: {
            q1: uploadClass,
            q2: uploadSection,
            q3: uploadSubject,
            q4: uploadExamType,
            q5: uploadMaxMarks
          }
        })
      });

      let data;
      try {
        data = await response.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }

      if (response.ok && Array.isArray(data)) {
        setAnalyzedData(data);
      } else {
        console.error('API Error:', data);
        alert(data.error || 'Failed to analyze document');
        setAnalyzedData(null);
      }
    } catch (err: any) {
      console.error(err);
      alert('Error analyzing document: ' + err.message);
      setAnalyzedData(null);
    } finally {
      setIsUploading(false);
    }
  };`;

upload = upload.replace(oldHandleAnalyze, newHandleAnalyze);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', upload);
console.log('Fixed handleAnalyze error catching');
