const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// Update state definition
content = content.replace(
  `const [paymentForm, setPaymentForm] = useState<{ amount: string; method: string; remarks: string } | null>(null);`,
  `const [paymentForm, setPaymentForm] = useState<{ amount: string; method: string; remarks: string; forMonth: string; isPartial: boolean } | null>(null);`
);

// Update setPaymentForm calls
content = content.replace(
  `onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '' })}`,
  `onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '', forMonth: new Date().toLocaleString('default', { month: 'long' }), isPartial: false })}`
);

// Update fetch call payload
content = content.replace(
  `amount: Number(paymentForm.amount),
          method: paymentForm.method,
          remarks: paymentForm.remarks`,
  `amount: Number(paymentForm.amount),
          method: paymentForm.method,
          remarks: paymentForm.remarks,
          forMonth: paymentForm.forMonth,
          isPartial: paymentForm.isPartial`
);

// Add fields to form
const formFields = `              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">For Month *</label>
                <select 
                  required 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                  value={paymentForm.forMonth} 
                  onChange={e => setPaymentForm({...paymentForm, forMonth: e.target.value})}
                >
                  {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                    <option key={m} value={m} className="bg-[#151515]">{m}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <input 
                  type="checkbox" 
                  id="isPartial"
                  checked={paymentForm.isPartial}
                  onChange={e => setPaymentForm({...paymentForm, isPartial: e.target.checked})}
                  className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="isPartial" className="text-sm font-medium text-gray-400 cursor-pointer">
                  This is a partial payment for the selected month
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Payment Method *</label>`;

content = content.replace(
  `              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Payment Method *</label>`,
  formFields
);

// Update the fees table to show the month and partial status
const tableHeaders = `<th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Date</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Month</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Amount</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Mode</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase text-right">Receipt</th>`;

content = content.replace(
  `<th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Date</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Amount</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Mode</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase text-right">Receipt</th>`,
  tableHeaders
);

// Update table colSpan
content = content.replace(
  `<td colSpan={4} className="p-8 text-center text-gray-500">No payments recorded.</td>`,
  `<td colSpan={5} className="p-8 text-center text-gray-500">No payments recorded.</td>`
);

// Update table row
const tableRow = `<td className="p-5 text-sm text-gray-300">{new Date(p.date).toLocaleDateString()}</td>
                          <td className="p-5 text-sm">
                            <span className="font-medium text-white">{p.forMonth || '-'}</span>
                            {p.isPartial && <span className="ml-2 text-xs font-bold text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded uppercase">Partial</span>}
                          </td>
                          <td className="p-5 text-sm font-bold text-white">₹{p.amount}</td>
                          <td className="p-5 text-sm text-gray-400">{p.method}</td>
                          <td className="p-5 text-right">`;

content = content.replace(
  `<td className="p-5 text-sm text-gray-300">{new Date(p.date).toLocaleDateString()}</td>
                          <td className="p-5 text-sm font-bold text-white">₹{p.amount}</td>
                          <td className="p-5 text-sm text-gray-400">{p.method}</td>
                          <td className="p-5 text-right">`,
  tableRow
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx");
