const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

content = content.replace(
  'app.get("/api/telegram/setup", async (req, res) => {',
  'app.get("/api/headers", (req, res) => res.json(req.headers));\n  app.get("/api/telegram/setup", async (req, res) => {'
);
fs.writeFileSync('server.ts', content);
