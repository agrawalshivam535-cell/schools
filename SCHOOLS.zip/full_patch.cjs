const fs = require('fs');

// 1. Patch server.ts
let server = fs.readFileSync('server.ts', 'utf-8');

// Details endpoint
server = server.replace(/\/api\/students\/:rollNumber/g, '/api/students/:id');
server = server.replace(/const rollNumber = req\.params\.rollNumber;/g, 'const id = req.params.id;');
server = server.replace(/s\.rollNumber === rollNumber/g, 's.id === id');
server = server.replace(/s\.rollNumber === req\.params\.rollNumber/g, 's.id === req.params.id');
server = server.replace(/s\.rollNumber !== req\.params\.rollNumber/g, 's.id !== req.params.id');

// Attendance API
server = server.replace(/r\.rollNumber === student\.rollNumber/g, 'r.id === student.id');
server = server.replace(/rollNumber: student\.rollNumber,/g, 'id: student.id, rollNumber: student.rollNumber,');

// Fees API
server = server.replace(/p\.rollNumber === student\.rollNumber/g, 'p.id === student.id');
server = server.replace(/p\.rollNumber === rollNumber/g, 'p.id === id');
server = server.replace(/rollNumber: student\.rollNumber,/g, 'id: student.id, rollNumber: student.rollNumber,');

// Exams API
server = server.replace(/s\.rollNumber === row\.rollNumber/g, 's.id === row.id');
server = server.replace(/r\.rollNumber === student\.rollNumber/g, 'r.id === student.id');
server = server.replace(/rollNumber: r\.rollNumber/g, 'id: r.id');
server = server.replace(/String\(s\.rollNumber\) === String\(r\.rollNumber\)/g, 'String(s.id) === String(r.id)');
server = server.replace(/rollNumber: s\.id/g, 'id: s.id');

// promote-selected
server = server.replace(/const \{ rollNumbers, toClassName \} = req\.body;/g, 'const { studentIds, toClassName } = req.body;');
server = server.replace(/rollNumbers\.includes\(s\.rollNumber\)/g, 'studentIds.includes(s.id)');
server = server.replace(/rollNumbers\.includes/g, 'studentIds.includes');
server = server.replace(/promotedRolls\.push\(s\.rollNumber\)/g, 'promotedRolls.push(s.id)');
server = server.replace(/promotedRolls\.includes\(r\.rollNumber\)/g, 'promotedRolls.includes(r.id)');
server = server.replace(/promotedRolls\.includes\(fp\.rollNumber\)/g, 'promotedRolls.includes(fp.id)');
server = server.replace(/studentIds\.includes\(r\.rollNumber\)/g, 'studentIds.includes(r.id)');
server = server.replace(/studentIds\.includes\(fp\.rollNumber\)/g, 'studentIds.includes(fp.id)');

// Related records matches
server = server.replace(/String\(r\.rollNumber\) === String\(rollNumber\)/g, 'String(r.id) === String(id)');

fs.writeFileSync('server.ts', server);

// 2. Patch frontend
const files = [
  'src/components/tabs/Students.tsx',
  'src/components/tabs/Fees.tsx',
  'src/components/tabs/Timetable.tsx',
  'src/components/tabs/Attendance.tsx',
  'src/components/tabs/Exams.tsx',
  'src/components/tabs/ClassSetup.tsx'
];

for (let file of files) {
  if (!fs.existsSync(file)) continue;
  let content = fs.readFileSync(file, 'utf-8');
  
  // Replace keys
  content = content.replace(/key=\{student\.rollNumber\}/g, 'key={student.id}');
  content = content.replace(/key=\{s\.rollNumber\}/g, 'key={s.id}');
  
  // Replace API URLs
  content = content.replace(/\/api\/students\/\$\{rollNumber\}/g, '/api/students/${studentId}');
  content = content.replace(/\/api\/students\/\$\{deleteConfirmId\}/g, '/api/students/${deleteConfirmId}'); // Will change deleteConfirmId to hold id
  content = content.replace(/editForm\.rollNumber/g, 'editForm.id');
  
  if (file.includes('Students.tsx')) {
    content = content.replace(/selectedRollNumbers/g, 'selectedIds');
    content = content.replace(/setSelectedRollNumbers/g, 'setSelectedIds');
    content = content.replace(/rollNumbers:/g, 'studentIds:');
    content = content.replace(/toggleSelectStudent\(student\.rollNumber\)/g, 'toggleSelectStudent(student.id)');
    content = content.replace(/selectedIds\.includes\(student\.rollNumber\)/g, 'selectedIds.includes(student.id)');
    content = content.replace(/const toggleSelectStudent = \(rollNumber: string\)/g, 'const toggleSelectStudent = (id: string)');
    content = content.replace(/prev\.includes\(rollNumber\) \? prev\.filter\(r => r !== rollNumber\) : \[\.\.\.prev, rollNumber\]/g, 'prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]');
    content = content.replace(/viewStudentDetails = async \(rollNumber: string\)/g, 'viewStudentDetails = async (studentId: string)');
    content = content.replace(/students\/\$\{rollNumber\}\/details/g, 'students/${studentId}/details');
    content = content.replace(/setDeleteConfirmId\(student\.rollNumber\)/g, 'setDeleteConfirmId(student.id)');
    content = content.replace(/editForm: any> \(null\)/, "editForm: any>(null)");
  }
  
  if (file.includes('Attendance.tsx')) {
    content = content.replace(/status-\" \+ student\.rollNumber/g, 'status-" + student.id');
    content = content.replace(/handleStatusChange\(student\.rollNumber/g, 'handleStatusChange(student.id');
    content = content.replace(/handleStatusChange = \(rollNumber: string/g, 'handleStatusChange = (id: string');
    content = content.replace(/r\.rollNumber === rollNumber/g, 'r.id === id');
  }
  
  if (file.includes('Fees.tsx')) {
    content = content.replace(/handlePayment\(student\.rollNumber\)/g, 'handlePayment(student.id)');
    content = content.replace(/handlePayment = \(rollNumber: string\)/g, 'handlePayment = (id: string)');
    content = content.replace(/rollNumber, /g, 'id, ');
    content = content.replace(/rollNumber:/g, 'id:');
  }
  
  if (file.includes('ClassSetup.tsx')) {
    content = content.replace(/selectedRollNumbers/g, 'selectedIds');
    content = content.replace(/setSelectedRollNumbers/g, 'setSelectedIds');
    content = content.replace(/rollNumbers:/g, 'studentIds:');
    content = content.replace(/toggleSelectStudent\(student\.rollNumber\)/g, 'toggleSelectStudent(student.id)');
    content = content.replace(/selectedIds\.includes\(student\.rollNumber\)/g, 'selectedIds.includes(student.id)');
    content = content.replace(/const toggleSelectStudent = \(rollNumber: string\)/g, 'const toggleSelectStudent = (id: string)');
    content = content.replace(/prev\.includes\(rollNumber\) \? prev\.filter\(r => r !== rollNumber\) : \[\.\.\.prev, rollNumber\]/g, 'prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]');
    content = content.replace(/s\.rollNumber/g, 's.id');
  }
  
  if (file.includes('Exams.tsx')) {
    content = content.replace(/id: s\.rollNumber/g, 'id: s.id');
    content = content.replace(/selectedResults\.includes\(student\.rollNumber\)/g, 'selectedResults.includes(student.id)');
    content = content.replace(/toggleSelectStudent\(student\.rollNumber\)/g, 'toggleSelectStudent(student.id)');
    content = content.replace(/toggleSelectStudent = \(rollNumber: string\)/g, 'toggleSelectStudent = (id: string)');
    content = content.replace(/prev\.includes\(rollNumber\) \? prev\.filter\(r => r !== rollNumber\) : \[\.\.\.prev, rollNumber\]/g, 'prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]');
    content = content.replace(/viewReport = async \(rollNumber: string\)/g, 'viewReport = async (studentId: string)');
    content = content.replace(/students\/\$\{rollNumber\}\/details/g, 'students/${studentId}/details');
  }
  
  fs.writeFileSync(file, content);
}
