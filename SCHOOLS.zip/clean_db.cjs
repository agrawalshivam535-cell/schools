const fs = require('fs');
let analysisRecords = JSON.parse(fs.readFileSync('analysis.json', 'utf8'));

// Group by className, section, subject, examType
let newRecords = [];
let grouped = {};

analysisRecords.forEach(ar => {
  const key = `${ar.className}-${ar.section}-${ar.subject}-${ar.examType}`;
  if (!grouped[key]) {
    grouped[key] = { ...ar, records: [...ar.records] };
  } else {
    // Merge newer records into existing (assuming later in array is newer)
    ar.records.forEach(newRec => {
      let idx = grouped[key].records.findIndex(r => String(r.id) === String(newRec.id) || String(r.rollNumber) === String(newRec.rollNumber));
      if (idx !== -1) {
         grouped[key].records[idx] = newRec;
      } else {
         grouped[key].records.push(newRec);
      }
    });
    grouped[key].timestamp = ar.timestamp;
  }
});

for (let key in grouped) {
  newRecords.push(grouped[key]);
}

fs.writeFileSync('analysis.json', JSON.stringify(newRecords, null, 2));
console.log('Cleaned db');
