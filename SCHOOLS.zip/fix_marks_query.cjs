const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rxQuery = /const clsQuery = resultClass === 'All' \? 'All Classes' \: fullClassName;\s*const secQuery = resultClass === 'All' \? 'All Sections' \: resultSection;/m;
const newQuery = `const clsQuery = resultClass === 'All' ? 'All Classes' : fullClassName;
      let actualSection = resultSection;
      if (resultClass !== 'All' && resultClass.includes(' - ')) {
        actualSection = resultClass.split(' - ')[1];
      }
      const secQuery = resultClass === 'All' ? 'All Sections' : actualSection;`;

content = content.replace(rxQuery, newQuery);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Fixed marks query section logic');
