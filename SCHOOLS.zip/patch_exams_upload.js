import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Import
code = code.replace(
  "import { useState } from 'react';",
  "import { useState } from 'react';\nimport { UploadMarks } from './UploadMarks';"
);

// 2. Add 'upload' to state
code = code.replace(
  "const [activeTab, setActiveTab] = useState<'results' | 'enter'>('enter');",
  "const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload'>('enter');"
);

// 3. Add Tab Button
const oldTabs = `            {activeTab === 'enter' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>`;
const newTabs = `            {activeTab === 'enter' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'upload' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Upload
            {activeTab === 'upload' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>`;
code = code.replace(oldTabs, newTabs);

// 4. Render Upload Marks
const oldRender = `        {activeTab === 'results' ? (`;
const newRender = `        {activeTab === 'upload' ? (
          <UploadMarks />
        ) : activeTab === 'results' ? (`;
code = code.replace(oldRender, newRender);

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Exams updated for Upload');
