const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Dashboard.tsx', 'utf-8');

content = content.replace(
  'export function Dashboard({ onNavigate }: { onNavigate: (tab: string) => void })',
  'export function Dashboard({ onNavigate }: { onNavigate: (tab: string, action?: string) => void })'
);

content = content.replace(
  "onClick={() => onNavigate('students')}",
  "onClick={() => onNavigate('students', 'enroll')}"
);

fs.writeFileSync('src/components/tabs/Dashboard.tsx', content);
console.log("Patched Dashboard.tsx");
