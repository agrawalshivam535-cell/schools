const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// 1. Refactor downloadFullReportCard to use buildFullPDF
const fullReportRx = /const downloadFullReportCard = \(displayMarks: any\[\], student: any, action: 'download' \| 'preview' = 'download'\) => \{\s*if \(action === "preview"\) \{\s*setPreviewData\(\{ type: 'full', data: displayMarks, student \}\);\s*return;\s*\}\s*const doc = new jsPDF\(\);[\s\S]*?doc\.save\(\`Full_Report_\$\{student\.rollNumber\}\.pdf\`\);\s*\};/m;

const buildFullPDFCode = `const buildFullPDF = (displayMarks: any[], student: any) => {
    const doc = new jsPDF();
    let y = 20;
    
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, y, { align: 'center' });
    y += 10;
    
    doc.setFontSize(16);
    doc.text('Full Academic Report', 105, y, { align: 'center' });
    y += 15;

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, y);
    y += 10;
    
    doc.text("Student Name: " + student.name, 20, y);
    y += 10;
    doc.text("Roll Number: " + student.rollNumber, 20, y);
    y += 10;
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, y);
    y += 15;
    
    doc.setLineWidth(0.5);
    doc.line(20, y, 190, y);
    y += 10;
    
    displayMarks.forEach(exam => {
      if (y > 250) {
        doc.addPage();
        y = 20;
      }

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text(exam.examName, 20, y);
      
      if (exam.isBlank) {
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text("Not Recorded", 150, y);
        y += 10;
      } else {
        y += 10;
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text('Subject', 20, y);
        doc.text('Marks', 150, y);
        y += 5;
        doc.line(20, y, 190, y);
        y += 8;

        doc.setFont("helvetica", "normal");
        exam.subjects.forEach((subj: any) => {
          doc.text(subj.name, 20, y);
          doc.text(String(subj.obtained), 150, y);
          y += 8;
        });
        
        doc.line(20, y, 190, y);
        y += 8;
        
        doc.setFont("helvetica", "bold");
        doc.text("Total", 20, y);
        doc.text(String(exam.obtained) + " / " + String(exam.total), 150, y);
        y += 8;
        
        const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
        let grade = 'F';
        if (Number(percentage) >= 90) grade = 'A+';
        else if (Number(percentage) >= 80) grade = 'A';
        else if (Number(percentage) >= 70) grade = 'B';
        else if (Number(percentage) >= 60) grade = 'C';
        else if (Number(percentage) >= 50) grade = 'D';
        doc.text(\`Percentage: \${percentage}% | Grade: \${grade}\`, 20, y);
        y += 15;
      }
    });
    return doc;
  };

  const downloadFullReportCard = (displayMarks: any[], student: any, action: 'download' | 'preview' = 'download') => {
    if (action === "preview") {
      setPreviewData({ type: 'full', data: displayMarks, student });
      return;
    }
    const doc = buildFullPDF(displayMarks, student);
    doc.save(\`Full_Report_\${student.rollNumber}.pdf\`);
  };

  const sendFullTelegramResult = async (displayMarks: any[], student: any) => {
    setSendingTelegramId('full_report');
    try {
      let message = \`*Full Academic Report - \${student.name}*\\nRoll No: \${student.rollNumber}\\nClass: \${student.className} \${student.section ? '- ' + student.section : ''}\\n\\n\`;
      
      displayMarks.forEach((exam: any) => {
        if (exam.isBlank) return;
        message += \`*\${exam.examName}*\\n\`;
        exam.subjects.forEach((subj: any) => {
          message += \`\${subj.name}: \${subj.obtained}\\n\`;
        });
        message += \`Total: \${exam.obtained}/\${exam.total}\\n\\n\`;
      });
      
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }
      
      const doc = buildFullPDF(displayMarks, student);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Full Report sent successfully to ' + student.name);
      } else {
        alert(\`Failed to send message: \${data.message}\`);
      }
    } catch (err) {
      alert('An error occurred while sending the message.');
    } finally {
      setSendingTelegramId(null);
    }
  };`;

content = content.replace(fullReportRx, buildFullPDFCode);

// 2. Add the send telegram button in the UI next to the Download full report button
const uiRx = /<button \s*onClick=\{\(\) => downloadFullReportCard\(displayMarks, selectedStudent\.student\)\}\s*className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"\s*>\s*<Download size=\{16\} \/> Download\s*<\/button>/m;

const newUi = `<button 
                          onClick={() => sendFullTelegramResult(displayMarks, selectedStudent.student)}
                          disabled={sendingTelegramId === 'full_report'}
                          className="bg-[#229ED9] hover:bg-[#1CA0DE] disabled:opacity-50 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors shadow-lg flex items-center justify-center gap-2"
                        >
                          {sendingTelegramId === 'full_report' ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} Telegram
                        </button>
                        <button 
                          onClick={() => downloadFullReportCard(displayMarks, selectedStudent.student)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
                        >
                          <Download size={16} /> Download
                        </button>`;

content = content.replace(uiRx, newUi);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log('Patched Full Report Telegram button in Students.tsx');
