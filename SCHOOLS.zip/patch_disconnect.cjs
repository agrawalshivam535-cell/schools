const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const disconnectLogic = `
  app.post("/api/students/:id/disconnect-telegram", (req, res) => {
    const idx = students.findIndex(s => s.id === req.params.id);
    if (idx !== -1) {
      students[idx] = { ...students[idx], telegramChatId: '' };
      saveDb('students.json', students);
      res.json({ success: true, student: students[idx] });
    } else {
      res.status(404).json({ error: 'Student not found' });
    }
  });
`;

if (!content.includes('/api/students/:id/disconnect-telegram')) {
  content = content.replace(
    '  app.post("/api/students/promote-selected", (req, res) => {',
    disconnectLogic + '\n  app.post("/api/students/promote-selected", (req, res) => {'
  );
  fs.writeFileSync('server.ts', content);
  console.log("Patched server.ts with disconnect route");
}
