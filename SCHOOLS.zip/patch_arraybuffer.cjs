const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = XLSX.read(bstr, { type: 'binary' });
        
        let allRows: any[] = [];`;

const replacement = `    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        let allRows: any[] = [];`;

code = code.replace(target, replacement);
code = code.replace("reader.readAsBinaryString(file);", "reader.readAsArrayBuffer(file);");

fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Updated to ArrayBuffer");
