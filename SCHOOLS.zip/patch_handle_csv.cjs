const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingCSV(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        let rows = results.data;
        if (!rows || rows.length === 0) {
          alert('CSV file is empty or invalid.');
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['studentid', 'id'].includes(cleanKey)) normalized.id = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['fathername', 'fathersname', 'parentname', 'guardianname', 'father'].includes(cleanKey)) normalized.fatherName = row[key];
            else if (['mothername', 'mothersname', 'mother'].includes(cleanKey)) normalized.motherName = row[key];
            else if (['parentphone', 'phone', 'mobile', 'contactnumber', 'parentcontact'].includes(cleanKey)) normalized.parentPhone = String(row[key]);
            else if (['email', 'emailaddress'].includes(cleanKey)) normalized.email = row[key];
            else if (['gender', 'sex'].includes(cleanKey)) normalized.gender = row[key];
            else if (['dob', 'dateofbirth', 'birthdate'].includes(cleanKey)) normalized.dob = row[key];
            else if (['address', 'homeaddress'].includes(cleanKey)) normalized.address = row[key];
            else if (['bloodgroup', 'blood'].includes(cleanKey)) normalized.bloodGroup = row[key];
            else if (['admissiondate', 'dateofadmission'].includes(cleanKey)) normalized.admissionDate = row[key];
            else if (['city'].includes(cleanKey)) normalized.city = row[key];
            else if (['state'].includes(cleanKey)) normalized.state = row[key];
            else if (['pincode', 'pin', 'zip', 'zipcode'].includes(cleanKey)) normalized.pinCode = row[key];
            else if (['telegramchatid', 'telegramid', 'telegram'].includes(cleanKey)) normalized.telegramChatId = String(row[key]);
            else normalized[key] = row[key]; // keep other fields
          }

          // Format class and section to match app expectations (e.g., "Class 10 - A")
          if (normalized.className) {
            let baseClass = normalized.className;
            // If they just provided a number like "10", make it "Class 10"
            if (/^\\d+$/.test(baseClass)) {
              baseClass = \`Class \${baseClass}\`;
            } else if (/^class\\s*\\d+$/i.test(baseClass)) {
              const num = baseClass.match(/\\d+/)[0];
              baseClass = \`Class \${num}\`;
            }
            
            // If section is provided, ensure className has the " - [Section]" suffix
            if (normalized.section) {
              const expectedSuffix = \` - \${normalized.section}\`;
              if (!baseClass.includes(expectedSuffix)) {
                // If it had a different section suffix, strip it first
                baseClass = baseClass.split(' - ')[0];
                normalized.className = \`\${baseClass}\${expectedSuffix}\`;
              }
            } else {
              // If no section provided in CSV, but className has one, extract it
              if (baseClass.includes(' - ')) {
                normalized.section = baseClass.split(' - ')[1].trim().toUpperCase();
              } else {
                normalized.section = 'A'; // default
                normalized.className = \`\${baseClass} - A\`;
              }
            }
          }
          return normalized;
        });

        try {
          const res = await fetch('/api/students/bulk-csv', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ students: rows }),
          });

          if (res.ok) {
            const data = await res.json();
            
            // Extract the first valid class/section from the upload to auto-navigate
            const firstValid = rows.find((r: any) => r.className);
            if (firstValid) {
              setClassName(firstValid.className);
              if (firstValid.section) setSection(firstValid.section);
            }

            alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students.\`);
            fetchStudents();
          } else {
            const err = await res.json();
            alert('Failed to upload students: ' + (err.error || 'Unknown error'));
          }
        } catch (error) {
          console.error('Error uploading CSV', error);
          alert('Failed to upload CSV');
        } finally {
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      },
      error: (error) => {
        console.error('Error parsing CSV:', error);
        alert('Error parsing CSV file');
        setIsUploadingCSV(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    });
  };`;

const replacement = `  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingCSV(true);

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = XLSX.read(bstr, { type: 'binary' });
        
        let allRows: any[] = [];
        
        // Loop through all sheets in the file
        workbook.SheetNames.forEach(sheetName => {
          const sheet = workbook.Sheets[sheetName];
          const sheetRows = XLSX.utils.sheet_to_json(sheet);
          allRows = allRows.concat(sheetRows);
        });

        let rows = allRows;

        if (!rows || rows.length === 0) {
          alert('File is empty or invalid.');
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['studentid', 'id'].includes(cleanKey)) normalized.id = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['fathername', 'fathersname', 'parentname', 'guardianname', 'father'].includes(cleanKey)) normalized.fatherName = row[key];
            else if (['mothername', 'mothersname', 'mother'].includes(cleanKey)) normalized.motherName = row[key];
            else if (['parentphone', 'phone', 'mobile', 'contactnumber', 'parentcontact'].includes(cleanKey)) normalized.parentPhone = String(row[key]);
            else if (['email', 'emailaddress'].includes(cleanKey)) normalized.email = row[key];
            else if (['gender', 'sex'].includes(cleanKey)) normalized.gender = row[key];
            else if (['dob', 'dateofbirth', 'birthdate'].includes(cleanKey)) normalized.dob = row[key];
            else if (['address', 'homeaddress'].includes(cleanKey)) normalized.address = row[key];
            else if (['bloodgroup', 'blood'].includes(cleanKey)) normalized.bloodGroup = row[key];
            else if (['admissiondate', 'dateofadmission'].includes(cleanKey)) normalized.admissionDate = row[key];
            else if (['city'].includes(cleanKey)) normalized.city = row[key];
            else if (['state'].includes(cleanKey)) normalized.state = row[key];
            else if (['pincode', 'pin', 'zip', 'zipcode'].includes(cleanKey)) normalized.pinCode = row[key];
            else if (['telegramchatid', 'telegramid', 'telegram'].includes(cleanKey)) normalized.telegramChatId = String(row[key]);
            else normalized[key] = row[key]; // keep other fields
          }

          // Format class and section to match app expectations (e.g., "Class 10 - A")
          if (normalized.className) {
            let baseClass = normalized.className;
            // If they just provided a number like "10", make it "Class 10"
            if (/^\\d+$/.test(baseClass)) {
              baseClass = \`Class \${baseClass}\`;
            } else if (/^class\\s*\\d+$/i.test(baseClass)) {
              const num = baseClass.match(/\\d+/)[0];
              baseClass = \`Class \${num}\`;
            }
            
            // If section is provided, ensure className has the " - [Section]" suffix
            if (normalized.section) {
              const expectedSuffix = \` - \${normalized.section}\`;
              if (!baseClass.includes(expectedSuffix)) {
                // If it had a different section suffix, strip it first
                baseClass = baseClass.split(' - ')[0];
                normalized.className = \`\${baseClass}\${expectedSuffix}\`;
              }
            } else {
              // If no section provided in CSV, but className has one, extract it
              if (baseClass.includes(' - ')) {
                normalized.section = baseClass.split(' - ')[1].trim().toUpperCase();
              } else {
                normalized.section = 'A'; // default
                normalized.className = \`\${baseClass} - A\`;
              }
            }
          }
          return normalized;
        });

        const res = await fetch('/api/students/bulk-csv', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ students: rows }),
        });

        if (res.ok) {
          const data = await res.json();
          
          // Extract the first valid class/section from the upload to auto-navigate
          const firstValid = rows.find((r: any) => r.className);
          if (firstValid) {
            setClassName(firstValid.className);
            if (firstValid.section) setSection(firstValid.section);
          }

          alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students from \${workbook.SheetNames.length} tabs.\`);
          fetchStudents();
        } else {
          const err = await res.json();
          alert('Failed to upload students: ' + (err.error || 'Unknown error'));
        }
      } catch (error) {
        console.error('Error processing file:', error);
        alert('Failed to parse file. Make sure it is a valid Excel or CSV file.');
      } finally {
        setIsUploadingCSV(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      alert("Error reading file.");
      setIsUploadingCSV(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.readAsBinaryString(file);
  };`;

if (!code.includes("const firstValid = rows.find")) {
    console.log("Could not find target block");
}

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Replaced handleCSVUpload to use XLSX");
