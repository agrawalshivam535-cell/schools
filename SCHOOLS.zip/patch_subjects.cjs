const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// Fix interface
content = content.replace(/  english: string;\n  socialScience: string;\n  computer: string;\n/, '');

// Fix default state
content = content.replace(/          english: '',\n          socialScience: '',\n          computer: '',\n/, '');

// Fix calculateTotal
content = content.replace(/const calculateTotal = \(student: StudentMarks\) => \{\n    const m = parseInt\(student\.maths\) \|\| 0;\n    const s = parseInt\(student\.science\) \|\| 0;\n    const h = parseInt\(student\.hindi\) \|\| 0;\n    const e = parseInt\(student\.english\) \|\| 0;\n    const ss = parseInt\(student\.socialScience\) \|\| 0;\n    const c = parseInt\(student\.computer\) \|\| 0;\n    return m \+ s \+ h \+ e \+ ss \+ c;\n  \};/m, 
`const calculateTotal = (student: StudentMarks) => {
    const m = parseInt(student.maths) || 0;
    const s = parseInt(student.science) || 0;
    const h = parseInt(student.hindi) || 0;
    return m + s + h;
  };`);

// Fix STANDARD_SUBJECTS
content = content.replace(/const STANDARD_SUBJECTS = \['Maths', 'Science', 'Hindi', 'English', 'Social Science', 'Computer'\];/g, "const STANDARD_SUBJECTS = ['Maths', 'Science', 'Hindi'];");

// Fix HTML in Result tab header
const headerRx = /<th className="p-4 whitespace-nowrap">English<\/th>\s*<th className="p-4 whitespace-nowrap">Social Science<\/th>\s*<th className="p-4 whitespace-nowrap">Computer<\/th>/m;
content = content.replace(headerRx, '');

// Fix HTML in Result tab body
const bodyRx = /<td className="p-4 text-white font-bold">\{getSub\('English'\)\}<\/td>\s*<td className="p-4 text-white font-bold">\{getSub\('Social Science'\)\}<\/td>\s*<td className="p-4 text-white font-bold">\{getSub\('Computer'\)\}<\/td>/m;
content = content.replace(bodyRx, '');

// Fix HTML in Enter Marks tab
const enterMarksRx = /<td className="p-4">\s*<input\s*type="text"\s*inputMode="numeric"\s*className="w-20 bg-black\/40 border border-white\/10 rounded-lg px-3 py-1\.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"\s*value=\{student\.english\}\s*onChange=\{\(e\) => handleMarkChange\(student\.id, 'english', e\.target\.value\)\}\s*\/>\s*<\/td>\s*<td className="p-4">\s*<input\s*type="text"\s*inputMode="numeric"\s*className="w-20 bg-black\/40 border border-white\/10 rounded-lg px-3 py-1\.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"\s*value=\{student\.socialScience\}\s*onChange=\{\(e\) => handleMarkChange\(student\.id, 'socialScience', e\.target\.value\)\}\s*\/>\s*<\/td>\s*<td className="p-4">\s*<input\s*type="text"\s*inputMode="numeric"\s*className="w-20 bg-black\/40 border border-white\/10 rounded-lg px-3 py-1\.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"\s*value=\{student\.computer\}\s*onChange=\{\(e\) => handleMarkChange\(student\.id, 'computer', e\.target\.value\)\}\s*\/>\s*<\/td>/m;
content = content.replace(enterMarksRx, '');

// Fix colSpan
content = content.replace(/colSpan=\{resultExamType !== 'Full Result' \? 12 : 5\}/, "colSpan={resultExamType !== 'Full Result' ? 9 : 5}");

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Exams.tsx');

let studentsContent = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');
studentsContent = studentsContent.replace(/const STANDARD_SUBJECTS = \['Maths', 'Science', 'Hindi', 'English', 'Social Science', 'Computer'\];/g, "const STANDARD_SUBJECTS = ['Maths', 'Science', 'Hindi'];");
fs.writeFileSync('src/components/tabs/Students.tsx', studentsContent);
console.log('Patched Students.tsx');

