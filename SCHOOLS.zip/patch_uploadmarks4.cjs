const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const oldRemap = `if (response.ok && Array.isArray(data)) {
        setAnalyzedData(data);
      } else {`;

const newRemap = `if (response.ok && Array.isArray(data)) {
        try {
          const classNameStr = uploadClass + ' - ' + uploadSection;
          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          const students = await res.json();
          
          const marksRes = await fetch(\`/api/marks/all?className=\${encodeURIComponent(uploadClass)}&section=\${encodeURIComponent(uploadSection)}\`);
          let existingMarks = {};
          if (marksRes.ok) existingMarks = await marksRes.json();
          
          const mergedData = students.map((student: any) => {
            const matchedRecord = data.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            
            let prevMarks = '';
            if (existingMarks[student.id]) {
               const studentExams = existingMarks[student.id];
               const specificExam = studentExams.find((e: any) => e.examName === uploadExamType);
               if (specificExam) {
                  const specificSubj = specificExam.subjects.find((s: any) => s.name === uploadSubject);
                  if (specificSubj) {
                     prevMarks = specificSubj.obtained;
                  }
               }
            }
            
            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : '',
              previousMarks: prevMarks
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });
          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to merge remapped data:", err);
          setAnalyzedData(data);
        }
      } else {`;

content = content.replace(oldRemap, newRemap);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
