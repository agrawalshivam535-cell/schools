const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `      complete: async (results) => {
        const rows = results.data;
        if (!rows || rows.length === 0) {`;

const replacement = `      complete: async (results) => {
        let rows = results.data;
        if (!rows || rows.length === 0) {
          alert('CSV file is empty or invalid.');
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = row[key];
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = row[key];
            else if (['section'].includes(cleanKey)) normalized.section = row[key];
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['parentname', 'fathername', 'guardianname'].includes(cleanKey)) normalized.parentName = row[key];
            else if (['contactnumber', 'phone', 'mobile'].includes(cleanKey)) normalized.contactNumber = row[key];
            else normalized[key] = row[key]; // keep other fields
          }
          return normalized;
        });

        if (!rows) {`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched CSV normalization in frontend");
