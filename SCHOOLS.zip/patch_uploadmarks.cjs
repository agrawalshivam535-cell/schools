const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

// 1. Change the initial state of analyzedData to null
content = content.replace(
  `const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(initialRecord?.records || pendingJob?.records || null);`,
  `const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(null);`
);

// 2. Add the useEffect for fetching and merging students
const useEffectHook = `  useEffect(() => {
    const recordSource = initialRecord || pendingJob;
    if (recordSource && recordSource.records) {
      const fetchClassStudents = async () => {
        try {
          const classNameStr = (recordSource.className || uploadClass) + ' - ' + (recordSource.section || uploadSection);
          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          if (!res.ok) throw new Error('Failed to fetch students');
          const students = await res.json();
          
          const mergedData = students.map((student: any) => {
            const matchedRecord = recordSource.records.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            return {
              id: student.id, // Ensure we use student.id for consistent saving
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (recordSource.maxMarks || uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : ''
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });

          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to fetch students for merging:", err);
          setAnalyzedData(recordSource.records);
        }
      };
      fetchClassStudents();
    }
  }, [initialRecord, pendingJob]);`;

content = content.replace(
  `useEffect(() => {
    if (classes.length > 0 && !uploadClass) {`,
  useEffectHook + `\n\n  useEffect(() => {\n    if (classes.length > 0 && !uploadClass) {`
);

// 3. Update handleRemap to merge with students too
const handleRemapSuccess = `if (response.ok && Array.isArray(data)) {
        setAnalyzedData(data);
      } else {`;
const handleRemapMerge = `if (response.ok && Array.isArray(data)) {
        try {
          const classNameStr = uploadClass + ' - ' + uploadSection;
          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          const students = await res.json();
          
          const mergedData = students.map((student: any) => {
            const matchedRecord = data.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : ''
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });
          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to merge remapped data:", err);
          setAnalyzedData(data);
        }
      } else {`;

content = content.replace(handleRemapSuccess, handleRemapMerge);

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log("Patched UploadMarks");
