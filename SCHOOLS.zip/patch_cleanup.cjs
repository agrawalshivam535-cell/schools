const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf8');

const targetStr = `      if (Array.isArray(data)) {
        try {
          const classNameStr = uploadClass + ' - ' + uploadSection;
          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          const students = await res.json();
          
          const mergedData = students.map((student: any) => {
            const matchedRecord = data.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : ''
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });
          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to merge remapped data:", err);
          setAnalyzedData(data);
        }
      } else {
        console.error('API Error:', data);
        alert(data.error || 'Failed to analyze document');
        setAnalyzedData(null);
      }`;

code = code.replace(targetStr, `      // Early return handles routing to Processing tab`);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
console.log("Cleaned up UploadMarks");
