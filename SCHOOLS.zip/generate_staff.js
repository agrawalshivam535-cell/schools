import fs from 'fs';

const mockStaff = [
  { id: 'S101', name: 'Dr. Anita Desai', role: 'Principal', department: 'Administration', phone: '9876543210', email: 'anita.desai@eduai.com', status: 'Active' },
  { id: 'S102', name: 'Mr. Sharma', role: 'Senior Teacher', department: 'Mathematics', phone: '9876543211', email: 'sharma.maths@eduai.com', status: 'Active' },
  { id: 'S103', name: 'Ms. Verma', role: 'Teacher', department: 'Science', phone: '9876543212', email: 'verma.science@eduai.com', status: 'Active' },
  { id: 'S104', name: 'Mrs. Iyer', role: 'Teacher', department: 'English', phone: '9876543213', email: 'iyer.english@eduai.com', status: 'On Leave' },
  { id: 'S105', name: 'Mr. Singh', role: 'Sports Coach', department: 'Physical Education', phone: '9876543214', email: 'singh.sports@eduai.com', status: 'Active' },
];

fs.writeFileSync('staff.json', JSON.stringify(mockStaff, null, 2));
console.log('staff.json generated');
