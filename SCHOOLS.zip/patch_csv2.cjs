const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = row[key];
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = row[key];
            else if (['section'].includes(cleanKey)) normalized.section = row[key];
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['parentname', 'fathername', 'guardianname'].includes(cleanKey)) normalized.parentName = row[key];
            else if (['contactnumber', 'phone', 'mobile'].includes(cleanKey)) normalized.contactNumber = row[key];
            else normalized[key] = row[key]; // keep other fields
          }
          return normalized;
        });

        if (!rows) {
          alert('CSV file is empty or invalid.');
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }`;

const replacement = `        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['parentname', 'fathername', 'guardianname'].includes(cleanKey)) normalized.parentName = row[key];
            else if (['contactnumber', 'phone', 'mobile'].includes(cleanKey)) normalized.contactNumber = String(row[key]);
            else normalized[key] = row[key]; // keep other fields
          }

          // Format class and section to match app expectations (e.g., "Class 10 - A")
          if (normalized.className) {
            let baseClass = normalized.className;
            // If they just provided a number like "10", make it "Class 10"
            if (/^\\d+$/.test(baseClass)) {
              baseClass = \`Class \${baseClass}\`;
            } else if (/^class\\s*\\d+$/i.test(baseClass)) {
              const num = baseClass.match(/\\d+/)[0];
              baseClass = \`Class \${num}\`;
            }
            
            // If section is provided, ensure className has the " - [Section]" suffix
            if (normalized.section) {
              const expectedSuffix = \` - \${normalized.section}\`;
              if (!baseClass.includes(expectedSuffix)) {
                // If it had a different section suffix, strip it first
                baseClass = baseClass.split(' - ')[0];
                normalized.className = \`\${baseClass}\${expectedSuffix}\`;
              }
            } else {
              // If no section provided in CSV, but className has one, extract it
              if (baseClass.includes(' - ')) {
                normalized.section = baseClass.split(' - ')[1].trim().toUpperCase();
              } else {
                normalized.section = 'A'; // default
                normalized.className = \`\${baseClass} - A\`;
              }
            }
          }
          return normalized;
        });`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched CSV normalization to correctly format className and section");
