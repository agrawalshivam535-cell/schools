import fs from 'fs';

let serverCode = fs.readFileSync('server.ts', 'utf-8');

const importLines = `
let classes: any[] = [];
try {
  classes = JSON.parse(fs.readFileSync('./classes.json', 'utf-8'));
} catch (e) {
  console.error("Could not load classes.json", e);
}
`;

serverCode = serverCode.replace('let attendanceRecords = [];', importLines + '\nlet attendanceRecords = [];');

const classesApi = `
  app.get("/api/classes", (req, res) => {
    // dynamically compute totalStudents
    const result = classes.map(c => {
      const classNameFormatted = c.className + " - " + c.section;
      const totalStudents = students.filter(s => {
         // handle if student has className="Class 1 - A" or className="Class 1", section="A"
         let sClass = s.className;
         let sSec = s.section;
         if (s.className && s.className.includes(" - ")) {
            sClass = s.className.split(" - ")[0];
            sSec = s.className.split(" - ")[1];
         } else {
            sClass = s.className || "Class 1";
            sSec = s.section || "A";
         }
         return sClass === c.className && sSec === c.section;
      }).length;
      return { ...c, totalStudents };
    });
    res.json(result);
  });
`;

serverCode = serverCode.replace('  app.get("/api/students", (req, res) => {', classesApi + '\n  app.get("/api/students", (req, res) => {');

fs.writeFileSync('server.ts', serverCode);
console.log('updated server.ts');
