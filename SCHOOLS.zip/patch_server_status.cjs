const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const targetLogic = `    let feeStatus = 'Unpaid';
    if (paidAmount > 0) feeStatus = balance <= 0 ? 'Paid' : 'Partial';`;

const replacementLogic = `    let feeStatus = 'Unpaid';
    if (payments && payments.length > 0) {
      const monthWeights = {
        'April': 1, 'May': 2, 'June': 3, 'July': 4, 'August': 5, 'September': 6,
        'October': 7, 'November': 8, 'December': 9, 'January': 10, 'February': 11, 'March': 12
      };
      const sortedPayments = [...payments]
        .filter(p => p.forMonth)
        .sort((a, b) => (monthWeights[b.forMonth] || 0) - (monthWeights[a.forMonth] || 0));
      
      if (sortedPayments.length > 0) {
        const latest = sortedPayments[0];
        feeStatus = \`Paid up to \${latest.forMonth}\${latest.isPartial ? ' (partial)' : ''}\`;
      } else {
        feeStatus = balance <= 0 ? 'Paid' : 'Partial';
      }
    } else if (paidAmount > 0) {
      feeStatus = balance <= 0 ? 'Paid' : 'Partial';
    }`;

content = content.replace(targetLogic, replacementLogic);
fs.writeFileSync('server.ts', content);
console.log("Patched server.ts feeStatus logic");
