const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rxModal = /\s*\{\/\* Telegram Modal \*\/\}[\s\S]*?<\/div>\s*<\/div>\s*\)\}\s*<\/div>\s*\)\;\s*\}/m;
const replacementModal = `\n    </div>\n  );\n}`;
if(rxModal.test(content)) {
  content = content.replace(rxModal, replacementModal);
  fs.writeFileSync('src/components/tabs/Exams.tsx', content);
  console.log('Removed modal from Exams.tsx');
} else {
  console.log('Could not find modal in Exams.tsx');
  const rxAlt = /\s*\{\/\* Telegram Modal \*\/\}[\s\S]*?<\/div>\s*<\/div>\s*\)\}\s*<\/>/m;
  if(rxAlt.test(content)) {
    console.log('Found with alt regex');
  } else {
    console.log('Alt regex failed too');
  }
}
