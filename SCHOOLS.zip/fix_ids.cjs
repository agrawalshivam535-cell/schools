const fs = require('fs');
const file = 'students.json';
let data = JSON.parse(fs.readFileSync(file, 'utf-8'));
let seen = new Set();
let newData = [];
for (let s of data) {
  if (!seen.has(s.id)) {
    seen.add(s.id);
    newData.push(s);
  } else {
    // Generate a unique ID for the duplicate
    s.id = 'STU' + Date.now() + Math.floor(Math.random()*1000);
    seen.add(s.id);
    newData.push(s);
  }
}
fs.writeFileSync(file, JSON.stringify(newData, null, 2));
console.log('Fixed students.json');
