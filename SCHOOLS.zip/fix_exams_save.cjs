const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rx = /body: JSON\.stringify\(\{\s*examName: selectedExam,\s*className: enterClass,\s*section: enterSection,\s*students\s*\}\)/m;
const replacement = `body: JSON.stringify({
          examName: selectedExam,
          className: enterClass,
          section: enterSection,
          students,
          maxMarks
        })`;

content = content.replace(rx, replacement);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Fixed Exams.tsx save-grid body');
