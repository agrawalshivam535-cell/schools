const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const uiSearch = `          <select 
            className="w-full sm:w-40 px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
            value={section}
            onChange={(e) => setSection(e.target.value)}
          >
            {sections.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>`;

const selectAllCode = `          <select 
            className="w-full sm:w-40 px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
            value={section}
            onChange={(e) => setSection(e.target.value)}
          >
            {sections.map(s => <option key={s}>{s}</option>)}
          </select>
          <button
            onClick={() => {
              if (selectedIds.length === students.length && students.length > 0) {
                setSelectedIds([]);
              } else {
                setSelectedIds(students.map(s => s.id));
              }
            }}
            className="px-4 py-3 bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 rounded-xl hover:bg-indigo-600/30 transition-colors whitespace-nowrap"
          >
            {selectedIds.length === students.length && students.length > 0 ? 'Deselect All' : 'Select All'}
          </button>
        </div>
      </div>`;

code = code.replace(uiSearch, selectAllCode);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched Select All");
