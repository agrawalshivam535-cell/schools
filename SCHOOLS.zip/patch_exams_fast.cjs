const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Rewrite loadResults to use the new endpoint
const rxLoadResults = /const loadResults = async \(\) => \{[\s\S]*?    \} catch \(err\) \{[\s\S]*?    \}\n  \};/m;

const newLoadResults = `const loadResults = async () => {
    setIsResultLoaded(false);
    try {
      let res;
      let data;
      
      let fullClassName = resultClass;
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        res = await fetch(\`/api/students?className=\${encodeURIComponent(fullClassName)}\`);
        data = await res.json();
      }
      
      const clsQuery = resultClass === 'All' ? 'All Classes' : fullClassName;
      const secQuery = resultClass === 'All' ? 'All Sections' : resultSection;
      const marksRes = await fetch(\`/api/marks/all?className=\${encodeURIComponent(clsQuery)}&section=\${encodeURIComponent(secQuery)}\`);
      const marksData = await marksRes.json();
      
      const STANDARD_SUBJECTS = ['Maths', 'Science', 'Hindi'];
      
      const studentsWithMarks = data.map((student: any) => {
        const studentRawMarks = marksData[student.id] || [];
        const displayMarks = availableExams.map(examName => {
          const existingExam = studentRawMarks.find((m: any) => m.examName === examName);
          if (existingExam) return existingExam;
          return {
            examName,
            total: 0,
            obtained: 0,
            isBlank: true,
            subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
          };
        });
        return { ...student, examMarks: displayMarks };
      });
      
      setResultStudents(studentsWithMarks);
      setSelectedResults([]);
      setIsResultLoaded(true);
    } catch (err) {
      console.error(err);
    }
  };`;

content = content.replace(rxLoadResults, newLoadResults);

// 2. Fix downloadIndividualResult
const rxDownloadIndiv = /const downloadIndividualResult = async \(student: any\) => \{\s*setIsDownloading\(true\);\s*let marks = await getStudentMarks\(student\.id\);/m;
const newDownloadIndiv = `const downloadIndividualResult = async (student: any) => {
    setIsDownloading(true);
    let marks = student.examMarks || await getStudentMarks(student.id);`;
content = content.replace(rxDownloadIndiv, newDownloadIndiv);

// 3. Fix sendTelegramResult
const rxSendTelegram = /const sendTelegramResult = async \(student: any\) => \{\s*setSendingTelegramId\(student\.id\);\s*try \{\s*let marks = await getStudentMarks\(student\.id\);/m;
const newSendTelegram = `const sendTelegramResult = async (student: any) => {
    setSendingTelegramId(student.id);
    try {
      let marks = student.examMarks || await getStudentMarks(student.id);`;
content = content.replace(rxSendTelegram, newSendTelegram);

// 4. Fix downloadBulkResults
const rxBulk = /let marks = await getStudentMarks\(id\);/m;
const newBulk = `let marks = student.examMarks || await getStudentMarks(id);`;
content = content.replace(rxBulk, newBulk);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Exams.tsx with fast fetching and reusing marks');
