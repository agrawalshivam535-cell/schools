const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /app\.post\("\/api\/exams\/save-grid"[\s\S]*?res\.json\(\{ success: true \}\);\n  \}\);/m;

const replacement = `app.post("/api/exams/save-grid", (req, res) => {
    const { examName, className, section, students, maxMarks } = req.body;
    
    const subjects = ["Maths", "Science", "Hindi", "English", "Social Science", "Computer"];
    
    subjects.forEach(subject => {
      // Find if we already have a record for this class/section/exam/subject
      let existingRecord = analysisRecords.find(ar => 
        ar.className === className && 
        (ar as any).section === section && 
        (ar as any).subject === subject && 
        (ar as any).examType === examName
      );
      
      const records = students.map((s: any) => {
        const objKey = subject === 'Social Science' ? 'socialScience' : subject.toLowerCase();
        const mark = s[objKey];
        if (!mark || mark === "" || mark === "0") return null;
        return {
          id: s.id,
          name: s.name,
          totalMarks: String(maxMarks || 100),
          marksObtained: String(mark)
        };
      }).filter(Boolean);
      
      if (records.length === 0) return;
      
      if (existingRecord) {
        // Update records within the existing analysis record
        records.forEach((newRec: any) => {
          const idx = (existingRecord as any).records.findIndex((r: any) => r.id === newRec.id);
          if (idx !== -1) {
            (existingRecord as any).records[idx].marksObtained = newRec.marksObtained;
            (existingRecord as any).records[idx].totalMarks = newRec.totalMarks;
          } else {
            (existingRecord as any).records.push(newRec);
          }
        });
        (existingRecord as any).timestamp = new Date().toISOString();
      } else {
        analysisRecords.push({
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
          className,
          section,
          subject,
          examType: examName,
          timestamp: new Date().toISOString(),
          records
        });
      }
    });
    
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });`;

if (!regex.test(code)) {
  console.error("Regex did not match in server.ts!");
  process.exit(1);
}

code = code.replace(regex, replacement);
fs.writeFileSync('server.ts', code);
console.log("Patched server.ts (save-grid)");
