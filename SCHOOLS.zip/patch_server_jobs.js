import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf-8');

const regex = /let examJobs: ExamJob\[\] = \[\];[\s\S]*?app\.get\("\/api\/exams\/jobs", \(req, res\) => \{/m;

const replacement = `let examJobs: ExamJob[] = [];
  try { examJobs = JSON.parse(fs.readFileSync('./examJobs.json', 'utf-8')); } catch(e) {}

  app.post("/api/exams/jobs/upload", (req, res) => {
    const job: ExamJob = {
      id: Date.now().toString(),
      filename: req.body.filename || 'document.pdf',
      className: req.body.className,
      section: req.body.section,
      subject: req.body.subject,
      examType: req.body.examType,
      maxMarks: req.body.maxMarks || '100',
      status: 'processing',
      timestamp: new Date().toISOString()
    };
    examJobs.push(job);
    saveDb('examJobs.json', examJobs);

    // AI processing asynchronously in the background
    const processAI = async () => {
      try {
        const { fileData, mimeType } = req.body;
        const prompt = "Class: " + job.className + "\\nSection: " + job.section + "\\nSubject: " + job.subject + "\\nExam: " + job.examType + "\\nTotal: " + job.maxMarks + "\\nExtract rollNumber, name, totalMarks (" + job.maxMarks + "), marksObtained in JSON array. Ensure the properties in the JSON objects are exactly \\"rollNumber\\", \\"name\\", \\"totalMarks\\", \\"marksObtained\\".";
        
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) throw new Error("GEMINI_API_KEY is not set on the server.");

        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [
            { role: 'user', parts: [
              { inlineData: { mimeType: mimeType || 'image/jpeg', data: fileData } },
              { text: prompt }
            ]}
          ],
          config: { responseMimeType: 'application/json' }
        });

        if (!response.text) throw new Error("No response from Gemini");
        const records = JSON.parse(response.text);
        
        // Enrich with existing names from mock DB
        const enriched = records.map((r: any) => {
          const studentClass = job.className + ' - ' + job.section;
          const student = students.find(s => 
            String(s.rollNumber) === String(r.rollNumber) && 
            s.className === studentClass
          );
          return {
            id: student ? student.id : (r.id || 'Unknown'),
            rollNumber: r.rollNumber,
            name: student ? student.name : r.name || 'Not Found',
            totalMarks: r.totalMarks || job.maxMarks,
            marksObtained: r.marksObtained,
            previousMarks: null
          };
        });

        const idx = examJobs.findIndex(j => j.id === job.id);
        if (idx !== -1) {
          examJobs[idx].status = 'pending_verification';
          examJobs[idx].records = enriched;
          saveDb('examJobs.json', examJobs);
        }
      } catch (err) {
        console.error("Background processing error:", err);
        // Could set a failed status here, but for now just log it
      }
    };
    
    // Start background processing
    processAI();

    res.json({ success: true, job });
  });

  app.get("/api/exams/jobs", (req, res) => {`;

code = code.replace(regex, replacement);

// We should also patch the job removal routes to save to disk.
code = code.replace(
  "      examJobs.splice(jobIndex, 1);\n      res.json({ success: true });",
  "      examJobs.splice(jobIndex, 1);\n      saveDb('examJobs.json', examJobs);\n      res.json({ success: true });"
);

code = code.replace(
  "    examJobs = examJobs.filter(j => j.id !== req.params.id);\n    res.json({ success: true });",
  "    examJobs = examJobs.filter(j => j.id !== req.params.id);\n    saveDb('examJobs.json', examJobs);\n    res.json({ success: true });"
);

fs.writeFileSync('server.ts', code);
