import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

code = code.replace("await fetch('/api/exams/save', {, {", "await fetch('/api/exams/save', {");

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
