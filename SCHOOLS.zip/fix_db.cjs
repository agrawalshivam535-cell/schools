const fs = require('fs');
let students = JSON.parse(fs.readFileSync('students.json', 'utf8'));

students = students.map(s => {
  const norm = { ...s };
  if (s["Father's Name"]) { norm.fatherName = s["Father's Name"]; delete norm["Father's Name"]; }
  if (s["Mother's Name"]) { norm.motherName = s["Mother's Name"]; delete norm["Mother's Name"]; }
  if (s["Blood Group"]) { norm.bloodGroup = s["Blood Group"]; delete norm["Blood Group"]; }
  if (s["Admission Date"]) { norm.admissionDate = s["Admission Date"]; delete norm["Admission Date"]; }
  if (s["City"]) { norm.city = s["City"]; delete norm["City"]; }
  if (s["State"]) { norm.state = s["State"]; delete norm["State"]; }
  if (s["PIN Code"]) { norm.pinCode = s["PIN Code"]; delete norm["PIN Code"]; }
  if (s["Atudent ID"]) { norm.id = s["Atudent ID"]; delete norm["Atudent ID"]; } // Typos in their csv header
  return norm;
});

fs.writeFileSync('students.json', JSON.stringify(students, null, 2));
console.log("Fixed students.json");
