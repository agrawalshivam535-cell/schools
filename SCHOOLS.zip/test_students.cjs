const fs = require('fs');
let data = JSON.parse(fs.readFileSync('students.json', 'utf8'));
let set = new Set(data.map(s => s.id));
if (set.size !== data.length) {
  console.log("Duplicate student ID!");
} else {
  console.log("No duplicate student ID.");
}
