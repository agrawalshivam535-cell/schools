const fs = require('fs');
let data = JSON.parse(fs.readFileSync('feeStructures.json', 'utf8'));
let set = new Set(data.map(s => s.id));
if (set.size !== data.length) {
  console.log("Duplicate fee ID!");
} else {
  console.log("No duplicate fee ID.");
}
