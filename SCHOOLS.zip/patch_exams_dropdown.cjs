const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rxFetchExams = /const uniqueExams = Array\.from\(new Set\(data\.map\(\(r: any\) => r\.examType\)\)\)\.sort\(\) as string\[\];/m;
const newFetchExams = `const defaultExams = ['Unit Test 1', 'Unit Test 2', 'Mid-year', 'Annual'];
        const uniqueExams = Array.from(new Set([...defaultExams, ...data.map((r: any) => r.examType)])).sort() as string[];`;

content = content.replace(rxFetchExams, newFetchExams);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Exams.tsx to include default exams in availableExams');
