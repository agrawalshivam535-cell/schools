import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Add useClasses
if (!code.includes("useClasses")) {
  code = "import { useClasses } from '../../hooks/useClasses';\n" + code;
}

// 2. States & Initializer
const oldStates = `  // Enter Marks state
  const [selectedExam, setSelectedExam] = useState('Unit Test 1');
  const [selectedClass, setSelectedClass] = useState('10 - B');
  const [isGridLoaded, setIsGridLoaded] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [students, setStudents] = useState<StudentMarks[]>([]);

  // Results state
  const [resultClass, setResultClass] = useState('10 - B');
  const [resultExamType, setResultExamType] = useState('Full Result');
  const [isResultLoaded, setIsResultLoaded] = useState(false);
  const [resultStudents, setResultStudents] = useState<any[]>([]);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);`;

const newStates = `  const { classes } = useClasses();
  const baseClasses = Array.from(new Set(classes.map(c => c.split(' - ')[0])));
  const sections = Array.from(new Set(classes.map(c => c.split(' - ')[1] || 'A'))).sort();

  // Enter Marks state
  const [selectedExam, setSelectedExam] = useState('Unit Test 1');
  const [enterClass, setEnterClass] = useState('');
  const [enterSection, setEnterSection] = useState('');
  const [isGridLoaded, setIsGridLoaded] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [students, setStudents] = useState<StudentMarks[]>([]);

  // Results state
  const [resultClass, setResultClass] = useState('');
  const [resultSection, setResultSection] = useState('');
  const [resultExamType, setResultExamType] = useState('Full Result');
  const [isResultLoaded, setIsResultLoaded] = useState(false);
  const [resultStudents, setResultStudents] = useState<any[]>([]);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);

  import { useEffect as UseEffectExams } from 'react';
  UseEffectExams(() => {
    if (classes.length > 0) {
      const cls = classes[0].split(' - ')[0];
      const sec = classes[0].split(' - ')[1] || 'A';
      if (!enterClass) setEnterClass(cls);
      if (!enterSection) setEnterSection(sec);
      if (!resultClass) setResultClass(cls);
      if (!resultSection) setResultSection(sec);
    }
  }, [classes, enterClass, enterSection, resultClass, resultSection]);`;

code = code.replace(oldStates, newStates);

// Global rename history -> hindi and History -> Hindi
code = code.replace(/history/g, 'hindi');
code = code.replace(/History/g, 'Hindi');

// 3. calculateTotal
code = code.replace(
  /const calculateTotal = \(student: StudentMarks\) => \{[\s\S]*?return m \+ s \+ h;\n  \};/,
  `const calculateTotal = (student: StudentMarks) => {
    const m = parseInt(student.maths) || 0;
    const s = parseInt(student.science) || 0;
    const h = parseInt(student.hindi) || 0;
    return m + s + h;
  };`
);

// 4. loadGrid
code = code.replace(
  /const res = await fetch\(\`\/api\/students\?className=\$\{encodeURIComponent\('Class ' \+ selectedClass\.split\(' - '\)\[0\] \+ ' - ' \+ selectedClass\.split\(' - '\)\[1\]\)\}\`\);\n      const data = await res\.json\(\);\n      \n      const formattedStudents = data\.map\(\(s: any\) => \(\{\n        id: s\.id,\n        name: s\.name,\n        maths: '',\n        science: '',\n        hindi: ''\n      \}\)\);/,
  `const res = await fetch(\`/api/students?className=\${encodeURIComponent(enterClass)}\`);
      const data = await res.json();
      
      const filtered = data.filter((s: any) => s.section === enterSection);
      const formattedStudents = filtered.map((s: any) => ({
        id: s.id,
        rollNumber: s.rollNumber,
        name: s.name,
        maths: '',
        science: '',
        hindi: ''
      }));`
);

// 5. save marks
code = code.replace(
  /className: 'Class ' \+ selectedClass\.split\(' - '\)\[0\] \+ ' - ' \+ selectedClass\.split\(' - '\)\[1\],\n          section: selectedClass\.split\(' - '\)\[1\],/,
  `className: enterClass,\n          section: enterSection,`
);

// 6. result load
code = code.replace(
  /const res = await fetch\(\`\/api\/students\?className=\$\{encodeURIComponent\('Class ' \+ resultClass\.split\(' - '\)\[0\] \+ ' - ' \+ resultClass\.split\(' - '\)\[1\]\)\}\`\);\n      const data = await res\.json\(\);/,
  `const res = await fetch(\`/api/students?className=\${encodeURIComponent(resultClass)}\`);
      let data = await res.json();
      data = data.filter((s: any) => s.section === resultSection);`
);

// 7. Update UI for Enter Marks dropdowns
const oldDropdownUI = `<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>
                <div className="relative">
                  <select
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                    value={selectedClass}
                    onChange={(e) => {
                      setSelectedClass(e.target.value);
                      setIsGridLoaded(false);
                      setIsSaved(false);
                    }}
                  >
                    <option value="10 - A" className="bg-[#151515]">10 - A</option>
                    <option value="10 - B" className="bg-[#151515]">10 - B</option>
                    <option value="10 - C" className="bg-[#151515]">10 - C</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>`;
const newDropdownUI = `<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <select
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                      value={enterClass}
                      onChange={(e) => {
                        setEnterClass(e.target.value);
                        setIsGridLoaded(false);
                        setIsSaved(false);
                      }}
                    >
                      {baseClasses.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                  <div className="relative flex-1">
                    <select
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                      value={enterSection}
                      onChange={(e) => {
                        setEnterSection(e.target.value);
                        setIsGridLoaded(false);
                        setIsSaved(false);
                      }}
                    >
                      {sections.map(s => <option key={s} value={s} className="bg-[#151515]">{s}</option>)}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>`;
code = code.replace(oldDropdownUI, newDropdownUI);

// 8. Update Enter Marks Grid headers
const oldGridHeaders = `<th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap">Total</th>`;
const newGridHeaders = `<th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>`;
code = code.replace(oldGridHeaders, newGridHeaders);

// 9. Update Grid row inputs
const oldGridRow = `<td className="p-4 text-gray-300 text-sm">
                            {student.name}
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.maths}
                              onChange={(e) => handleMarkChange(student.id, 'maths', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.science}
                              onChange={(e) => handleMarkChange(student.id, 'science', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.hindi}
                              onChange={(e) => handleMarkChange(student.id, 'hindi', e.target.value)}
                            />
                          </td>
                          <td className="p-4 font-bold text-white">
                            {calculateTotal(student)}
                          </td>`;
const newGridRow = `<td className="p-4 text-gray-400 text-sm font-medium">
                            {student.rollNumber}
                          </td>
                          <td className="p-4 text-gray-200 text-sm font-medium">
                            {student.name}
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.maths}
                              onChange={(e) => handleMarkChange(student.id, 'maths', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.science}
                              onChange={(e) => handleMarkChange(student.id, 'science', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.hindi}
                              onChange={(e) => handleMarkChange(student.id, 'hindi', e.target.value)}
                            />
                          </td>
                          <td className="p-4 font-bold text-emerald-400 text-lg">
                            {calculateTotal(student)}
                          </td>`;
code = code.replace(oldGridRow, newGridRow);

// 10. Update Results dropdown
const oldResultDropdown = `<select
                          className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                          value={resultClass}
                          onChange={(e) => {
                            setResultClass(e.target.value);
                            setIsResultLoaded(false);
                          }}
                        >
                          <option value="10 - A" className="bg-[#151515]">10 - A</option>
                          <option value="10 - B" className="bg-[#151515]">10 - B</option>
                          <option value="10 - C" className="bg-[#151515]">10 - C</option>
                        </select>`;
const newResultDropdown = `<div className="flex gap-2">
                          <div className="relative flex-1">
                            <select
                              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                              value={resultClass}
                              onChange={(e) => {
                                setResultClass(e.target.value);
                                setIsResultLoaded(false);
                              }}
                            >
                              {baseClasses.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                            </div>
                          </div>
                          <div className="relative flex-1">
                            <select
                              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                              value={resultSection}
                              onChange={(e) => {
                                setResultSection(e.target.value);
                                setIsResultLoaded(false);
                              }}
                            >
                              {sections.map(s => <option key={s} value={s} className="bg-[#151515]">{s}</option>)}
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                            </div>
                          </div>
                        </div>`;
code = code.replace(oldResultDropdown, newResultDropdown);

// 11. interface StudentMarks add rollNumber
if (!code.includes("rollNumber?: string;")) {
  code = code.replace("interface StudentMarks {", "interface StudentMarks {\n  rollNumber?: string;");
}

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Exams.tsx patched');
