const fs = require('fs');
let data = JSON.parse(fs.readFileSync('staff.json', 'utf8'));
let set = new Set(data.map(s => s.id));
if (set.size !== data.length) {
  console.log("Duplicate staff ID!");
} else {
  console.log("No duplicate staff ID.");
}
