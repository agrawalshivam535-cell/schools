const fs = require('fs');
let data = JSON.parse(fs.readFileSync('students.json', 'utf-8'));
let seen = new Set();
let newData = [];
for (let s of data) {
  if (!seen.has(s.id)) {
    seen.add(s.id);
    newData.push(s);
  } else {
    s.id = 'STU' + Date.now() + Math.floor(Math.random()*1000);
    seen.add(s.id);
    newData.push(s);
  }
}
fs.writeFileSync('students.json', JSON.stringify(newData, null, 2));
console.log('Fixed students.json');
