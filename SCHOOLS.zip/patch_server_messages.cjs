const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

// 1. Add telegramMessages to DB loading
const dbLoadCode = `
let telegramMessages: any[] = [];
try { telegramMessages = JSON.parse(fs.readFileSync('./telegramMessages.json', 'utf-8')); } catch(e) {}
`;

if (!content.includes('let telegramMessages: any[] = [];')) {
  content = content.replace(
    "let feePayments: any[] = [];\ntry { feePayments = JSON.parse(fs.readFileSync('./feePayments.json', 'utf-8')); } catch(e) {}\n",
    "let feePayments: any[] = [];\ntry { feePayments = JSON.parse(fs.readFileSync('./feePayments.json', 'utf-8')); } catch(e) {}\n" + dbLoadCode
  );
}

// 2. Add message logging logic in webhook
const webhookPattern = /const chatId = body\.message\.chat\.id;/;
const messageLogCode = `const chatId = body.message.chat.id;

        // Log the message
        const incomingMsg = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
          date: new Date().toISOString(),
          chatId: chatId,
          username: body.message.from?.username || body.message.from?.first_name || 'Unknown',
          text: body.message.text || (body.message.contact ? '📱 Shared Contact: ' + body.message.contact.phone_number : 'Attachment/Other')
        };
        telegramMessages.unshift(incomingMsg);
        if (telegramMessages.length > 200) telegramMessages.length = 200;
        saveDb('telegramMessages.json', telegramMessages);
`;
content = content.replace(webhookPattern, messageLogCode);

// 3. Add API route to fetch messages
const apiRouteCode = `
  app.get("/api/telegram/messages", (req, res) => {
    res.json(telegramMessages);
  });
`;

if (!content.includes('/api/telegram/messages')) {
  content = content.replace(
    'app.post("/api/telegram/send", async (req, res) => {',
    apiRouteCode + '\n  app.post("/api/telegram/send", async (req, res) => {'
  );
}

fs.writeFileSync('server.ts', content);
console.log("Patched server.ts");
