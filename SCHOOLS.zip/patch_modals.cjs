const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

// 1. Add states
const stateTarget = `  const [isPromoting, setIsPromoting] = useState(false);`;
const stateReplacement = `  const [isPromoting, setIsPromoting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [telegramDisconnectId, setTelegramDisconnectId] = useState<string | null>(null);`;
code = code.replace(stateTarget, stateReplacement);

// 2. Change disconnectTelegram
const telegramTarget = `  const disconnectTelegram = async (id: string) => {
    if (!confirm('Are you sure you want to disconnect Telegram for this student?')) return;
    try {
      const res = await fetch(\`/api/students/\${id}/disconnect-telegram\`, { method: 'POST' });
      if (res.ok) {
        setSelectedStudent((prev: any) => prev ? { ...prev, telegramChatId: '' } : prev);
        fetchStudents();
      } else {
        alert('Failed to disconnect telegram');
      }
    } catch (e) {
      if (String(e).includes("Failed to fetch")) return;
      console.error(e);
      alert('Error disconnecting telegram');
    }
  };`;

const telegramReplacement = `  const disconnectTelegram = async (id: string) => {
    try {
      const res = await fetch(\`/api/students/\${id}/disconnect-telegram\`, { method: 'POST' });
      if (res.ok) {
        setSelectedStudent((prev: any) => prev ? { ...prev, telegramChatId: '' } : prev);
        setTelegramDisconnectId(null);
        fetchStudents();
      }
    } catch (e) {
      if (String(e).includes("Failed to fetch")) return;
      console.error(e);
    }
  };`;
code = code.replace(telegramTarget, telegramReplacement);

// 3. Update handleDeleteSelected
const handleTarget = `  const handleDeleteSelected = async () => {
    if (selectedIds.length === 0) return;
    if (!confirm(\`Are you sure you want to delete \${selectedIds.length} student(s)? This action cannot be undone.\`)) return;
    
    try {
      const res = await fetch('/api/students/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentIds: selectedIds })
      });
      if (res.ok) {
        setSelectedIds([]);
        fetchStudents();
      } else {
        alert('Failed to delete students');
      }
    } catch (e) {
      console.error(e);
      alert('Error deleting students');
    }
  };`;
  
const handleReplacement = `  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    setShowDeleteConfirm(true);
  };

  const executeDeleteSelected = async () => {
    setIsDeleting(true);
    try {
      const res = await fetch('/api/students/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentIds: selectedIds })
      });
      if (res.ok) {
        setSelectedIds([]);
        setShowDeleteConfirm(false);
        fetchStudents();
      }
    } catch (e) {
      console.error(e);
    }
    setIsDeleting(false);
  };`;
code = code.replace(handleTarget, handleReplacement);

// 4. Add the Delete Modal before </> 
const modalTarget = `      )}
    </>
  );
}`;
const modalReplacement = `      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-2">Delete Students</h3>
            <p className="text-gray-400 mb-6">Are you sure you want to delete {selectedIds.length} student(s)? This action cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 rounded-xl text-gray-300 hover:bg-white/5 transition-colors"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                onClick={executeDeleteSelected}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white transition-colors flex items-center gap-2"
                disabled={isDeleting}
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}`;
code = code.replace(modalTarget, modalReplacement);

fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched confirmation modals");
