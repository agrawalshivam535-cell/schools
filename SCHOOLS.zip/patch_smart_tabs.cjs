const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `        let allRows: any[] = [];
        
        // Loop through all sheets in the file
        workbook.SheetNames.forEach(sheetName => {
          const sheet = workbook.Sheets[sheetName];
          const sheetRows = XLSX.utils.sheet_to_json(sheet);
          allRows = allRows.concat(sheetRows);
        });

        let rows = allRows;`;

const replacement = `        let allRows: any[] = [];
        let detectedHeaders: string[] = [];
        
        // Loop through all sheets in the file
        workbook.SheetNames.forEach((sheetName, index) => {
          const sheet = workbook.Sheets[sheetName];
          
          // Read sheet as an array of arrays to inspect the first row
          const aoa = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
          if (!aoa || aoa.length === 0) return;
          
          let sheetRows: any[];
          
          // Check if the first row looks like a header row
          const firstRow = aoa[0];
          const firstRowStr = firstRow.map(String).join(' ').toLowerCase();
          const hasHeaders = firstRowStr.includes('name') || firstRowStr.includes('class') || firstRowStr.includes('roll');
          
          if (hasHeaders || index === 0) {
            // It has headers (or it's the very first sheet, so we assume it defines the headers)
            detectedHeaders = firstRow.map(String);
            // Parse normally
            sheetRows = XLSX.utils.sheet_to_json(sheet);
          } else {
            // Missing headers! Use the headers from the first sheet
            sheetRows = XLSX.utils.sheet_to_json(sheet, { header: detectedHeaders });
            // The first row is actual data, so we keep it. sheet_to_json with header array includes the first row as data.
          }
          
          allRows = allRows.concat(sheetRows);
        });

        let rows = allRows;`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched multi-tab reading to handle missing headers on subsequent tabs");
