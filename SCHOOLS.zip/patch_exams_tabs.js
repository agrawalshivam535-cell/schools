import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// Add imports
code = code.replace("import { ProcessedDataList } from './ProcessedDataList';", "import { ProcessedDataList } from './ProcessedDataList';\nimport { ProcessingJobsList } from './ProcessingJobsList';\nimport { PendingVerificationList } from './PendingVerificationList';");

// Expand state
code = code.replace("const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload' | 'processed'>('enter');", "const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload' | 'processing' | 'pending' | 'processed'>('enter');");

// Update navigation
const navRegex = /<div className="flex gap-6 border-b border-white\/10 mb-8 overflow-x-auto">[\s\S]*?<\/div>/;
// Wait, is it overflow-x-auto? Let me just search for the nav wrapper.
