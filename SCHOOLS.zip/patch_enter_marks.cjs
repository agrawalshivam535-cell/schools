const fs = require('fs');

function patchEnterMarks() {
  let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

  // Update Enter Marks Table Headers
  content = content.replace(
    /<th className="p-4 whitespace-nowrap">Maths<\/th>\s*<th className="p-4 whitespace-nowrap">Science<\/th>\s*<th className="p-4 whitespace-nowrap">Hindi<\/th>/,
    `<th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap">English</th>
                        <th className="p-4 whitespace-nowrap">Social Science</th>
                        <th className="p-4 whitespace-nowrap">Computer</th>`
  );

  // Update Enter Marks Table Data Cells
  const hindiInput = `<td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.hindi}
                              onChange={(e) => handleMarkChange(student.id, 'hindi', e.target.value)}
                            />
                          </td>`;
  
  const additionalInputs = `
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.english}
                              onChange={(e) => handleMarkChange(student.id, 'english', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.socialScience}
                              onChange={(e) => handleMarkChange(student.id, 'socialScience', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.computer}
                              onChange={(e) => handleMarkChange(student.id, 'computer', e.target.value)}
                            />
                          </td>`;

  content = content.replace(hindiInput, hindiInput + additionalInputs);

  // Update logic where student marks are initialized from the backend API
  const getSubInit = /maths: getSub\('Maths'\),\s*science: getSub\('Science'\),\s*hindi: getSub\('Hindi'\)/;
  content = content.replace(getSubInit, 
    `maths: getSub('Maths'),
          science: getSub('Science'),
          hindi: getSub('Hindi'),
          english: getSub('English'),
          socialScience: getSub('Social Science'),
          computer: getSub('Computer')`
  );

  const initObj = /maths: '',\s*science: '',\s*hindi: ''/;
  content = content.replace(initObj, 
    `maths: '',
          science: '',
          hindi: '',
          english: '',
          socialScience: '',
          computer: ''`
  );

  // Update save logic
  const saveRecords = /const records = students\.map\(s => \(\{\s*studentId: s\.id,\s*subjects: \[\s*\{ name: 'Maths', obtained: s\.maths \|\| '-' \},\s*\{ name: 'Science', obtained: s\.science \|\| '-' \},\s*\{ name: 'Hindi', obtained: s\.hindi \|\| '-' \}\s*\]\s*\}\)\);/m;
  content = content.replace(saveRecords, 
    `const records = students.map(s => ({
      studentId: s.id,
      subjects: [
        { name: 'Maths', obtained: s.maths || '-' },
        { name: 'Science', obtained: s.science || '-' },
        { name: 'Hindi', obtained: s.hindi || '-' },
        { name: 'English', obtained: s.english || '-' },
        { name: 'Social Science', obtained: s.socialScience || '-' },
        { name: 'Computer', obtained: s.computer || '-' }
      ]
    }));`
  );
  
  // Total logic
  const totalLogic = /const total = \[s\.maths, s\.science, s\.hindi\]/m;
  content = content.replace(totalLogic, `const total = [s.maths, s.science, s.hindi, s.english, s.socialScience, s.computer]`);

  fs.writeFileSync('src/components/tabs/Exams.tsx', content);
}

patchEnterMarks();
console.log('Patched Enter Marks table in Exams.tsx');
