const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

content = content.replace(
  /if \(res\.ok\) \{\s*setPaymentForm\(null\);\s*viewStudentDetails\(selectedStudent\.student\.id\);\s*\} else \{\s*.*?\s*\}/,
  ""
); // clear any existing just in case, though there isn't an else

const oldBlock = `      if (res.ok) {
        setPaymentForm(null);
        viewStudentDetails(selectedStudent.student.id);
      }`;

const newBlock = `      if (res.ok) {
        setPaymentForm(null);
        viewStudentDetails(selectedStudent.student.id);
      } else {
        const data = await res.json();
        alert(data.message || 'Failed to record payment');
      }`;

content = content.replace(oldBlock, newBlock);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx with payment error alert");
