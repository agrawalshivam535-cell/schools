const fs = require('fs');
const files = [
  'src/components/tabs/Integrations.tsx',
  'src/components/tabs/ProcessingJobsList.tsx',
  'src/hooks/useClasses.ts'
];

files.forEach(file => {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf-8');
    // For integrations
    content = content.replace(
      'console.error(e);',
      '// Silently ignore network errors during server reboots\n      if (String(e).includes("Failed to fetch")) return;\n      console.error(e);'
    );
    // For processing jobs
    content = content.replace(
      'console.error("Failed to fetch jobs", e);',
      'if (String(e).includes("Failed to fetch")) return;\n      console.error("Failed to fetch jobs", e);'
    );
    fs.writeFileSync(file, content);
  }
});
console.log("Patched silent catches");
