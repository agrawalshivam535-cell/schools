import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

// 1. Update Props
code = code.replace(
  "interface UploadMarksProps {\n  initialRecord?: ProcessedRecord;\n  onBack?: () => void;\n}",
  "interface UploadMarksProps {\n  initialRecord?: ProcessedRecord;\n  pendingJob?: any;\n  onBack?: () => void;\n  onUploadSuccess?: () => void;\n}"
);

code = code.replace(
  "export function UploadMarks({ initialRecord, onBack }: UploadMarksProps = {}) {",
  "export function UploadMarks({ initialRecord, pendingJob, onBack, onUploadSuccess }: UploadMarksProps = {}) {"
);

// 2. Initialize State with pendingJob as well
code = code.replace(
  "  const [uploadClass, setUploadClass] = useState(initialRecord?.className || '');",
  "  const [uploadClass, setUploadClass] = useState(initialRecord?.className || pendingJob?.className || '');"
);
code = code.replace(
  "  const [uploadSection, setUploadSection] = useState(initialRecord?.section || '');",
  "  const [uploadSection, setUploadSection] = useState(initialRecord?.section || pendingJob?.section || '');"
);
code = code.replace(
  "  const [uploadSubject, setUploadSubject] = useState(initialRecord?.subject || 'Maths');",
  "  const [uploadSubject, setUploadSubject] = useState(initialRecord?.subject || pendingJob?.subject || 'Maths');"
);
code = code.replace(
  "  const [uploadExamType, setUploadExamType] = useState(initialRecord?.examType || 'Unit Test 1');",
  "  const [uploadExamType, setUploadExamType] = useState(initialRecord?.examType || pendingJob?.examType || 'Unit Test 1');"
);
code = code.replace(
  "  const [uploadMaxMarks, setUploadMaxMarks] = useState(initialRecord?.records?.[0]?.totalMarks || '100');",
  "  const [uploadMaxMarks, setUploadMaxMarks] = useState(initialRecord?.records?.[0]?.totalMarks || pendingJob?.records?.[0]?.totalMarks || pendingJob?.maxMarks || '100');"
);
code = code.replace(
  "  const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(initialRecord?.records || null);",
  "  const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(initialRecord?.records || pendingJob?.records || null);"
);

// 3. Update handleUpload function
const oldHandleUpload = `
  const handleUpload = () => {
    if (!file) return;
    setIsUploading(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const classStudents = students.filter(s => s.className === \`\${uploadClass} - \${uploadSection}\`);
      
      const simulatedData = classStudents.map(s => ({
        id: s.id,
        rollNumber: s.rollNumber,
        name: s.name,
        totalMarks: uploadMaxMarks,
        marksObtained: Math.floor(Math.random() * parseInt(uploadMaxMarks)).toString()
      }));
      
      setAnalyzedData(simulatedData);
      setIsUploading(false);
    }, 2000);
  };
`;

const newHandleUpload = `
  const handleUpload = async () => {
    if (!file) return;
    setIsUploading(true);
    
    try {
      await fetch('/api/exams/jobs/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: file.name,
          className: uploadClass,
          section: uploadSection,
          subject: uploadSubject,
          examType: uploadExamType,
          maxMarks: uploadMaxMarks
        })
      });
      setIsUploading(false);
      if (onUploadSuccess) onUploadSuccess();
    } catch (err) {
      console.error(err);
      setIsUploading(false);
    }
  };
`;
// Replace carefully, keeping in mind students might not be imported if it wasn't. Actually it fetched them before, let's just use regex.

code = code.replace(/const handleUpload = \(\) => \{[\s\S]*?\}, 2000\);\s*\};/, newHandleUpload.trim());

// 4. Update save Data to use pendingJob branch
const saveUpdate = `
    try {
      if (initialRecord) {
        await fetch('/api/exams/analysis/' + initialRecord.id, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData
          })
        });
      } else if (pendingJob) {
        await fetch('/api/exams/jobs/' + pendingJob.id + '/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData
          })
        });
      } else {
        await fetch('/api/exams/save', {
`;
code = code.replace(/try \{\s*if \(initialRecord\) \{[\s\S]*?\} else \{[\s\S]*?await fetch\('\/api\/exams\/save'/m, saveUpdate.trim());

// Fix the button title condition
code = code.replace("initialRecord ? \"Update Data\" : \"Save Uploaded Data\"", "(initialRecord || pendingJob) ? \"Verify and Update\" : \"Save Uploaded Data\"");

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
