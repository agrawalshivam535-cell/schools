import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const oldBtn = `
            {activeTab === 'upload' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>
`;

const newBtn = `
            {activeTab === 'upload' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('processed')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'processed' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Processed Data
            {activeTab === 'processed' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>
`;

code = code.replace(oldBtn.trim(), newBtn.trim());
fs.writeFileSync('src/components/tabs/Exams.tsx', code);
