const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `<div className="flex gap-3">
          
          {selectedIds.length > 0 && (`;

const replacement = `<div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              if (selectedIds.length === students.length && students.length > 0) {
                setSelectedIds([]);
              } else {
                setSelectedIds(students.map(s => s.id));
              }
            }}
            className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/20 px-4 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            {selectedIds.length === students.length && students.length > 0 ? 'Deselect All' : 'Select All'}
          </button>
          
          {selectedIds.length > 0 && (`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched action bar");
