import fs from 'fs';

let code = fs.readFileSync('server.ts', 'utf-8');
const oldAnalyze = `      const enriched = records.map((r: any) => {
        const student = students.find(s => String(s.id) === String(r.id));
        return {
          id: r.id,
          name: student ? student.name : r.name || 'Not Found',
          totalMarks: r.totalMarks || answers.q5,
          marksObtained: r.marksObtained,
          previousMarks: null
        };
      });`;

const newAnalyze = `      const enriched = records.map((r: any) => {
        // AI returns rollNumber, we should match by rollNumber and className/section
        const studentClass = answers.q1 + ' - ' + answers.q2;
        const student = students.find(s => 
          String(s.rollNumber) === String(r.rollNumber) && 
          s.className === studentClass
        );
        return {
          id: student ? student.id : (r.id || 'Unknown'),
          rollNumber: r.rollNumber,
          name: student ? student.name : r.name || 'Not Found',
          totalMarks: r.totalMarks || answers.q5,
          marksObtained: r.marksObtained,
          previousMarks: null
        };
      });`;

code = code.replace(oldAnalyze, newAnalyze);

// Let's also change the Gemini model to gemini-2.5-pro for better handwriting OCR
code = code.replace("model: 'gemini-2.5-flash',", "model: 'gemini-2.5-pro',");

// And ensure prompt tells it to return rollNumber
code = code.replace(
  'Extract rollNumber, name, totalMarks (" + answers.q5 + "), marksObtained in JSON array."',
  'Extract rollNumber, name, totalMarks (" + answers.q5 + "), marksObtained in JSON array. Ensure the properties in the JSON objects are exactly \\"rollNumber\\", \\"name\\", \\"totalMarks\\", \\"marksObtained\\"."'
);

fs.writeFileSync('server.ts', code);
console.log('patched analyze');
