const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

content = content.replace(
  /onClick=\{\(\) => downloadFeeLedger\(selectedStudent, fees\)\}/g,
  "onClick={() => downloadFeeLedger(student, fees)}"
);

content = content.replace(
  /onClick=\{\(\) => sendFeeLedgerTelegram\(selectedStudent, fees\)\}/g,
  "onClick={() => sendFeeLedgerTelegram(student, fees)}"
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log('Fixed arguments');
