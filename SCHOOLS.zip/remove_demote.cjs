const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

const demoteButtonCode = `<button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e, 'demote')}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        Demote
                      </button>`;

content = content.replace(demoteButtonCode, '');

// Also remove the <> and </> wrapper if we can easily find it, but leaving it is fine too since Fragments are harmless.
content = content.replace(/<>\s*<button/g, '<button');
content = content.replace(/<\/button>\s*<\/>/g, '</button>');

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Removed Demote button");
