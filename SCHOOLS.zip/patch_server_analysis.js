import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf-8');

const idPatch = `
  app.post("/api/exams/save", (req, res) => {
    const { answers, records } = req.body;
    analysisRecords.push({
      id: Date.now().toString(),
      className: answers.q1,
      section: answers.q2,
      subject: answers.q3,
      examType: answers.q4,
      timestamp: new Date().toISOString(),
      records
    });
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });

  app.get("/api/exams/analysis", (req, res) => {
    // Send full array so frontend can have details
    const summary = analysisRecords.map(a => ({
      id: a.id || a.timestamp, // fallback for old records
      className: a.className,
      section: a.section,
      subject: a.subject,
      examType: a.examType,
      timestamp: a.timestamp,
      records: a.records
    }));
    res.json(summary);
  });

  app.put("/api/exams/analysis/:id", (req, res) => {
    const { answers, records } = req.body;
    const idx = analysisRecords.findIndex(a => (a.id || a.timestamp) === req.params.id);
    if (idx !== -1) {
      analysisRecords[idx] = {
        ...analysisRecords[idx],
        className: answers.q1,
        section: answers.q2,
        subject: answers.q3,
        examType: answers.q4,
        records
      };
      saveDb('analysis.json', analysisRecords);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });

  app.delete("/api/exams/analysis/:id", (req, res) => {
    analysisRecords = analysisRecords.filter(a => (a.id || a.timestamp) !== req.params.id);
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });
`;

// Replace existing save and get analysis
code = code.replace(/app\.post\("\/api\/exams\/save", \(req, res\) => \{[\s\S]*?app\.get\("\/api\/exams\/analysis", \(req, res\) => \{[\s\S]*?\}\);/g, idPatch.trim());

fs.writeFileSync('server.ts', code);
