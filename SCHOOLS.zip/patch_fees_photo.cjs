const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

const nameCell = `<td className="p-4 font-medium text-white">{s.name}</td>`;
const avatarNameCell = `<td className="p-4 font-medium text-white">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                            {s.photo ? (
                              <img src={s.photo} alt={s.name} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-xs font-bold text-indigo-300">{s.name.charAt(0)}</span>
                            )}
                          </div>
                          {s.name}
                        </div>
                      </td>`;

content = content.replace(nameCell, avatarNameCell);
fs.writeFileSync('src/components/tabs/Fees.tsx', content);
console.log("Patched Fees");
