const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf8');

const targetStr1 = `      if (data.job && data.job.id) {
        let isDone = false;
        let jobResult = null;
        while (!isDone) {
          await new Promise(r => setTimeout(r, 2000));
          const jobsRes = await fetch('/api/exams/jobs');
          if (jobsRes.ok) {
             const jobs = await jobsRes.json();
             const job = jobs.find((j: any) => j.id === data.job.id);
             if (job && (job.status === 'pending_verification' || job.status === 'error')) {
                isDone = true;
                jobResult = job;
             }
          }
        }
        
        if (jobResult && jobResult.status === 'pending_verification' && jobResult.records) {
           data = jobResult.records;
        } else {
           setIsUploading(false);
           alert("Failed to process document: " + (jobResult?.errorMsg || "Unknown error"));
           return;
        }
      }

      setIsUploading(false);
      // We removed the early return so it proceeds to populate the UI`;

const replaceStr1 = `      setIsUploading(false);
      if (onUploadSuccess) onUploadSuccess();
      return; // Stop processing in UI, wait in background`;

if (code.includes(targetStr1)) {
    code = code.replace(targetStr1, replaceStr1);
    fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
    console.log("Successfully reverted polling block in UploadMarks.tsx");
} else {
    console.log("Could not find the exact polling block string. Dumping surrounding context:");
}

