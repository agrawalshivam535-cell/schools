const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Timetable.tsx', 'utf-8');

const oldHandleOpen = `  const handleOpenAssign = (period: number, day: string) => {
    setAssignSlot({ period, day });
    setSubject('');
    setTeacher('');
  };`;

const newHandleOpen = `  const handleOpenAssign = (period: number, day: string, existingSubject: string = '', existingTeacher: string = '') => {
    setAssignSlot({ period, day });
    setSubject(existingSubject);
    setTeacher(existingTeacher);
  };`;

content = content.replace(oldHandleOpen, newHandleOpen);

const oldCellRender = `                    <td key={d} className="border-r border-white/5 last:border-0 align-middle p-2">
                      {cell ? (
                        <div className="p-2">
                          <span className="font-bold text-white block">{cell.subject}</span>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 rounded mt-1 inline-block">
                            {cell.teacher}
                          </span>
                        </div>
                      ) : (`;

const newCellRender = `                    <td key={d} className="border-r border-white/5 last:border-0 align-middle p-2">
                      {cell ? (
                        <div 
                          className="p-2 cursor-pointer hover:bg-white/5 rounded transition-colors group relative"
                          onClick={() => handleOpenAssign(p, d, cell.subject, cell.teacher)}
                        >
                          <span className="font-bold text-white block group-hover:text-indigo-300 transition-colors">{cell.subject}</span>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 rounded mt-1 inline-block group-hover:bg-emerald-500/20 transition-colors">
                            {cell.teacher}
                          </span>
                        </div>
                      ) : (`;

content = content.replace(oldCellRender, newCellRender);

fs.writeFileSync('src/components/tabs/Timetable.tsx', content);
console.log("Patched Timetable edit");
