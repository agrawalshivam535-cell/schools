const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/ProcessingJobsList.tsx', 'utf8');

const targetStr = `export function ProcessingJobsList() {`;
const replaceStr = `interface ProcessingJobsListProps {
  onJobComplete?: () => void;
}
export function ProcessingJobsList({ onJobComplete }: ProcessingJobsListProps = {}) {`;

code = code.replace(targetStr, replaceStr);

const fetchTarget = `      const data = await res.json();
      setJobs(data.filter((j: any) => j.status === 'processing' || j.status === 'error'));`;
      
const fetchReplace = `      const data = await res.json();
      const currentProcessing = data.filter((j: any) => j.status === 'processing' || j.status === 'error');
      
      // If we previously had processing jobs and now we have fewer, one might have completed.
      // A more reliable way: check if we have any pending_verification jobs now, 
      // AND we are about to set an empty processing list.
      setJobs((prevJobs) => {
        if (prevJobs.length > 0 && currentProcessing.length === 0) {
          const hasPending = data.some((j: any) => j.status === 'pending_verification');
          if (hasPending && onJobComplete) {
             setTimeout(onJobComplete, 500);
          }
        }
        return currentProcessing;
      });`;

if (code.includes(fetchTarget)) {
    code = code.replace(fetchTarget, fetchReplace);
    fs.writeFileSync('src/components/tabs/ProcessingJobsList.tsx', code);
    console.log("Patched ProcessingJobsList");
} else {
    console.log("Could not find fetchTarget");
}
