const fs = require('fs');

const csv = fs.readFileSync('data.csv', 'utf8');
const lines = csv.trim().split('\n');
const students = [];

// Skip header (i=1)
for (let i = 1; i < lines.length; i++) {
  const line = lines[i].trim();
  if (!line) continue;
  
  const values = line.split(',');
  const studentId = values[0];
  const rollNumber = values[1];
  const name = values[2];
  const classVal = values[3];
  const section = values[4];
  const gender = values[5];
  const parentPhone = values[6];

  const student = {
    id: studentId,
    name: name,
    rollNumber: rollNumber,
    className: 'Class ' + classVal + ' - ' + section,
    section: section,
    gender: gender,
    parentPhone: parentPhone,
    dob: '',
    bloodGroup: '',
    fatherName: '',
    motherName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pinCode: '',
    admissionDate: '',
    status: "Active Student"
  };
  
  students.push(student);
}

fs.writeFileSync('students.json', JSON.stringify(students, null, 2));
console.log('Successfully saved ' + students.length + ' students to students.json');
