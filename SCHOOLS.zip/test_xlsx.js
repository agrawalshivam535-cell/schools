const XLSX = require('xlsx');

// Create dummy workbook
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["name"], ["John"]]), "Sheet1");
XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["name"], ["Jane"]]), "Sheet2");

const out = XLSX.write(wb, { type: 'binary', bookType: 'xlsx' });

const readWb = XLSX.read(out, { type: 'binary' });
let allRows = [];
readWb.SheetNames.forEach(sheetName => {
  const sheet = readWb.Sheets[sheetName];
  allRows = allRows.concat(XLSX.utils.sheet_to_json(sheet));
});
console.log(allRows);
