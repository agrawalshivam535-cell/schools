const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `        // Filter out empty or invalid rows before sending to avoid massive payloads
        rows = rows.filter((r: any) => r.name && r.rollNumber && r.className);

        const res = await fetch('/api/students/bulk-csv', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ students: rows }),
        });

        if (res.ok) {
          const data = await res.json();
          
          // Extract the first valid class/section from the upload to auto-navigate
          const firstValid = rows.find((r: any) => r.className);
          if (firstValid) {
            setClassName(firstValid.className);
            if (firstValid.section) setSection(firstValid.section);
          }

          alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students from \${workbook.SheetNames.length} tabs.\`);
          fetchStudents();
        } else {
          const err = await res.json();
          alert('Failed to upload students: ' + (err.error || 'Unknown error'));
        }`;

const replacement = `        // Filter out empty or invalid rows before sending to avoid massive payloads
        rows = rows.filter((r: any) => r.name && r.rollNumber && r.className);

        let totalAdded = 0;
        let totalUpdated = 0;
        let hasError = false;

        // Chunk rows to prevent "Failed to fetch" due to payload size limits
        const chunkSize = 100;
        for (let i = 0; i < rows.length; i += chunkSize) {
          const chunk = rows.slice(i, i + chunkSize);
          const res = await fetch('/api/students/bulk-csv', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ students: chunk }),
          });

          if (res.ok) {
            const data = await res.json();
            totalAdded += data.added || 0;
            totalUpdated += data.updated || 0;
          } else {
            hasError = true;
            break;
          }
        }

        if (!hasError) {
          // Extract the first valid class/section from the upload to auto-navigate
          const firstValid = rows.find((r: any) => r.className);
          if (firstValid) {
            setClassName(firstValid.className);
            if (firstValid.section) setSection(firstValid.section);
          }

          alert(\`Successfully enrolled \${totalAdded} new students and updated \${totalUpdated} existing students from \${workbook.SheetNames.length} tabs.\`);
          fetchStudents();
        } else {
          alert('Failed to upload some students. Please try again.');
        }`;

if (!code.includes("rows = rows.filter((r: any)")) {
    console.error("Could not find target!");
    process.exit(1);
}
code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched to chunk uploads");
