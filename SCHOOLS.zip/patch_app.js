import fs from 'fs';
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// Insert AuthPage import
code = code.replace(
  "import { Staff } from './components/tabs/Staff';",
  "import { Staff } from './components/tabs/Staff';\nimport { AuthPage } from './components/AuthPage';"
);

// Update user state initialization to null
code = code.replace(
  "const [user, setUser] = useState<User | null>({ name: 'Admin User', email: 'admin@example.com' });",
  "const [user, setUser] = useState<User | null>(null);"
);

// Add the rendering wrapper at the bottom
const renderWrapper = `
  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  return (
    <div className="flex h-screen bg-[#050505] overflow-hidden text-gray-200">
`;

code = code.replace(
  `  return (
    <div className="flex h-screen bg-[#050505] overflow-hidden text-gray-200">`,
  renderWrapper
);

// Handle the header logout
code = code.replace(
  /<Topbar\s*user=\{user\}\s*onMenuClick=\{.*\}/,
  (match) => match + " onLogout={() => setUser(null)}"
);

fs.writeFileSync('src/App.tsx', code);
