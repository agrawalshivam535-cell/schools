const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const webhookCode = `
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      const body = req.body;
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) return res.status(500).send("No bot token");

      if (body.message) {
        const chatId = body.message.chat.id;

        // If user sends a contact
        if (body.message.contact) {
          const phone = body.message.contact.phone_number;
          
          // Normalize phone to last 10 digits to be safe
          const cleanPhone = phone.replace(/[^0-9]/g, '');
          const last10 = cleanPhone.slice(-10);

          // Find student
          const matchedStudents = students.filter(s => {
            if (!s.parentPhone) return false;
            const sPhone = s.parentPhone.replace(/[^0-9]/g, '');
            return sPhone.includes(last10);
          });

          if (matchedStudents.length > 0) {
            // Update all matched students
            matchedStudents.forEach(s => {
              s.telegramChatId = String(chatId);
            });
            saveDb('students.json', students);

            const names = matchedStudents.map(s => s.name).join(', ');
            await fetch(\`https://api.telegram.org/bot\${botToken}/sendMessage\`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                text: \`✅ Successfully linked your Telegram to student(s): \${names}. You will now receive automated fee receipts and reports here.\`,
                reply_markup: { remove_keyboard: true }
              })
            });
          } else {
            await fetch(\`https://api.telegram.org/bot\${botToken}/sendMessage\`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                text: \`❌ We couldn't find a student associated with the phone number \${phone}. Please update your phone number with the school administration.\`,
                reply_markup: { remove_keyboard: true }
              })
            });
          }
        } 
        // If user sends normal text
        else if (body.message.text) {
          await fetch(\`https://api.telegram.org/bot\${botToken}/sendMessage\`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              text: "Welcome to EduAI Bot! Please share your contact number to link your child's account so you can receive receipts and reports automatically.",
              reply_markup: {
                keyboard: [
                  [{ text: "📱 Share Phone Number", request_contact: true }]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
              }
            })
          });
        }
      }
      res.sendStatus(200); // Always respond 200 to Telegram
    } catch (e) {
      console.error("Webhook error", e);
      res.sendStatus(500);
    }
  });

  app.get("/api/telegram/setup", async (req, res) => {
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) return res.status(500).json({error: "No token"});
      
      const host = req.headers.host;
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
      const webhookUrl = \`\${protocol}://\${host}/api/telegram/webhook\`;

      const response = await fetch(\`https://api.telegram.org/bot\${botToken}/setWebhook\`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: webhookUrl })
      });
      const data = await response.json();
      res.json({ webhookUrl, telegramResponse: data });
    } catch (e) {
      res.status(500).json({ error: String(e) });
    }
  });

`;

content = content.replace('app.post("/api/telegram/send", async (req, res) => {', webhookCode + 'app.post("/api/telegram/send", async (req, res) => {');

fs.writeFileSync('server.ts', content);
console.log('Webhook routes added');
