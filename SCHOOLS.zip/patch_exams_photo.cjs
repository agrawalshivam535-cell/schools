const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const nameCell = `<td className="p-4 text-gray-300 font-bold">{student.name}</td>`;
const avatarNameCell = `<td className="p-4 text-gray-300 font-bold">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                                  {student.photo ? (
                                    <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                                  ) : (
                                    <span className="text-xs font-bold text-indigo-300">{student.name.charAt(0)}</span>
                                  )}
                                </div>
                                {student.name}
                              </div>
                            </td>`;

content = content.replace(nameCell, avatarNameCell);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log("Patched Exams");
