import fs from 'fs';

// Fix backend model
let server = fs.readFileSync('server.ts', 'utf-8');
server = server.replace(/gemini-2.5-pro/g, 'gemini-2.5-flash');
fs.writeFileSync('server.ts', server);

// Fix frontend error handling
let upload = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');
const oldAnalyze = `        const data = await response.json();
        setAnalyzedData(data);
        setIsUploading(false);`;
const newAnalyze = `        const data = await response.json();
        if (response.ok && Array.isArray(data)) {
          setAnalyzedData(data);
        } else {
          console.error('API Error:', data);
          alert(data.error || 'Failed to analyze document');
          setAnalyzedData(null);
        }
        setIsUploading(false);`;
upload = upload.replace(oldAnalyze, newAnalyze);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', upload);

console.log('Fixed errors');
