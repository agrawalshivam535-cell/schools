import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

code = code.replace("import { UploadMarks } from './UploadMarks';", "import { UploadMarks } from './UploadMarks';\nimport { ProcessedDataList } from './ProcessedDataList';");
code = code.replace("const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload'>('enter');", "const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload' | 'processed'>('enter');");

const oldNav = `<button
            onClick={() => setActiveTab('results')}
            className={\`px-4 py-2 text-sm font-medium transition-colors \${activeTab === 'results' ? 'text-white border-b-2 border-emerald-400' : 'text-gray-400 hover:text-white'}\`}
          >
            Results & Reports
          </button>
        </nav>
      </div>`;

const newNav = `<button
            onClick={() => setActiveTab('results')}
            className={\`px-4 py-2 text-sm font-medium transition-colors \${activeTab === 'results' ? 'text-white border-b-2 border-emerald-400' : 'text-gray-400 hover:text-white'}\`}
          >
            Results & Reports
          </button>
          <button
            onClick={() => setActiveTab('processed')}
            className={\`px-4 py-2 text-sm font-medium transition-colors \${activeTab === 'processed' ? 'text-white border-b-2 border-blue-400' : 'text-gray-400 hover:text-white'}\`}
          >
            Processed Data
          </button>
        </nav>
      </div>`;

code = code.replace(oldNav, newNav);

const newTabContent = `
        {activeTab === 'processed' && (
          <ProcessedDataList />
        )}
      </div>
    </div>
  );
`;

code = code.replace("      </div>\n    </div>\n  );\n}", newTabContent + "\n}");

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
