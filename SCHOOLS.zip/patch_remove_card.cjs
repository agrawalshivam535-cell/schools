const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const targetContent = `<div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Fee</div>
                  <div className="text-2xl font-black text-white">₹{fees.totalFee.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Paid</div>
                  <div className="text-2xl font-black text-emerald-400">₹{fees.paidAmount.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Balance</div>
                  <div className="text-2xl font-black text-red-400">₹{fees.balance.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Paid Month</div>
                  <div className="text-lg sm:text-xl font-black text-indigo-400 truncate" title={fees.status}>{fees.status}</div>
                </div>
              </div>`;

const replacementContent = `<div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Fee</div>
                  <div className="text-2xl font-black text-white">₹{fees.totalFee.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Paid</div>
                  <div className="text-2xl font-black text-emerald-400">₹{fees.paidAmount.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Balance</div>
                  <div className="text-2xl font-black text-red-400">₹{fees.balance.toFixed(2)}</div>
                </div>
              </div>`;

content = content.replace(targetContent, replacementContent);
fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched to remove Paid Month card");
