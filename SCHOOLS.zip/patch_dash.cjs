const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Dashboard.tsx', 'utf-8');

content = content.replace("import { useEffect, useState } from 'react';", "import { useEffect, useState } from 'react';\nimport { motion } from 'motion/react';");

const mainDivRx = /<div className="space-y-8 animate-in fade-in duration-500">/m;
content = content.replace(mainDivRx, '<div className="space-y-8">');

// Staggered cards
const statCardContainerRx = /<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">([\s\S]*?)<\/div>/m;
const match = content.match(statCardContainerRx);
if (match) {
  const cards = match[1];
  const newContainer = `<motion.div 
        variants={{ show: { transition: { staggerChildren: 0.1 } } }}
        initial="hidden" animate="show"
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4"
      >
        ${cards}
      </motion.div>`;
  content = content.replace(statCardContainerRx, newContainer);
}

// Modify StatCard to use motion
const statCardFuncRx = /function StatCard\(\{ title, value, color \}: \{ title: string, value: string \| number, color: string \}\) \{([\s\S]*?)return \([\s\S]*?<div className=\{([\s\S]*?)\}>([\s\S]*?)<\/div>\s*\);\s*\}/m;
const statCardMatch = content.match(statCardFuncRx);

if (statCardMatch) {
  const newStatCard = `function StatCard({ title, value, color }: { title: string, value: string | number, color: string }) {
  const colorMap: Record<string, string> = {
    indigo: 'border-indigo-500 text-indigo-400',
    purple: 'border-purple-500 text-purple-400',
    emerald: 'border-emerald-500 text-emerald-400',
    blue: 'border-blue-500 text-blue-400',
    red: 'border-red-500 text-red-400',
  };
  return (
    <motion.div 
      variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 24 } } }}
      whileHover={{ y: -5, scale: 1.02 }}
      className={"bg-[#0f0f0f]/60 backdrop-blur-xl border border-white/5 p-5 flex flex-col justify-center border-l-4 rounded-xl shadow-xl hover:shadow-2xl hover:shadow-" + colorMap[color].split(' ')[0].split('-')[1] + "-500/10 transition-all duration-300 " + colorMap[color].split(' ')[0]}
    >
      <span className="text-sm font-medium text-gray-400">{title}</span>
      <span className={"text-3xl font-extrabold mt-2 " + colorMap[color].split(' ')[1]}>{value}</span>
    </motion.div>
  );
}`;
  content = content.replace(statCardFuncRx, newStatCard);
}

// Quick Actions stagger
const quickActionsRx = /<div className="grid grid-cols-2 md:grid-cols-4 gap-4">([\s\S]*?)<\/div>\s*<\/div>/m;
const qaMatch = content.match(quickActionsRx);
if (qaMatch) {
    const rawButtons = qaMatch[1];
    let buttonsReplaced = rawButtons.replace(/<button/g, '<motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}');
    buttonsReplaced = buttonsReplaced.replace(/<\/button>/g, '</motion.button>');
    const newQaContainer = `<motion.div 
        variants={{ show: { transition: { staggerChildren: 0.1, delayChildren: 0.2 } } }}
        initial="hidden" animate="show"
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        ${buttonsReplaced}
      </motion.div>
    </div>`;
    content = content.replace(quickActionsRx, newQaContainer);
}

fs.writeFileSync('src/components/tabs/Dashboard.tsx', content);
console.log('Patched Dashboard.tsx');
