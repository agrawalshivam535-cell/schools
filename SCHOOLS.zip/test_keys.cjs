const fs = require('fs');
let classes = JSON.parse(fs.readFileSync('classes.json', 'utf8'));
let dynamic = classes.map(c => c.className + (c.section ? ' - ' + c.section : ''));
let set = new Set(dynamic);
if (set.size !== dynamic.length) {
  console.log("Duplicate in dynamicClassesList!");
} else {
  console.log("No duplicate in dynamicClassesList.");
}
