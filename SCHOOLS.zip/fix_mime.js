import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');
code = code.replace("mimeType: file.type,", "mimeType: 'image/jpeg',");
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
console.log('Fixed mimeType');
