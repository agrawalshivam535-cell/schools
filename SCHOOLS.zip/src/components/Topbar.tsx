import { useState } from 'react';
import { Menu, Key, LogOut, Sparkles } from 'lucide-react';
import { User } from '../types';
import { GeminiKeyModal } from './GeminiKeyModal';

interface TopbarProps {
  user: User;
  onOpenSidebar: () => void;
  title: string;
  onLogout?: () => void;
  onUpdateUser?: (updated: User) => void;
}

export function Topbar({ user, onOpenSidebar, title, onLogout, onUpdateUser }: TopbarProps) {
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);

  return (
    <>
      <div className="flex items-center justify-between gap-4 p-4 sm:px-8 sm:py-5 sticky top-0 z-30 bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center gap-3">
          <button onClick={onOpenSidebar} className="lg:hidden text-gray-300 hover:text-white">
            <Menu size={24} />
          </button>
          <h1 className="text-base sm:text-lg font-bold text-white">{title}</h1>
        </div>
        
        <div className="flex items-center gap-3 sm:gap-4">
          {/* User's Gemini API Key Status Button */}
          <button
            onClick={() => setIsKeyModalOpen(true)}
            className={`flex items-center gap-2 py-1.5 px-3 rounded-full text-xs font-medium border transition-all ${
              user.hasApiKey
                ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/40'
                : 'bg-amber-950/30 border-amber-500/40 text-amber-300 hover:bg-amber-900/40 animate-pulse'
            }`}
            title="Configure Gemini API Key for your account"
          >
            <Key size={13} className={user.hasApiKey ? 'text-emerald-400' : 'text-amber-400'} />
            <span className="hidden sm:inline">
              {user.hasApiKey ? 'Gemini Key: Active' : 'Set Gemini Key'}
            </span>
            <span className="sm:hidden">
              {user.hasApiKey ? 'Key Set' : 'Add Key'}
            </span>
            <span className={`w-1.5 h-1.5 rounded-full ${user.hasApiKey ? 'bg-emerald-400' : 'bg-amber-400'}`} />
          </button>

          {/* User Profile Pill */}
          <div className="flex items-center gap-2 py-1 px-2.5 rounded-full bg-black/40 border border-white/10">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs">
              {(user.name || user.loginId || 'U').charAt(0).toUpperCase()}
            </div>
            <div className="hidden sm:flex flex-col text-left pr-1">
              <span className="text-xs font-semibold text-white leading-tight">
                {user.name}
              </span>
              <span className="text-[10px] text-gray-400 leading-tight">
                @{user.loginId}
              </span>
            </div>
          </div>

          {onLogout && (
            <button 
              onClick={onLogout}
              className="p-2 text-gray-400 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors"
              title="Sign Out"
            >
              <LogOut size={20} />
            </button>
          )}
        </div>
      </div>

      <GeminiKeyModal
        isOpen={isKeyModalOpen}
        onClose={() => setIsKeyModalOpen(false)}
        user={user}
        onKeyUpdated={(updated) => {
          if (onUpdateUser) onUpdateUser(updated);
        }}
      />
    </>
  );
}
