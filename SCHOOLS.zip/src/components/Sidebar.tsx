import { motion } from 'motion/react';
import {  Home, Users, CheckSquare, DollarSign, FileText, Calendar, LogOut, Settings, Briefcase , Link2 } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  onLogout: () => void;
}

export function Sidebar({ activeTab, setActiveTab, isOpen, onLogout }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'staff', label: 'Staff', icon: Briefcase },
    { id: 'attendance', label: 'Attendance', icon: CheckSquare },
    { id: 'fees', label: 'Fees', icon: DollarSign },
    { id: 'exams', label: 'Exams', icon: FileText },
    { id: 'timetable', label: 'Timetable', icon: Calendar },
    { id: 'classsetup', label: 'Class Setup', icon: Settings },
  ];

  return (
    <aside className={"w-[15.5rem] shrink-0 flex flex-col fixed top-0 left-0 bottom-0 z-60 bg-[#0f0f0f] border-r border-white/10 transition-transform duration-250 ease-in-out " + (isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0")}>
      <div className="flex items-center gap-2.5 p-4 sm:p-5 border-b border-white/10">
        <span className="text-lg font-bold text-white tracking-tight">EduAI Dashboard</span>
      </div>
      
      <nav className="flex-1 overflow-y-auto p-3 space-y-1.5">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <motion.button whileHover={{ x: 4 }} whileTap={{ scale: 0.98 }}
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={"flex items-center gap-3 w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors " + (isActive ? "bg-indigo-500/15 text-indigo-200" : "text-gray-400 hover:bg-white/5 hover:text-white")}
            >
              <Icon size={18} className={isActive ? 'text-indigo-400' : 'text-gray-500'} />
              <span>{item.label}</span>
            </motion.button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-white/10">
        <motion.button whileHover={{ x: 4 }} whileTap={{ scale: 0.98 }} onClick={onLogout}
          className="flex items-center gap-3 w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-red-500 hover:bg-red-500/10 transition-colors"
        >
          <LogOut size={18} />
          <span>Logout</span>
        </motion.button>
      </div>
    </aside>
  );
}
