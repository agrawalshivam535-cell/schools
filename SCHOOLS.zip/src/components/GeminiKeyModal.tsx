import React, { useState } from 'react';
import { Key, Eye, EyeOff, Check, AlertCircle, Loader2, X, ExternalLink, ShieldCheck } from 'lucide-react';
import { User } from '../types';

interface GeminiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  user?: User;
  onKeyUpdated?: (updatedUser: User) => void;
  onUpdateUser?: (updatedUser: User) => void;
}

export function GeminiKeyModal({ isOpen, onClose, user, onKeyUpdated, onUpdateUser }: GeminiKeyModalProps) {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen || !user) return null;

  const notifyUserUpdated = (updatedUser: User) => {
    if (onKeyUpdated) onKeyUpdated(updatedUser);
    if (onUpdateUser) onUpdateUser(updatedUser);
  };

  const handleTest = async () => {
    const keyToTest = apiKey.trim();
    if (!keyToTest) {
      setMessage({ type: 'error', text: 'Please enter a Gemini API Key to test.' });
      return;
    }

    setTesting(true);
    setMessage(null);
    try {
      const res = await fetch('/api/user/test-gemini-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ geminiApiKey: keyToTest })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMessage({ type: 'success', text: 'Success! Your Gemini API key is valid and working.' });
      } else {
        setMessage({ type: 'error', text: data.message || 'Invalid Gemini API key. Please check and try again.' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Connection failed: ' + (err.message || 'Unknown network error') });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const keyToSave = apiKey.trim();
    if (!keyToSave) {
      setMessage({ type: 'error', text: 'Please enter a valid Gemini API key.' });
      return;
    }

    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch('/api/user/gemini-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          loginId: user.loginId,
          geminiApiKey: keyToSave
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMessage({ type: 'success', text: 'Gemini API key saved successfully for ' + user.loginId + '!' });
        const updatedUser: User = {
          ...user,
          hasApiKey: true,
          maskedApiKey: data.maskedApiKey,
          apiKey: keyToSave
        };
        notifyUserUpdated(updatedUser);
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setMessage({ type: 'error', text: data.message || 'Failed to save API key.' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Save failed: ' + (err.message || 'Unknown error') });
    } finally {
      setSaving(false);
    }
  };

  const handleRemove = async () => {
    if (!confirm('Are you sure you want to remove your personal Gemini API key? You will need to re-enter one to extract marks.')) {
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch('/api/user/gemini-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          loginId: user.loginId,
          geminiApiKey: ''
        })
      });
      const data = await res.json();
      if (res.ok) {
        setMessage({ type: 'success', text: 'Gemini API key removed.' });
        setApiKey('');
        const updatedUser: User = {
          ...user,
          hasApiKey: false,
          maskedApiKey: '',
          apiKey: ''
        };
        notifyUserUpdated(updatedUser);
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Failed to remove key: ' + err.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#0f0f11] border border-white/10 rounded-2xl p-6 sm:p-7 shadow-2xl relative text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Key size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Personal Gemini API Key
              </h2>
              <p className="text-xs text-gray-400">
                User Login ID: <span className="text-blue-400 font-semibold">{user.loginId}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Info card */}
        <div className="mb-5 p-3.5 bg-blue-950/20 border border-blue-500/20 rounded-xl text-xs text-blue-200/90 leading-relaxed flex items-start gap-2.5">
          <ShieldCheck size={18} className="text-blue-400 shrink-0 mt-0.5" />
          <div>
            Each user login uses their own individual Gemini API key for OCR marksheet extraction. 
            Your key is linked directly to <strong className="text-white">{user.loginId}</strong>.
          </div>
        </div>

        {/* Current status */}
        <div className="mb-5 p-3.5 bg-black/40 border border-white/5 rounded-xl flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Current Status:</span>
            {user.hasApiKey ? (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                Active ({user.maskedApiKey || 'Key Saved'})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                No key configured
              </span>
            )}
          </div>

          {user.hasApiKey && (
            <button
              type="button"
              onClick={handleRemove}
              disabled={saving}
              className="text-xs text-red-400 hover:text-red-300 transition-colors"
            >
              Remove
            </button>
          )}
        </div>

        {/* Feedback message */}
        {message && (
          <div
            className={`mb-5 p-3.5 rounded-xl text-xs flex items-start gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                : 'bg-red-500/10 border border-red-500/20 text-red-300'
            }`}
          >
            {message.type === 'success' ? (
              <Check size={16} className="shrink-0 text-emerald-400 mt-0.5" />
            ) : (
              <AlertCircle size={16} className="shrink-0 text-red-400 mt-0.5" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Key Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300">
              {user.hasApiKey ? 'Update Gemini API Key' : 'Enter Gemini API Key'}
            </label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Paste AIzaSy... key here"
                className="w-full bg-black/50 border border-white/10 rounded-xl py-2.5 pl-3.5 pr-11 text-sm text-white placeholder:text-gray-600 outline-none focus:border-blue-500 transition-colors font-mono"
                required
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                title={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between gap-3">
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors"
            >
              Get free key on Google AI Studio <ExternalLink size={12} />
            </a>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTest}
                disabled={testing || !apiKey.trim()}
                className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-medium text-gray-300 hover:text-white transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {testing && <Loader2 size={13} className="animate-spin" />}
                Test Key
              </button>

              <button
                type="submit"
                disabled={saving || !apiKey.trim()}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-blue-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {saving && <Loader2 size={13} className="animate-spin" />}
                Save Key
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
