import React, { useState, useEffect } from 'react';
import { 
  UploadCloud, 
  CheckCircle2, 
  Loader2, 
  Edit2, 
  Check, 
  LayoutGrid, 
  RefreshCw, 
  History, 
  Sparkles, 
  AlertTriangle, 
  ChevronLeft,
  Database,
  Key
} from 'lucide-react';
import { useClasses } from '../../hooks/useClasses';
import { User } from '../../types';
import { GeminiKeyModal } from '../GeminiKeyModal';

export interface AnalyzedRecord {
  id: string;
  rollNumber: string;
  name: string;
  totalMarks: string;
  marksObtained: string;
  previousMarks?: string;
  newMarks?: string;
  selectedSource?: 'old' | 'current' | 'custom';
  resolvedMismatch?: boolean;
}

export interface ProcessedRecord {
  id: string;
  className: string;
  section: string;
  subject: string;
  examType: string;
  timestamp: string;
  records: AnalyzedRecord[];
}

interface UploadMarksProps {
  initialRecord?: ProcessedRecord;
  pendingJob?: any;
  onBack?: () => void;
  onUploadSuccess?: () => void;
  user?: User;
  onUpdateUser?: (updated: User) => void;
}

export function UploadMarks({ initialRecord, pendingJob, onBack, onUploadSuccess, user, onUpdateUser }: UploadMarksProps = {}) {
  const { classes } = useClasses();
  const baseClasses = Array.from(new Set(classes.map(c => c.split(' - ')[0])));
  const sections = Array.from(new Set(classes.map(c => c.split(' - ')[1] || 'A'))).sort();

  const [uploadClass, setUploadClass] = useState(initialRecord?.className || pendingJob?.className || '');
  const [uploadSection, setUploadSection] = useState(initialRecord?.section || pendingJob?.section || '');
  const [uploadSubject, setUploadSubject] = useState(initialRecord?.subject || pendingJob?.subject || 'Maths');
  const [uploadExamType, setUploadExamType] = useState(initialRecord?.examType || pendingJob?.examType || 'Unit Test 1');
  const [uploadMaxMarks, setUploadMaxMarks] = useState(initialRecord?.records?.[0]?.totalMarks || pendingJob?.records?.[0]?.totalMarks || pendingJob?.maxMarks || '100');
  
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(null);
  const [isBulkEdit, setIsBulkEdit] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isRemapping, setIsRemapping] = useState(false);
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);

  useEffect(() => {
    const recordSource = initialRecord || pendingJob;
    if (recordSource && recordSource.records) {
      const fetchClassStudents = async () => {
        try {
          const classNameOnly = recordSource.className || uploadClass;
          const sectionOnly = recordSource.section || uploadSection;
          const classNameStr = classNameOnly + ' - ' + sectionOnly;
          const subjectStr = recordSource.subject || uploadSubject;
          const examTypeStr = recordSource.examType || uploadExamType;

          // 1. Fetch official students roster
          const res = await fetch(`/api/students?className=${encodeURIComponent(classNameStr)}`);
          if (!res.ok) throw new Error('Failed to fetch students');
          const students = await res.json();
          
          // 2. Fetch direct previous exam analysis records for this exact class, section, subject, and examType
          let previousRecords: any[] = [];
          try {
            const prevRes = await fetch(`/api/exams/previous?className=${encodeURIComponent(classNameOnly)}&section=${encodeURIComponent(sectionOnly)}&subject=${encodeURIComponent(subjectStr)}&examType=${encodeURIComponent(examTypeStr)}`);
            if (prevRes.ok) {
              const prevJson = await prevRes.json();
              if (prevJson.exists && Array.isArray(prevJson.records)) {
                previousRecords = prevJson.records;
              }
            }
          } catch (e) {
            console.error("Failed to fetch direct previous marks:", e);
          }

          // 3. Fallback: fetch from /api/marks/all
          let existingMarksMap: Record<string, any> = {};
          try {
            const marksRes = await fetch(`/api/marks/all?className=${encodeURIComponent(classNameOnly)}&section=${encodeURIComponent(sectionOnly)}`);
            if (marksRes.ok) {
              existingMarksMap = await marksRes.json();
            }
          } catch (e) {}

          const mergedData = students.map((student: any) => {
            // Find newly extracted record from image (current)
            const matchedCurrent = recordSource.records.find((r: any) => 
              String(r.rollNumber).trim() === String(student.rollNumber).trim() || 
              (r.id && student.id && String(r.id) === String(student.id))
            );

            // Find previous record (old)
            let prevMarks = '';
            const matchedPrev = previousRecords.find((r: any) => 
              String(r.rollNumber).trim() === String(student.rollNumber).trim() || 
              (r.id && student.id && String(r.id) === String(student.id))
            );

            if (matchedPrev && matchedPrev.marksObtained !== undefined && matchedPrev.marksObtained !== null && matchedPrev.marksObtained !== '') {
              prevMarks = String(matchedPrev.marksObtained);
            } else if (existingMarksMap[student.id]) {
              const studentExams = existingMarksMap[student.id];
              const specificExam = studentExams.find((e: any) => e.examName === examTypeStr);
              if (specificExam) {
                const specificSubj = specificExam.subjects.find((s: any) => s.name === subjectStr);
                if (specificSubj && specificSubj.obtained !== undefined && specificSubj.obtained !== '') {
                  prevMarks = String(specificSubj.obtained);
                }
              }
            }

            const currentMark = matchedCurrent && matchedCurrent.marksObtained !== undefined && matchedCurrent.marksObtained !== null 
              ? String(matchedCurrent.marksObtained) 
              : '';

            // Default selection:
            // Prefer current mark from the fresh image upload.
            // If current mark not found in image but old mark exists, use old.
            let activeMarks = currentMark;
            let source: 'old' | 'current' | 'custom' = 'current';

            if (currentMark !== '') {
              activeMarks = currentMark;
              source = 'current';
            } else if (prevMarks !== '') {
              activeMarks = prevMarks;
              source = 'old';
            }

            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: String(matchedCurrent?.totalMarks || matchedPrev?.totalMarks || recordSource.maxMarks || uploadMaxMarks || '100'),
              marksObtained: activeMarks,
              previousMarks: prevMarks,
              newMarks: currentMark,
              selectedSource: source
            };
          });

          // Also merge any extra roll numbers that were found in the uploaded image but not in the roster
          recordSource.records.forEach((r: any) => {
            if (!r.rollNumber) return;
            const alreadyIncluded = mergedData.some((m: any) => String(m.rollNumber).trim() === String(r.rollNumber).trim());
            if (!alreadyIncluded) {
              const prevMatch = previousRecords.find((pr: any) => String(pr.rollNumber).trim() === String(r.rollNumber).trim());
              const prevVal = prevMatch?.marksObtained !== undefined ? String(prevMatch.marksObtained) : '';
              const currVal = r.marksObtained !== undefined ? String(r.marksObtained) : '';
              mergedData.push({
                id: r.id || 'TEMP_' + r.rollNumber,
                rollNumber: r.rollNumber,
                name: r.name || `Student (Roll ${r.rollNumber})`,
                totalMarks: String(r.totalMarks || recordSource.maxMarks || uploadMaxMarks || '100'),
                marksObtained: currVal || prevVal,
                previousMarks: prevVal,
                newMarks: currVal,
                selectedSource: currVal ? 'current' : 'old'
              });
            }
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });

          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to fetch students for merging:", err);
          setAnalyzedData(recordSource.records);
        }
      };
      fetchClassStudents();
    }
  }, [initialRecord, pendingJob]);

  useEffect(() => {
    if (classes.length > 0 && !uploadClass) {
      setUploadClass(classes[0].split(' - ')[0]);
      setUploadSection(classes[0].split(' - ')[1] || 'A');
    }
  }, [classes, uploadClass]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;

    if (!user?.hasApiKey && !user?.apiKey) {
      setIsKeyModalOpen(true);
      return;
    }

    setIsUploading(true);
    setAnalyzedData(null);
    setIsSaved(false);

    try {
      const base64data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
              // Directly use PDF data
              return resolve(reader.result);
            }

            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              let width = img.width;
              let height = img.height;
              const maxDim = 2500; // Preserve high resolution for sharp OCR of tables and small numbers
              if (width > maxDim || height > maxDim) {
                if (width > height) {
                  height = Math.round((height * maxDim) / width);
                  width = maxDim;
                } else {
                  width = Math.round((width * maxDim) / height);
                  height = maxDim;
                }
              }
              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', 0.92));
              } else {
                resolve(reader.result as string);
              }
            };
            img.onerror = () => resolve(reader.result as string);
            img.src = reader.result;
          } else {
            reject(new Error("Failed to read file"));
          }
        };
        reader.readAsDataURL(file);
      });

      const response = await fetch('/api/exams/jobs/upload', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-user-id': user?.loginId || '',
          'x-gemini-api-key': user?.apiKey || ''
        },
        body: JSON.stringify({
          image: base64data,
          fileData: base64data,
          filename: file.name,
          mimeType: file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'image/jpeg'),
          className: uploadClass,
          section: uploadSection,
          subject: uploadSubject,
          examType: uploadExamType,
          maxMarks: uploadMaxMarks,
          loginId: user?.loginId,
          geminiApiKey: user?.apiKey
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (errorData.error && errorData.error.toLowerCase().includes('gemini api key')) {
          setIsKeyModalOpen(true);
        }
        throw new Error(errorData.error || 'Failed to upload exam job');
      }

      if (onUploadSuccess) onUploadSuccess();
      return;
    } catch (err: any) {
      console.error(err);
      alert('Error analyzing document: ' + err.message);
      setAnalyzedData(null);
    } finally {
      setIsUploading(false);
    }
  };

  // --- Granular conflict resolution handlers ---

  // Choose Old Data for an individual student
  const handleSelectOld = (id: string) => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if (row.id === id) {
        return {
          ...row,
          marksObtained: row.previousMarks ?? '',
          selectedSource: 'old'
        };
      }
      return row;
    }));
  };

  // Choose Current Data for an individual student
  const handleSelectCurrent = (id: string) => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if (row.id === id) {
        return {
          ...row,
          marksObtained: row.newMarks ?? '',
          selectedSource: 'current'
        };
      }
      return row;
    }));
  };

  // Bulk action: Keep All Old Data
  const handleKeepAllOld = () => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if (row.previousMarks !== undefined && row.previousMarks !== '') {
        return {
          ...row,
          marksObtained: row.previousMarks,
          selectedSource: 'old'
        };
      }
      return row;
    }));
  };

  // Bulk action: Keep All Current Data
  const handleKeepAllCurrent = () => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if (row.newMarks !== undefined && row.newMarks !== '') {
        return {
          ...row,
          marksObtained: row.newMarks,
          selectedSource: 'current'
        };
      }
      return row;
    }));
  };

  const hasAnyOldData = analyzedData?.some(row => row.previousMarks !== undefined && row.previousMarks !== '');
  const conflictsCount = analyzedData?.filter(row => 
    row.previousMarks !== undefined && 
    row.previousMarks !== '' && 
    row.newMarks !== undefined && 
    row.newMarks !== '' && 
    row.previousMarks !== row.newMarks
  ).length || 0;

  const currentKeptCount = analyzedData?.filter(row => row.selectedSource === 'current' && row.marksObtained !== '').length || 0;
  const oldKeptCount = analyzedData?.filter(row => row.selectedSource === 'old' && row.marksObtained !== '').length || 0;
  const customKeptCount = analyzedData?.filter(row => row.selectedSource === 'custom' && row.marksObtained !== '').length || 0;

  const handleRemap = async () => {
    if (!analyzedData) return;
    setIsRemapping(true);
    try {
      const response = await fetch('/api/exams/remap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          records: analyzedData.filter(r => r.marksObtained !== ""),
          answers: {
            q1: uploadClass,
            q2: uploadSection,
            q3: uploadSubject,
            q4: uploadExamType,
            q5: uploadMaxMarks
          }
        })
      });
      const data = await response.json();
      if (response.ok && Array.isArray(data)) {
        try {
          const classNameStr = uploadClass + ' - ' + uploadSection;
          const res = await fetch(`/api/students?className=${encodeURIComponent(classNameStr)}`);
          const students = await res.json();
          
          let previousRecords: any[] = [];
          try {
            const prevRes = await fetch(`/api/exams/previous?className=${encodeURIComponent(uploadClass)}&section=${encodeURIComponent(uploadSection)}&subject=${encodeURIComponent(uploadSubject)}&examType=${encodeURIComponent(uploadExamType)}`);
            if (prevRes.ok) {
              const prevJson = await prevRes.json();
              if (prevJson.exists && Array.isArray(prevJson.records)) {
                previousRecords = prevJson.records;
              }
            }
          } catch (e) {}

          const mergedData = students.map((student: any) => {
            const matchedRecord = data.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            const matchedPrev = previousRecords.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            
            const prevMarks = matchedPrev?.marksObtained !== undefined ? String(matchedPrev.marksObtained) : '';
            const currMarks = matchedRecord?.marksObtained !== undefined ? String(matchedRecord.marksObtained) : '';

            let activeMarks = currMarks || prevMarks || '';
            let source: 'old' | 'current' | 'custom' = currMarks ? 'current' : 'old';

            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (uploadMaxMarks || '100'),
              marksObtained: activeMarks,
              previousMarks: prevMarks,
              newMarks: currMarks,
              selectedSource: source
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });
          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to merge remapped data:", err);
          setAnalyzedData(data);
        }
      } else {
        alert(data.error || 'Failed to remap data');
      }
    } catch (err: any) {
      alert('Error remapping data: ' + err.message);
    } finally {
      setIsRemapping(false);
    }
  };

  const handleMarkChange = (id: string, value: string) => {
    if (!analyzedData) return;
    
    // Only allow empty or numbers
    if (value !== '' && !/^\d+$/.test(value)) return;
    
    if (value !== '') {
      const num = parseInt(value, 10);
      let maxMarks = parseInt(uploadMaxMarks || '100', 10) || 100;
      const lowerExam = uploadExamType.toLowerCase();
      if (lowerExam.includes('unit test')) maxMarks = Math.min(maxMarks, 25);
      else if (lowerExam.includes('mid-year') || lowerExam.includes('mid term')) maxMarks = Math.min(maxMarks, 50);
      
      if (num > maxMarks) {
        alert(`Maximum marks for ${uploadExamType} is ${maxMarks}`);
        return;
      }
    }

    setAnalyzedData(analyzedData.map(row => {
      if (row.id === id) {
        let src: 'old' | 'current' | 'custom' = 'custom';
        if (row.previousMarks && value === row.previousMarks) src = 'old';
        else if (row.newMarks && value === row.newMarks) src = 'current';
        return {
          ...row,
          marksObtained: value,
          selectedSource: src
        };
      }
      return row;
    }));
  };

  const handleSave = async () => {
    if (!analyzedData) return;
    setIsSaving(true);
    
    try {
      if (initialRecord) {
        await fetch('/api/exams/analysis/' + initialRecord.id, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData.filter(r => r.marksObtained !== "")
          })
        });
      } else if (pendingJob) {
        await fetch('/api/exams/jobs/' + pendingJob.id + '/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData.filter(r => r.marksObtained !== "")
          })
        });
      } else {
        await fetch('/api/exams/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData.filter(r => r.marksObtained !== "")
          })
        });
      }
      setIsSaving(false);
      setIsSaved(true);
      setTimeout(() => {
        setIsSaved(false);
        if (onBack) onBack();
      }, 1200);
    } catch (err) {
      console.error(err);
      setIsSaving(false);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      {/* User Gemini API Key Status Banner */}
      <div className={`mb-6 p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
        user?.hasApiKey 
          ? 'bg-indigo-950/20 border-indigo-500/20 text-indigo-200' 
          : 'bg-amber-950/30 border-amber-500/30 text-amber-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg ${user?.hasApiKey ? 'bg-indigo-500/20 text-indigo-400' : 'bg-amber-500/20 text-amber-400'}`}>
            <Key size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-white">Extraction Account:</span>
              <span className="text-xs px-2 py-0.5 rounded bg-white/10 text-white font-mono">{user?.loginId || 'Current User'}</span>
              {user?.hasApiKey ? (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-medium flex items-center gap-1">
                  <Check size={11} /> Key Connected
                </span>
              ) : (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-medium flex items-center gap-1">
                  <AlertTriangle size={11} /> API Key Required
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              {user?.hasApiKey 
                ? `Using personal key (${user.maskedApiKey || 'Active'}) for document extraction quota`
                : 'Every login ID user must supply their personal Gemini API key to extract marks'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsKeyModalOpen(true)}
          className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 shrink-0 ${
            user?.hasApiKey
              ? 'bg-white/10 hover:bg-white/20 text-white border border-white/10'
              : 'bg-amber-500 hover:bg-amber-400 text-black font-semibold shadow-md shadow-amber-900/30'
          }`}
        >
          <Key size={13} />
          {user?.hasApiKey ? 'Manage Key' : 'Enter Gemini API Key'}
        </button>
      </div>

      <div className="flex flex-col xl:flex-row gap-6 mb-8">
        {onBack && (
          <div className="w-full mb-2">
             <button onClick={onBack} className="text-gray-400 hover:text-white flex items-center gap-2 mb-2 transition-colors font-medium text-sm">
               <ChevronLeft size={18} />
               Back to {pendingJob ? 'Pending Verification' : 'Processed Data'}
             </button>
          </div>
        )}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Class</label>
            <select
              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors"
              value={uploadClass}
              onChange={(e) => setUploadClass(e.target.value)}
            >
              {baseClasses.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Section</label>
            <select
              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors"
              value={uploadSection}
              onChange={(e) => setUploadSection(e.target.value)}
            >
              {sections.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Subject</label>
            <select
              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors"
              value={uploadSubject}
              onChange={(e) => setUploadSubject(e.target.value)}
            >
              {['Maths', 'Science', 'Hindi'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Exam Type</label>
            <select
              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors"
              value={uploadExamType}
              onChange={(e) => setUploadExamType(e.target.value)}
            >
              {['Unit Test 1', 'Unit Test 2', 'Mid-year', 'Annual'].map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Max Marks</label>
            <input
              type="number"
              className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors"
              value={uploadMaxMarks}
              onChange={(e) => setUploadMaxMarks(e.target.value)}
            />
          </div>
        </div>
      </div>

      {!analyzedData && (
        <div className="mb-8 p-6 bg-[#0a0a0a] border border-white/10 rounded-xl">
          <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Upload Handwritten Marks Document</label>
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-white/10 rounded-lg p-12 bg-black/20 hover:bg-white/5 transition-colors cursor-pointer relative">
            <input 
              type="file" 
              accept="image/*"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleFileChange}
            />
            <UploadCloud className="w-12 h-12 text-gray-500 mb-4" />
            <p className="text-white font-medium mb-1">Drop image here or click to browse</p>
            <p className="text-sm text-gray-500">{file ? file.name : "Supports JPG, PNG"}</p>
          </div>
          
          {file && !analyzedData && (
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleAnalyze}
                disabled={isUploading}
                className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white px-6 py-2.5 rounded-lg font-bold transition-colors shadow-lg"
              >
                {isUploading ? <Loader2 size={16} className="animate-spin" /> : <UploadCloud size={16} />}
                {isUploading ? 'Analyzing...' : 'Upload & Analyze with AI'}
              </button>
            </div>
          )}
        </div>
      )}

      {analyzedData && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-purple-400" />
                Data Verification & Conflict Management
              </h3>
              <p className="text-gray-400 text-xs sm:text-sm mt-0.5">
                Review extracted marks against previous database records. Select old or current data for each student or apply globally.
              </p>
            </div>

            <button
              onClick={() => setIsBulkEdit(!isBulkEdit)}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors border ${isBulkEdit ? 'bg-blue-600 border-blue-500 text-white' : 'bg-transparent border-white/20 text-gray-300 hover:bg-white/5'}`}
            >
              {isBulkEdit ? 'Done Editing' : 'Manual Direct Edit'}
            </button>
          </div>
          
          {/* Comparison & Decision Banner */}
          {hasAnyOldData && (
            <div className="mb-6 bg-gradient-to-r from-blue-950/30 via-purple-950/20 to-black/40 border border-blue-500/30 rounded-xl p-5 shadow-lg">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
                <div className="flex items-start gap-3.5">
                  <div className="p-2.5 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 mt-0.5 shrink-0">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <h4 className="text-white font-semibold text-sm sm:text-base">
                        Existing Data Available (पुराना डेटा उपलब्ध है)
                      </h4>
                      {conflictsCount > 0 ? (
                        <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs rounded-full font-semibold flex items-center gap-1">
                          <AlertTriangle size={12} /> {conflictsCount} Mismatch{conflictsCount !== 1 ? 'es' : ''} Found
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs rounded-full font-semibold flex items-center gap-1">
                          <Check size={12} /> All Match Old Data
                        </span>
                      )}
                    </div>
                    <p className="text-gray-300 text-xs sm:text-sm mt-1">
                      इस जगह पहले से पुराना डेटा उपलब्ध है। आप तय कर सकते हैं कि प्रत्येक छात्र पर पुराना (Old) डेटा रखना है या नया इमेज (Current) डेटा रखना है:
                    </p>
                    <div className="flex items-center gap-4 mt-2.5 text-xs text-gray-400 flex-wrap">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                        Current Kept: <strong className="text-white">{currentKeptCount}</strong>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-400"></span>
                        Old Kept: <strong className="text-white">{oldKeptCount}</strong>
                      </span>
                      {customKeptCount > 0 && (
                        <span className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                          Custom Edited: <strong className="text-white">{customKeptCount}</strong>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Bulk Decision Buttons */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full lg:w-auto shrink-0">
                  <button
                    type="button"
                    onClick={handleKeepAllOld}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-900/40 hover:bg-blue-800/60 text-blue-200 text-xs sm:text-sm font-semibold rounded-lg border border-blue-500/40 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-md shadow-blue-950/40"
                    title="सभी छात्रों पर पुराना डेटा सेट करें"
                  >
                    <History size={16} className="text-blue-300" />
                    Keep All Old (केवल ओल्ड डेटा रखें)
                  </button>
                  <button
                    type="button"
                    onClick={handleKeepAllCurrent}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-lg shadow-emerald-900/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                    title="सभी छात्रों पर नया इमेज डेटा सेट करें"
                  >
                    <Sparkles size={16} />
                    Keep All Current (केवल करंट डेटा रखें)
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Marks Data Table */}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0a0a] mb-6 shadow-xl">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/10 text-xs font-bold text-gray-400 uppercase tracking-wider bg-black/50">
                  <th className="p-3.5 whitespace-nowrap w-20">Roll No</th>
                  <th className="p-3.5 whitespace-nowrap min-w-[150px]">Student Name</th>
                  <th className="p-3.5 whitespace-nowrap">Old / Previous Data</th>
                  <th className="p-3.5 whitespace-nowrap">Current Image Data</th>
                  <th className="p-3.5 whitespace-nowrap min-w-[220px]">Choose Data (डेटा चुनें)</th>
                  <th className="p-3.5 whitespace-nowrap w-32">Final to Save</th>
                  <th className="p-3.5 whitespace-nowrap w-20">Total</th>
                  <th className="p-3.5 whitespace-nowrap text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {analyzedData.map((row) => {
                  const hasOld = row.previousMarks !== undefined && row.previousMarks !== '';
                  const hasCurrent = row.newMarks !== undefined && row.newMarks !== '';
                  const isMismatch = hasOld && hasCurrent && row.previousMarks !== row.newMarks;
                  const isIdentical = hasOld && hasCurrent && row.previousMarks === row.newMarks;

                  return (
                    <tr 
                      key={row.id} 
                      className={`hover:bg-white/[0.03] transition-colors ${
                        isMismatch 
                          ? row.selectedSource === 'old'
                            ? 'bg-blue-950/10'
                            : 'bg-emerald-950/10'
                          : ''
                      }`}
                    >
                      <td className="p-3.5 text-gray-400 text-sm font-mono font-bold">{row.rollNumber}</td>
                      <td className="p-3.5 text-gray-200 text-sm font-medium">{row.name}</td>
                      
                      {/* Old Data Column */}
                      <td className="p-3.5">
                        {hasOld ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-blue-950/40 text-blue-300 border border-blue-800/40 rounded-md font-mono text-sm font-semibold">
                            <History size={13} className="text-blue-400" />
                            {row.previousMarks}
                          </span>
                        ) : (
                          <span className="text-gray-600 text-xs italic">No old data</span>
                        )}
                      </td>

                      {/* Current Data Column */}
                      <td className="p-3.5">
                        {hasCurrent ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-purple-950/40 text-purple-300 border border-purple-800/40 rounded-md font-mono text-sm font-semibold">
                            <Sparkles size={13} className="text-purple-400" />
                            {row.newMarks}
                          </span>
                        ) : (
                          <span className="text-gray-600 text-xs italic">Not detected</span>
                        )}
                      </td>

                      {/* Per-Student Granular Choice Column */}
                      <td className="p-3.5">
                        {isMismatch ? (
                          <div className="flex items-center gap-2">
                            {/* Choose Old Button */}
                            <button
                              type="button"
                              onClick={() => handleSelectOld(row.id)}
                              title="इस छात्र पर पुराना डेटा रखें"
                              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                                row.selectedSource === 'old'
                                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40 border border-blue-400 ring-2 ring-blue-500/40 font-bold scale-[1.02]'
                                  : 'bg-white/5 hover:bg-blue-900/30 text-gray-300 border border-white/10 hover:border-blue-500/40'
                              }`}
                            >
                              <History size={13} className={row.selectedSource === 'old' ? 'text-white' : 'text-blue-400'} />
                              Old: {row.previousMarks}
                            </button>

                            {/* Choose Current Button */}
                            <button
                              type="button"
                              onClick={() => handleSelectCurrent(row.id)}
                              title="इस छात्र पर नया करंट डेटा रखें"
                              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                                row.selectedSource === 'current'
                                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40 border border-emerald-400 ring-2 ring-emerald-500/40 font-bold scale-[1.02]'
                                  : 'bg-white/5 hover:bg-emerald-900/30 text-gray-300 border border-white/10 hover:border-emerald-500/40'
                              }`}
                            >
                              <Sparkles size={13} className={row.selectedSource === 'current' ? 'text-white' : 'text-emerald-400'} />
                              Current: {row.newMarks}
                            </button>
                          </div>
                        ) : isIdentical ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs text-emerald-400 bg-emerald-950/30 border border-emerald-800/30 font-medium">
                            <Check size={13} /> Matches Old ({row.marksObtained})
                          </span>
                        ) : hasOld && !hasCurrent ? (
                          <button
                            type="button"
                            onClick={() => handleSelectOld(row.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs bg-blue-950/40 hover:bg-blue-900/40 text-blue-300 border border-blue-800/40 font-medium"
                          >
                            <History size={12} /> Use Old ({row.previousMarks})
                          </button>
                        ) : hasCurrent && !hasOld ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs text-purple-300 bg-purple-950/30 border border-purple-800/30 font-medium">
                            <Sparkles size={12} /> New Entry ({row.newMarks})
                          </span>
                        ) : (
                          <span className="text-gray-600 text-xs">-</span>
                        )}
                      </td>

                      {/* Final Marks to Save (Editable) */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            inputMode="numeric"
                            className={`w-20 rounded-lg px-2.5 py-1.5 text-sm font-mono text-center outline-none transition-all border font-bold ${
                              row.selectedSource === 'old'
                                ? 'border-blue-500/60 text-blue-300 bg-blue-950/30 shadow-[0_0_10px_rgba(59,130,246,0.15)]'
                                : row.selectedSource === 'current'
                                ? 'border-emerald-500/60 text-emerald-300 bg-emerald-950/30 shadow-[0_0_10px_rgba(16,185,129,0.15)]'
                                : 'border-amber-500/60 text-amber-300 bg-amber-950/30 shadow-[0_0_10px_rgba(245,158,11,0.15)]'
                            }`}
                            value={row.marksObtained}
                            onChange={(e) => handleMarkChange(row.id, e.target.value)}
                          />
                        </div>
                      </td>

                      <td className="p-3.5 text-gray-500 text-sm font-mono">{row.totalMarks}</td>

                      {/* Status Tag */}
                      <td className="p-3.5 text-right">
                        {row.selectedSource === 'old' ? (
                          <span className="inline-block text-[11px] font-bold text-blue-400 uppercase tracking-wider bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                            Old Kept
                          </span>
                        ) : row.selectedSource === 'current' ? (
                          <span className="inline-block text-[11px] font-bold text-emerald-400 uppercase tracking-wider bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                            Current Kept
                          </span>
                        ) : (
                          <span className="inline-block text-[11px] font-bold text-amber-400 uppercase tracking-wider bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            Custom
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-3 items-center">
              <button
                onClick={handleRemap}
                disabled={isRemapping}
                className="flex items-center gap-2 bg-blue-600/80 hover:bg-blue-600 disabled:opacity-50 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors border border-blue-500/30"
              >
                {isRemapping ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
                {isRemapping ? 'Updating...' : 'Remap / Change Data'}
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-bold px-7 py-2.5 rounded-lg transition-all shadow-lg shadow-emerald-950/50 hover:scale-[1.02] active:scale-[0.98]"
              >
                {isSaving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
                {isSaving ? 'Saving...' : 'Verify and Update'}
              </button>
              {isSaved && (
                <span className="text-emerald-400 text-sm font-medium flex items-center gap-1.5 animate-in fade-in">
                  <CheckCircle2 size={16} /> Saved successfully!
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Per-User Gemini API Key Configuration Modal */}
      <GeminiKeyModal 
        isOpen={isKeyModalOpen} 
        onClose={() => setIsKeyModalOpen(false)}
        user={user}
        onUpdateUser={onUpdateUser}
      />
    </div>
  );
}
