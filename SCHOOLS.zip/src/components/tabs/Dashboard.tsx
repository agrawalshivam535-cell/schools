import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Users, Megaphone, AlertCircle } from 'lucide-react';

export function Dashboard({ onNavigate }: { onNavigate: (tab: string, action?: string) => void }) {
  const [stats, setStats] = useState({
    totalStudents: '...',
    attendancePct: '...',
    totalStaff: '...',
    feesCollected: '...',
    feesPending: '...'
  });

  useEffect(() => {
    fetch('/api/dashboard')
      .then(r => r.json())
      .then(data => setStats(data))
      .catch(console.error);
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Welcome!</h1>
        <p className="text-sm mt-1 text-gray-400">Here is what's happening at your school today.</p>
      </div>

      <motion.div 
        variants={{ show: { transition: { staggerChildren: 0.1 } } }}
        initial="hidden" animate="show"
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4"
      >
        
        <StatCard title="Total Students" value={stats.totalStudents} color="indigo" />
        <StatCard title="Total Staff" value={stats.totalStaff} color="purple" />
        <StatCard title="Today's Attendance" value={stats.attendancePct} color="emerald" />
        <StatCard title="Fees Collected" value={stats.feesCollected} color="blue" />
        <StatCard title="Fees Pending" value={stats.feesPending} color="red" />
      
      </motion.div>

      <div>
        <h2 className="text-lg font-bold text-white mb-4">Quick Actions</h2>
        <motion.div 
        variants={{ show: { transition: { staggerChildren: 0.1, delayChildren: 0.2 } } }}
        initial="hidden" animate="show"
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => onNavigate('attendance')} className="bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl shadow-lg font-semibold flex items-center justify-center gap-2 transition-transform active:scale-95">
            <Calendar size={18} /> Mark Attendance
          </motion.button>
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => onNavigate('students', 'enroll')} className="bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-xl shadow-lg font-semibold flex items-center justify-center gap-2 transition-transform active:scale-95">
            <Users size={18} /> Add Student
          </motion.button>
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl shadow-lg font-semibold flex items-center justify-center gap-2 transition-transform active:scale-95">
            <Megaphone size={18} /> Announcement
          </motion.button>
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => onNavigate('fees')} className="bg-black/40 border border-white/10 hover:bg-white/5 text-red-400 py-3 px-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-transform active:scale-95">
            <AlertCircle size={18} /> Fee Defaulters
          </motion.button>
        
      </motion.div>
    </div>
    </div>
  );
}

function StatCard({ title, value, color }: { title: string, value: string | number, color: string }) {
  const colorMap: Record<string, string> = {
    indigo: 'border-indigo-500 text-indigo-400 hover:shadow-indigo-500/20',
    purple: 'border-purple-500 text-purple-400 hover:shadow-purple-500/20',
    emerald: 'border-emerald-500 text-emerald-400 hover:shadow-emerald-500/20',
    blue: 'border-blue-500 text-blue-400 hover:shadow-blue-500/20',
    red: 'border-red-500 text-red-400 hover:shadow-red-500/20',
  };
  return (
    <motion.div 
      variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 24 } } }}
      whileHover={{ y: -5, scale: 1.02 }}
      className={"bg-[#0f0f0f]/60 backdrop-blur-xl border border-white/5 p-5 flex flex-col justify-center border-l-4 rounded-xl shadow-xl transition-all duration-300 " + colorMap[color].split(' ').slice(0,1).join('') + " " + colorMap[color].split(' ').slice(2).join('')}
    >
      <span className="text-sm font-medium text-gray-400">{title}</span>
      <span className={"text-3xl font-extrabold mt-2 " + colorMap[color].split(' ')[1]}>{value}</span>
    </motion.div>
  );
}
