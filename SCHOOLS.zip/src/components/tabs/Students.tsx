import { useClasses } from '../../hooks/useClasses';
import React, { useState, useEffect, useRef } from 'react';
import { Search, Plus, Eye, Trash2, Edit, Calendar, IndianRupee, Activity, FileText, Download, X, Upload, Send, Loader2, Unlink } from 'lucide-react';
import { Student } from '../../types';
import { jsPDF } from "jspdf";
import Papa from "papaparse";
import * as XLSX from "xlsx";

export function Students({ initialAction, onActionComplete }: { initialAction?: string | null, onActionComplete?: () => void }) {
  const [currentView, setCurrentView] = useState<'list' | 'detail' | 'enroll'>('list');
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(false);

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Student> | null>(null);

  // Filters for list view
  const [search, setSearch] = useState('');
  const [className, setClassName] = useState('All Classes');
  const [section, setSection] = useState('All Sections');

  // Selected student for detail view
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [detailTab, setDetailTab] = useState<'overview' | 'attendance' | 'fees' | 'marks'>('overview');

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [promoteModal, setPromoteModal] = useState<{ isOpen: boolean, toClass: string, actionType: 'promote' | 'demote' | 'reassign' }>({ isOpen: false, toClass: 'Class 10 - A', actionType: 'reassign' });
  const [isPromoting, setIsPromoting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [telegramDisconnectId, setTelegramDisconnectId] = useState<string | null>(null);
  const [previewData, setPreviewData] = useState<{
    type: 'single' | 'full';
    data: any;
    student: any;
  } | null>(null);
  
  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingCSV, setIsUploadingCSV] = useState(false);

  const { classes: fetchedClasses } = useClasses();
  const classes = ['All Classes', ...fetchedClasses];
  const sections = ['All Sections', 'A', 'B', 'C', 'D'];

  useEffect(() => {
    if (currentView === 'list') {
      fetchStudents();
    }
  }, [className, section, search, currentView]);

  useEffect(() => {
    if (initialAction === 'enroll') {
      setEditForm({});
      if (onActionComplete) onActionComplete();
    }
  }, [initialAction]);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/students?className=${encodeURIComponent(className)}&section=${encodeURIComponent(section)}&search=${encodeURIComponent(search)}`);
      const data = await res.json();
      setStudents(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };


  const disconnectTelegram = async (id: string) => {
    if (!confirm('Are you sure you want to disconnect Telegram for this student?')) return;
    try {
      const res = await fetch(`/api/students/${id}/disconnect-telegram`, { method: 'POST' });
      if (res.ok) {
        setSelectedStudent((prev: any) => prev ? { ...prev, telegramChatId: '' } : prev);
        fetchStudents();
      } else {
        alert('Failed to disconnect telegram');
      }
    } catch (e) {
      if (String(e).includes("Failed to fetch")) return;
      console.error(e);
    }
  };

  const viewStudentDetails = async (studentId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/students/${studentId}/details`);
      const data = await res.json();
      setSelectedStudent(data);
      setCurrentView('detail');
      setDetailTab('overview');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await fetch(`/api/students/${deleteConfirmId}`, { method: 'POST' });
      setDeleteConfirmId(null);
      if (currentView === 'detail' && selectedStudent?.student.rollNumber === deleteConfirmId) {
        setCurrentView('list');
      } else {
        fetchStudents();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image must be smaller than 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (editForm) {
          setEditForm({ ...editForm, photo: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveStudent = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!editForm) return;

    try {
      const isEdit = students.some(s => s.id === editForm.id);
      const method = isEdit ? 'PUT' : 'POST';
      const endpoint = isEdit ? `/api/students/${editForm.id}` : '/api/students/enroll';

      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      });

      if (res.ok) {
        setEditForm(null);
        if (currentView === 'detail' && isEdit) {
          viewStudentDetails(editForm.id!);
        } else {
          fetchStudents();
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingCSV(true);

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        let allRows: any[] = [];
        let detectedHeaders: string[] = [];
        
        // Loop through all sheets in the file
        workbook.SheetNames.forEach((sheetName, index) => {
          const sheet = workbook.Sheets[sheetName];
          
          // Read sheet as an array of arrays to inspect the first row
          const aoa = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
          if (!aoa || aoa.length === 0) return;
          
          let sheetRows: any[];
          
          // Check if the first row looks like a header row
          const firstRow = aoa[0];
          const firstRowStr = firstRow.map(String).join(' ').toLowerCase();
          const hasHeaders = firstRowStr.includes('name') || firstRowStr.includes('class') || firstRowStr.includes('roll');
          
          if (hasHeaders || index === 0) {
            // It has headers (or it's the very first sheet, so we assume it defines the headers)
            detectedHeaders = firstRow.map(String);
            // Parse normally
            sheetRows = XLSX.utils.sheet_to_json(sheet);
          } else {
            // Missing headers! Use the headers from the first sheet
            sheetRows = XLSX.utils.sheet_to_json(sheet, { header: detectedHeaders });
            // The first row is actual data, so we keep it. sheet_to_json with header array includes the first row as data.
          }
          
          allRows = allRows.concat(sheetRows);
        });

        let rows = allRows;

        if (!rows || rows.length === 0) {
          alert('File is empty or invalid.');
          setIsUploadingCSV(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        // Normalize CSV keys to match our internal data model
        rows = rows.map((row: any) => {
          const normalized: any = {};
          for (const key in row) {
            const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['studentid', 'id'].includes(cleanKey)) normalized.id = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['fathername', 'fathersname', 'parentname', 'guardianname', 'father'].includes(cleanKey)) normalized.fatherName = row[key];
            else if (['mothername', 'mothersname', 'mother'].includes(cleanKey)) normalized.motherName = row[key];
            else if (['parentphone', 'phone', 'mobile', 'contactnumber', 'parentcontact'].includes(cleanKey)) normalized.parentPhone = String(row[key]);
            else if (['email', 'emailaddress'].includes(cleanKey)) normalized.email = row[key];
            else if (['gender', 'sex'].includes(cleanKey)) normalized.gender = row[key];
            else if (['dob', 'dateofbirth', 'birthdate'].includes(cleanKey)) normalized.dob = row[key];
            else if (['address', 'homeaddress'].includes(cleanKey)) normalized.address = row[key];
            else if (['bloodgroup', 'blood'].includes(cleanKey)) normalized.bloodGroup = row[key];
            else if (['admissiondate', 'dateofadmission'].includes(cleanKey)) normalized.admissionDate = row[key];
            else if (['city'].includes(cleanKey)) normalized.city = row[key];
            else if (['state'].includes(cleanKey)) normalized.state = row[key];
            else if (['pincode', 'pin', 'zip', 'zipcode'].includes(cleanKey)) normalized.pinCode = row[key];
            else if (['telegramchatid', 'telegramid', 'telegram'].includes(cleanKey)) normalized.telegramChatId = String(row[key]);
            else normalized[key] = row[key]; // keep other fields
          }

          // Format class and section to match app expectations (e.g., "Class 10 - A")
          if (normalized.className) {
            let baseClass = normalized.className;
            // If they just provided a number like "10", make it "Class 10"
            if (/^\d+$/.test(baseClass)) {
              baseClass = `Class ${baseClass}`;
            } else if (/^class\s*\d+$/i.test(baseClass)) {
              const num = baseClass.match(/\d+/)[0];
              baseClass = `Class ${num}`;
            }
            
            // If section is provided, ensure className has the " - [Section]" suffix
            if (normalized.section) {
              const expectedSuffix = ` - ${normalized.section}`;
              if (!baseClass.includes(expectedSuffix)) {
                // If it had a different section suffix, strip it first
                baseClass = baseClass.split(' - ')[0];
                normalized.className = `${baseClass}${expectedSuffix}`;
              }
            } else {
              // If no section provided in CSV, but className has one, extract it
              if (baseClass.includes(' - ')) {
                normalized.section = baseClass.split(' - ')[1].trim().toUpperCase();
              } else {
                normalized.section = 'A'; // default
                normalized.className = `${baseClass} - A`;
              }
            }
          }
          return normalized;
        });

        // Filter out empty or invalid rows before sending to avoid massive payloads
        rows = rows.filter((r: any) => r.name && r.rollNumber && r.className);

        let totalAdded = 0;
        let totalUpdated = 0;
        let hasError = false;

        // Chunk rows to prevent "Failed to fetch" due to payload size limits
        const chunkSize = 100;
        for (let i = 0; i < rows.length; i += chunkSize) {
          const chunk = rows.slice(i, i + chunkSize);
          const res = await fetch('/api/students/bulk-csv', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ students: chunk }),
          });

          if (res.ok) {
            const data = await res.json();
            totalAdded += data.added || 0;
            totalUpdated += data.updated || 0;
          } else {
            hasError = true;
            break;
          }
        }

        if (!hasError) {
          // Extract the first valid class/section from the upload to auto-navigate
          const firstValid = rows.find((r: any) => r.className);
          if (firstValid) {
            setClassName(firstValid.className);
            if (firstValid.section) setSection(firstValid.section);
          }

          alert(`Successfully enrolled ${totalAdded} new students and updated ${totalUpdated} existing students from ${workbook.SheetNames.length} tabs.`);
          fetchStudents();
        } else {
          alert('Failed to upload some students. Please try again.');
        }
      } catch (error) {
        console.error('Error processing file:', error);
        alert('Failed to parse file. Make sure it is a valid Excel or CSV file.');
      } finally {
        setIsUploadingCSV(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      alert("Error reading file.");
      setIsUploadingCSV(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.readAsArrayBuffer(file);
  };

  const [paymentForm, setPaymentForm] = useState<{ amount: string; method: string; remarks: string } | null>(null);

  const handleRecordPayment = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!paymentForm || !selectedStudent) return;
    
    try {
      const res = await fetch('/api/fees/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedStudent.student.id,
          amount: Number(paymentForm.amount),
          method: paymentForm.method,
          remarks: paymentForm.remarks
        })
      });

      if (res.ok) {
        setPaymentForm(null);
        viewStudentDetails(selectedStudent.student.id);
      } else {
        const data = await res.json();
        alert(data.message || 'Failed to record payment');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const buildSinglePDF = (exam: any, student: any) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Examination Result', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, 50);
    
    doc.text("Student Name: " + student.name, 20, 70);
    doc.text("Roll Number: " + student.rollNumber, 20, 80);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 90);
    doc.text("Exam: " + exam.examName, 20, 100);
    
    doc.setLineWidth(0.5);
    doc.line(20, 110, 190, 110);
    
    doc.setFontSize(14);
    doc.text('Subjects', 20, 120);
    doc.text('Marks Obtained', 130, 120);
    
    doc.line(20, 125, 190, 125);
    
    doc.setFontSize(12);
    let y = 135;
    exam.subjects.forEach((subj: any) => {
      doc.text(subj.name, 20, y);
      doc.text(String(subj.obtained), 130, y);
      y += 10;
    });
    
    doc.line(20, y, 190, y);
    y += 10;
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Total", 20, y);
    doc.text(String(exam.obtained) + " / " + String(exam.total), 130, y);

    const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
    let grade = 'F';
    if (Number(percentage) >= 90) grade = 'A+';
    else if (Number(percentage) >= 80) grade = 'A';
    else if (Number(percentage) >= 70) grade = 'B';
    else if (Number(percentage) >= 60) grade = 'C';
    else if (Number(percentage) >= 50) grade = 'D';
    
    y += 10;
    doc.text(`Percentage: ${percentage}% | Grade: ${grade}`, 20, y);
    return doc;
  };

  const downloadMarksResult = (exam: any, student: any, action: 'download' | 'preview' = 'download') => {
    if (action === "preview") {
      setPreviewData({ type: 'single', data: exam, student });
      return;
    }
    const doc = buildSinglePDF(exam, student);
    doc.save(`Result_${student.rollNumber}_${exam.examName.replace(/\s+/g, "_")}.pdf`);
  };

  const buildFullPDF = (displayMarks: any[], student: any) => {
    const doc = new jsPDF();
    let y = 20;
    
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, y, { align: 'center' });
    y += 10;
    
    doc.setFontSize(16);
    doc.text('Full Academic Report', 105, y, { align: 'center' });
    y += 15;

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, y);
    y += 10;
    
    doc.text("Student Name: " + student.name, 20, y);
    y += 10;
    doc.text("Roll Number: " + student.rollNumber, 20, y);
    y += 10;
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, y);
    y += 15;
    
    doc.setLineWidth(0.5);
    doc.line(20, y, 190, y);
    y += 10;
    
    displayMarks.forEach(exam => {
      if (y > 250) {
        doc.addPage();
        y = 20;
      }

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text(exam.examName, 20, y);
      
      if (exam.isBlank) {
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text("Not Recorded", 150, y);
        y += 10;
      } else {
        y += 10;
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text('Subject', 20, y);
        doc.text('Marks', 150, y);
        y += 5;
        doc.line(20, y, 190, y);
        y += 8;

        doc.setFont("helvetica", "normal");
        exam.subjects.forEach((subj: any) => {
          doc.text(subj.name, 20, y);
          doc.text(String(subj.obtained), 150, y);
          y += 8;
        });
        
        doc.line(20, y, 190, y);
        y += 8;
        
        doc.setFont("helvetica", "bold");
        doc.text("Total", 20, y);
        doc.text(String(exam.obtained) + " / " + String(exam.total), 150, y);
        y += 8;
        
        const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
        let grade = 'F';
        if (Number(percentage) >= 90) grade = 'A+';
        else if (Number(percentage) >= 80) grade = 'A';
        else if (Number(percentage) >= 70) grade = 'B';
        else if (Number(percentage) >= 60) grade = 'C';
        else if (Number(percentage) >= 50) grade = 'D';
        doc.text(`Percentage: ${percentage}% | Grade: ${grade}`, 20, y);
        y += 15;
      }
    });
    return doc;
  };

  const downloadFullReportCard = (displayMarks: any[], student: any, action: 'download' | 'preview' = 'download') => {
    if (action === "preview") {
      setPreviewData({ type: 'full', data: displayMarks, student });
      return;
    }
    const doc = buildFullPDF(displayMarks, student);
    doc.save(`Full_Report_${student.rollNumber}.pdf`);
  };

  const sendFullTelegramResult = async (displayMarks: any[], student: any) => {
    setSendingTelegramId('full_report');
    try {
      let message = `*Full Academic Report - ${student.name}*\nRoll No: ${student.rollNumber}\nClass: ${student.className} ${student.section ? '- ' + student.section : ''}\n\n`;
      
      displayMarks.forEach((exam: any) => {
        if (exam.isBlank) return;
        message += `*${exam.examName}*\n`;
        exam.subjects.forEach((subj: any) => {
          message += `${subj.name}: ${subj.obtained}\n`;
        });
        message += `Total: ${exam.obtained}/${exam.total}\n\n`;
      });
      
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }
      
      const doc = buildFullPDF(displayMarks, student);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Full Report sent successfully to ' + student.name);
      } else {
        alert(`Failed to send message: ${data.message}`);
      }
    } catch (err) {
      alert('An error occurred while sending the message.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  const downloadReceipt = (payment: any, student: any) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('EduAI SaaS', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Fee Receipt', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Receipt ID: " + (payment.id || Math.random().toString(36).substring(7).toUpperCase()), 20, 50);
    doc.text("Date: " + new Date(payment.date).toLocaleString(), 20, 60);
    
    doc.text("Student Name: " + student.name, 20, 80);
    doc.text("Roll Number: " + student.rollNumber, 20, 90);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 100);
    
    doc.setLineWidth(0.5);
    doc.line(20, 110, 190, 110);
    
    doc.text('Amount Paid:', 20, 120);
    doc.text("Rs. " + payment.amount, 150, 120);
    
    doc.text('Payment Method:', 20, 130);
    doc.text(payment.method || 'Online', 150, 130);
    
    if (payment.remarks) {
      doc.text('Remarks:', 20, 140);
      doc.text(payment.remarks, 150, 140);
    }
    
    doc.save(`Receipt_${student.rollNumber}_${new Date(payment.date).getTime()}.pdf`);
  };
  const sendReceiptViaTelegram = async (payment: any, student: any) => {
    setSendingTelegramId(payment.id || payment.date);
    try {
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text('EduAI SaaS', 105, 20, { align: 'center' });
      
      doc.setFontSize(16);
      doc.text('Fee Receipt', 105, 30, { align: 'center' });

      doc.setFontSize(12);
      doc.text("Receipt ID: " + (payment.id || Math.random().toString(36).substring(7).toUpperCase()), 20, 50);
      doc.text("Date: " + new Date(payment.date).toLocaleString(), 20, 60);
      
      doc.text("Student Name: " + student.name, 20, 80);
      doc.text("Roll Number: " + student.rollNumber, 20, 90);
      doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 100);
      
      doc.setLineWidth(0.5);
      doc.line(20, 110, 190, 110);
      
      doc.text('Amount Paid:', 20, 120);
      doc.text("Rs. " + payment.amount, 150, 120);
      
      doc.text('Payment Method:', 20, 130);
      doc.text(payment.method || 'Online', 150, 130);
      
      if (payment.remarks) {
        doc.text('Remarks:', 20, 140);
        doc.text(payment.remarks, 150, 140);
      }
      
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const message = `*Fee Receipt*
Receipt ID: ${payment.id || ''}
Date: ${new Date(payment.date).toLocaleString()}
Amount Paid: Rs. ${payment.amount}
Method: ${payment.method || 'Online'}

Thank you!`;
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Receipt sent successfully to ' + student.name);
      } else {
        alert(`Failed to send receipt: ${data.message}`);
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while sending the receipt.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  
  const buildFeeLedgerPDF = (student: any, fees: any) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('EduAI SaaS', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Comprehensive Fee Ledger', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, 50);
    doc.text("Student Name: " + student.name, 20, 60);
    doc.text("Roll Number: " + student.rollNumber, 20, 70);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 80);
    
    doc.setLineWidth(0.5);
    doc.line(20, 90, 190, 90);
    
    // Summary
    doc.setFontSize(14);
    doc.text("Summary:", 20, 100);
    doc.setFontSize(12);
    doc.text("Total Fee: Rs. " + fees.totalFee.toFixed(2), 30, 110);
    doc.text("Total Paid: Rs. " + fees.paidAmount.toFixed(2), 30, 120);
    doc.text("Balance Due: Rs. " + fees.balance.toFixed(2), 30, 130);
    
    doc.line(20, 140, 190, 140);
    
    // Payments Table
    doc.setFontSize(14);
    doc.text("Payment History:", 20, 150);
    doc.setFontSize(12);
    
    let y = 160;
    if (!fees.payments || fees.payments.length === 0) {
      doc.text("No payments recorded.", 30, y);
    } else {
      doc.setFont(undefined, 'bold');
      doc.text("Date", 20, y);
      doc.text("Amount", 70, y);
      doc.text("Method", 120, y);
      doc.setFont(undefined, 'normal');
      y += 10;
      
      fees.payments.forEach((p: any) => {
        doc.text(new Date(p.date).toLocaleDateString(), 20, y);
        doc.text("Rs. " + p.amount, 70, y);
        doc.text(p.method || 'Online', 120, y);
        y += 10;
        if (y > 270) {
          doc.addPage();
          y = 20;
        }
      });
    }
    
    return doc;
  };

  const downloadFeeLedger = (student: any, fees: any) => {
    const doc = buildFeeLedgerPDF(student, fees);
    doc.save(`FeeLedger_${student.rollNumber}_${new Date().getTime()}.pdf`);
  };

  const sendFeeLedgerTelegram = async (student: any, fees: any) => {
    setSendingTelegramId('ledger');
    try {
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = buildFeeLedgerPDF(student, fees);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const message = `*Comprehensive Fee Ledger*\nStudent: ${student.name}\nRoll No: ${student.rollNumber}\n\nPaid Month: ${fees.status}\nTotal Fee: Rs. ${fees.totalFee}\nPaid: Rs. ${fees.paidAmount}\nBalance: Rs. ${fees.balance}\n\nPlease find the attached detailed ledger.`;
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Fee Ledger sent successfully to ' + student.name);
      } else {
        alert(`Failed to send fee ledger: ${data.message}`);
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while sending the fee ledger.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  const sendTelegramResult = async (exam: any, student: any) => {
    setSendingTelegramId(exam.examName);
    try {
      let message = `*Academic Report - ${student.name}*\nRoll No: ${student.rollNumber}\nClass: ${student.className} ${student.section ? '- ' + student.section : ''}\n\n`;
      message += `*${exam.examName}*\n`;
      exam.subjects.forEach((subj: any) => {
        message += `${subj.name}: ${subj.obtained}\n`;
      });
      message += `Total: ${exam.obtained}/${exam.total}\n\n`;
      
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }
      
      const doc = buildSinglePDF(exam, student);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Message sent successfully to ' + student.name);
      } else {
        alert(`Failed to send message: ${data.message}`);
      }
    } catch (err) {
      alert('An error occurred while sending the message.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  const renderDetailView = () => {
    if (!selectedStudent) return null;
    if (selectedStudent.error) return <div className="p-8 text-red-500">Error: {selectedStudent.error}</div>;
    const { student, attendance, fees, marks } = selectedStudent;
    
    return (
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setCurrentView('list')}
            className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white"
          >
            ← Back to Directory
          </button>
        </div>

        {/* Header Card */}
        <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center text-3xl font-extrabold border border-indigo-500/30 overflow-hidden">
              {student.photo ? (
                <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
              ) : (
                student.name.charAt(0)
              )}
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white tracking-tight">{student.name}</h1>
              <div className="text-gray-400 mt-1 flex items-center gap-2">
                <span>Class: {student.className}</span>
                <span className="text-gray-600">|</span>
                <span>Roll No: {student.rollNumber}</span>
              </div>
              <div className="mt-3 inline-flex px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full text-xs font-bold border border-emerald-500/20">
                {student.status || 'Active Student'}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
            <button 
              onClick={() => setEditForm(student)}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Edit size={16} /> Edit Profile
            </button>
            <button 
              onClick={() => setDeleteConfirmId(student.id)}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Trash2 size={16} /> Delete Student
            </button>
          </div>
        </div>

        {/* Sub-navigation */}
        <div className="flex overflow-x-auto border-b border-white/10 hide-scrollbar bg-black/20 rounded-t-2xl px-2 pt-2">
          {[
            { id: 'overview', label: 'Overview', icon: Activity },
            { id: 'attendance', label: 'Attendance', icon: Calendar },
            { id: 'fees', label: 'Fees', icon: IndianRupee },
            { id: 'marks', label: 'Marks', icon: FileText }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setDetailTab(tab.id as any)}
                className={`px-6 py-4 flex items-center gap-2 font-bold border-b-2 whitespace-nowrap transition-colors ${
                  detailTab === tab.id 
                    ? 'border-indigo-400 text-indigo-400' 
                    : 'border-transparent text-gray-500 hover:text-white'
                }`}
              >
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="pt-2">
          {detailTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in">
              <div className="bg-[#151515] border border-white/5 p-6 sm:p-8 rounded-2xl shadow-lg">
                <h3 className="text-lg font-bold text-white mb-6">Personal Information</h3>
                <div className="space-y-5">
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Status:</span>
                    <span className="text-emerald-400 text-sm font-medium">{student.status || 'Active Student'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Class:</span>
                    <span className="text-white text-sm">{student.className}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Date of Birth:</span>
                    <span className="text-white text-sm">{student.dob || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Gender:</span>
                    <span className="text-white text-sm">{student.gender || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Blood Group:</span>
                    <span className="text-white text-sm">{student.bloodGroup || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Admission Date:</span>
                    <span className="text-white text-sm">{student.admissionDate || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Address:</span>
                    <span className="text-white text-sm text-right max-w-[200px] leading-relaxed">
                      {student.address ? `${student.address}${student.city ? ', ' + student.city : ''}${student.state ? ', ' + student.state : ''}${student.pinCode ? ' - ' + student.pinCode : ''}` : 'Not Provided'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-[#151515] border border-white/5 p-6 sm:p-8 rounded-2xl shadow-lg">
                <h3 className="text-lg font-bold text-white mb-6">Parent Information</h3>
                <div className="space-y-5">
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Father's Name:</span>
                    <span className="text-white text-sm">{student.fatherName || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Mother's Name:</span>
                    <span className="text-white text-sm">{student.motherName || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Primary Phone:</span>
                    <span className="text-white text-sm">{student.parentPhone || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Telegram Chat ID:</span>
                    <div className="flex items-center gap-3">
                      <span className="text-white text-sm font-mono">{student.telegramChatId || 'Not Provided'}</span>
                      {student.telegramChatId && (
                        <button 
                          onClick={() => disconnectTelegram(student.id)}
                          className="px-3 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-bold transition-colors"
                        >
                          Disconnect
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Email:</span>
                    <span className="text-white text-sm">{student.email || 'Not Provided'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {detailTab === 'attendance' && (
            <div className="bg-[#151515] border border-white/5 p-6 sm:p-8 rounded-2xl shadow-lg animate-in fade-in">
              <div className="flex flex-wrap items-center justify-between mb-8 gap-4">
                <h3 className="text-lg font-bold text-white">Recent Attendance Record</h3>
                <div className="flex gap-4 text-xs font-medium">
                  <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Present</span>
                  <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-red-500"></div> Absent</span>
                  <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-yellow-500"></div> Late</span>
                </div>
              </div>

              {attendance.length === 0 ? (
                <div className="text-center p-8 border border-dashed border-white/10 rounded-xl text-gray-500">
                  No recent attendance records found.
                </div>
              ) : (
                <div className="flex gap-4 flex-wrap">
                  {attendance.map((rec: any, idx: number) => (
                    <div 
                      key={idx} 
                      className={`p-4 rounded-xl border flex flex-col gap-2 min-w-[120px] ${
                        rec.status === 'Present' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                        rec.status === 'Late' ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400' :
                        'bg-red-500/10 border-red-500/20 text-red-400'
                      }`}
                    >
                      <span className="text-[10px] font-bold tracking-wider uppercase opacity-80">{rec.status}</span>
                      <span className="text-sm font-medium">{rec.date}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {detailTab === 'fees' && (
            <div className="space-y-6 animate-in fade-in">
              <div className="flex justify-between items-center flex-wrap gap-4">
                <h3 className="text-lg font-bold text-white">Fee Ledger & Summary</h3>
                <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                  <button 
                    onClick={() => downloadFeeLedger(student, fees)}
                    className="bg-white/10 hover:bg-white/20 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors"
                  >
                    <Download size={16} /> <span className="hidden sm:inline">Download Ledger</span><span className="sm:hidden">Download</span>
                  </button>
                  <button 
                    onClick={() => sendFeeLedgerTelegram(student, fees)}
                    disabled={sendingTelegramId === 'ledger'}
                    className="bg-[#229ED9]/10 hover:bg-[#229ED9]/20 border border-[#229ED9]/30 text-[#229ED9] px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    {sendingTelegramId === 'ledger' ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} <span className="hidden sm:inline">Send Ledger</span><span className="sm:hidden">Send</span>
                  </button>
                  <button 
                    onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '' })}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors"
                  >
                    <Plus size={16} /> Record Payment
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Fee</div>
                  <div className="text-2xl font-black text-white">₹{fees.totalFee.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Total Paid</div>
                  <div className="text-2xl font-black text-emerald-400">₹{fees.paidAmount.toFixed(2)}</div>
                </div>
                <div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Balance</div>
                  <div className="text-2xl font-black text-red-400">₹{fees.balance.toFixed(2)}</div>
                </div>
              </div>

              <div className="bg-[#151515] border border-white/5 rounded-2xl overflow-hidden mt-6 shadow-lg">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-white/5 border-b border-white/10">
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Date</th>
                      
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Amount</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Mode</th>
                      <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase text-right">Receipt</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fees.payments.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-8 text-center text-gray-500">No payments recorded.</td>
                      </tr>
                    ) : (
                      fees.payments.map((p: any, i: number) => (
                        <tr key={i} className="border-b border-white/5 last:border-0 hover:bg-white/5">
                          <td className="p-5 text-sm text-gray-300">{new Date(p.date).toLocaleDateString()}</td>
                          
                          <td className="p-5 text-sm font-bold text-white">₹{p.amount}</td>
                          <td className="p-5 text-sm text-gray-400">{p.method}</td>
                          <td className="p-5 text-right">
                            <div className="flex items-center justify-end gap-3">
                              <button 
                                onClick={() => downloadReceipt(p, student)}
                                className="text-indigo-400 hover:text-indigo-300 text-sm font-bold flex items-center gap-1.5 transition-colors"
                              >
                                <Download size={14} /> Download
                              </button>
                              <button 
                                onClick={() => sendReceiptViaTelegram(p, student)}
                                disabled={sendingTelegramId === (p.id || p.date)}
                                className="text-[#229ED9] hover:text-[#229ED9]/80 text-sm font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                              >
                                {sendingTelegramId === (p.id || p.date) ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />} Telegram
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {detailTab === 'marks' && (
            <div className="space-y-6 animate-in fade-in">
              {(() => {
                const STANDARD_EXAMS = Array.from(new Set(['Unit Test 1', 'Unit Test 2', 'Mid-year', 'Annual', ...marks.map((m: any) => m.examName)]));
                const allSubjects = new Set(['Maths', 'Science', 'Hindi']);
                marks.forEach((m: any) => m.subjects?.forEach((s: any) => allSubjects.add(s.name)));
                const STANDARD_SUBJECTS = Array.from(allSubjects);
                const displayMarks = STANDARD_EXAMS.map(examName => {
                  const existingExam = marks.find((m: any) => m.examName === examName);
                  if (existingExam) {
                    const paddedSubjects = STANDARD_SUBJECTS.map(subjName => {
                      const found = existingExam.subjects.find((s: any) => s.name === subjName);
                      return found ? found : { name: subjName, obtained: '-' };
                    });
                    return {
                      ...existingExam,
                      subjects: paddedSubjects
                    };
                  }
                  return {
                    examName,
                    total: 0,
                    obtained: 0,
                    isBlank: true,
                    subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
                  };
                });

                return (
                  <>
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-2">
                      <h3 className="text-lg font-bold text-white">Examination Results</h3>
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => downloadFullReportCard(displayMarks, selectedStudent.student, 'preview')}
                          className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-sm font-bold px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                        >
                          <Eye size={16} /> Preview Report
                        </button>
                        <button 
                          onClick={() => sendFullTelegramResult(displayMarks, selectedStudent.student)}
                          disabled={sendingTelegramId === 'full_report'}
                          className="bg-[#229ED9] hover:bg-[#1CA0DE] disabled:opacity-50 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors shadow-lg flex items-center justify-center gap-2"
                        >
                          {sendingTelegramId === 'full_report' ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} Telegram
                        </button>
                        <button 
                          onClick={() => downloadFullReportCard(displayMarks, selectedStudent.student)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
                        >
                          <Download size={16} /> Download
                        </button>
                      </div>
                    </div>
                    {displayMarks.map((exam: any, idx: number) => {
                  const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
                  let grade = '-';
                  if (!exam.isBlank) {
                    if (Number(percentage) >= 90) grade = 'A+';
                    else if (Number(percentage) >= 80) grade = 'A';
                    else if (Number(percentage) >= 70) grade = 'B';
                    else if (Number(percentage) >= 60) grade = 'C';
                    else if (Number(percentage) >= 50) grade = 'D';
                    else grade = 'F';
                  }

                  return (
                    <div key={idx} className="bg-[#151515] border border-white/5 rounded-2xl overflow-hidden shadow-lg">
                      <div className="p-5 bg-white/5 border-b border-white/10 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                        <h4 className="font-bold text-white">{exam.examName}</h4>
                        <div className="flex items-center gap-3">
                          <>
                            {exam.isBlank ? (
                              <div className="px-4 py-1.5 bg-gray-500/10 text-gray-400 rounded-full text-xs font-bold border border-gray-500/20 whitespace-nowrap text-center mr-2">
                                Not Recorded
                              </div>
                            ) : (
                              <div className="px-4 py-1.5 bg-indigo-500/10 text-indigo-300 rounded-full text-xs font-bold border border-indigo-500/20 whitespace-nowrap text-center mr-2">
                                Total: {exam.obtained} / {exam.total} | Grade: {grade} ({percentage}%)
                              </div>
                            )}
                            <button 
                              onClick={() => downloadMarksResult(exam, selectedStudent.student, 'preview')}
                              className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                              title="Preview PDF"
                            >
                              <Eye size={18} />
                            </button>
                            <button 
                              onClick={() => sendTelegramResult(exam, selectedStudent.student)}
                              disabled={sendingTelegramId === exam.examName}
                              className="p-1.5 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors disabled:opacity-50"
                              title="Send via Telegram"
                            >
                              {sendingTelegramId === exam.examName ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                            </button>
                            <button 
                              onClick={() => downloadMarksResult(exam, selectedStudent.student)}
                              className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                              title="Download PDF"
                            >
                              <Download size={18} />
                            </button>
                          </>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="border-b border-white/10 bg-black/20 text-xs font-bold text-gray-500 uppercase tracking-wider">
                              <th className="p-4 whitespace-nowrap">Subject</th>
                              <th className="p-4 whitespace-nowrap text-right">Marks Obtained</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {exam.subjects.map((s: any, i: number) => (
                              <tr key={i} className="hover:bg-white/5 transition-colors">
                                <td className="p-4 text-sm text-gray-300">{s.name}</td>
                                <td className={`p-4 text-sm font-bold text-right ${exam.isBlank ? 'text-gray-600' : 'text-white'}`}>{s.obtained}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}
                </>
                );
              })()}
            </div>
          )}
        </div>
      </div>
    );
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const handlePromoteSelected = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (selectedIds.length === 0) return;
    setIsPromoting(true);
    try {
      const res = await fetch('/api/students/promote-selected', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentIds: selectedIds,
          toClassName: promoteModal.toClass
        })
      });
      if (res.ok) {
        setSelectedIds([]);
        setPromoteModal({ ...promoteModal, isOpen: false });
        fetchStudents();
      }
    } catch (e) {
      console.error(e);
    }
    setIsPromoting(false);
  };

  // LIST VIEW
  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    setShowDeleteConfirm(true);
  };

  const executeDeleteSelected = async () => {
    setIsDeleting(true);
    try {
      const res = await fetch('/api/students/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentIds: selectedIds })
      });
      if (res.ok) {
        setSelectedIds([]);
        setShowDeleteConfirm(false);
        fetchStudents();
      }
    } catch (e) {
      console.error(e);
    }
    setIsDeleting(false);
  };

  const renderListView = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white tracking-tight">Student Directory</h1>
        <div className="flex gap-3 flex-wrap items-center">
          <button
            onClick={() => {
              if (selectedIds.length === students.length && students.length > 0) {
                setSelectedIds([]);
              } else {
                setSelectedIds(students.map(s => s.id));
              }
            }}
            className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/20 px-4 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            {selectedIds.length === students.length && students.length > 0 ? 'Deselect All' : 'Select All'}
          </button>

                    {selectedIds.length > 0 && (
            <>
              <button 
                onClick={handleDeleteSelected}
                className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                <Trash2 size={18} /> Delete All Students
              </button>
              <button 
                onClick={() => setPromoteModal({ isOpen: true, toClass: classes[2] || classes[1], actionType: 'reassign' })}
                className="bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                Reassign Selected ({selectedIds.length})
              </button>
            </>
          )}
          <input 
            type="file" 
            accept=".csv, .xlsx, .xls" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleCSVUpload} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploadingCSV}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-500/20"
          >
            {isUploadingCSV ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />}
            Bulk Upload CSV
          </button>
          <button 
            onClick={() => setEditForm({ name: '', rollNumber: '', className: classes[1], section: sections[1] })}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20"
          >
            <Plus size={18} /> Enroll Student
          </button>
        </div>
      </div>

      <div className="bg-[#151515] border border-white/5 p-4 rounded-2xl flex flex-col md:flex-row gap-4 shadow-lg">
        <div className="flex-1 relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Search by name or roll no"
            className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 transition-colors"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <select 
            className="w-full sm:w-48 px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
            value={className}
            onChange={(e) => setClassName(e.target.value)}
          >
            {classes.map(c => <option key={c}>{c}</option>)}
          </select>
          <select 
            className="w-full sm:w-40 px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
            value={section}
            onChange={(e) => setSection(e.target.value)}
          >
            {sections.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

            <div>
        {loading ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">Loading directory...</div>
        ) : students.length === 0 ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No students found matching your criteria.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {students.map((student) => (
              <div 
                key={student.id} 
                className={`bg-[#151515] border ${selectedIds.includes(student.id) ? 'border-indigo-500 shadow-lg shadow-indigo-500/10' : 'border-white/5 hover:border-white/10'} rounded-2xl overflow-hidden transition-all group flex flex-col`}
              >
                {/* Card Header (Avatar & Name) */}
                <div 
                  className="p-5 cursor-pointer relative"
                  onClick={() => viewStudentDetails(student.id)}
                >
                  <div className="absolute top-4 left-4 z-10" onClick={(e) => e.stopPropagation()}>
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                      checked={selectedIds.includes(student.id)}
                      onChange={() => toggleSelectStudent(student.id)}
                    />
                  </div>
                  
                  <div className="flex flex-col items-center mt-2">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner overflow-hidden">
                      {student.photo ? (
                        <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl font-bold text-indigo-300">
                          {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{student.name}</h3>
                    <div className="text-xs text-gray-400 mt-1 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                      Roll No: {student.rollNumber}
                    </div>
                  </div>
                </div>

                {/* Card Body (Details) */}
                <div 
                  className="px-5 pb-5 cursor-pointer flex-1 flex flex-col justify-center"
                  onClick={() => viewStudentDetails(student.id)}
                >
                  <div className="space-y-3 mt-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Class</span>
                      <span className="font-semibold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">{student.className}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Phone</span>
                      <span className="text-gray-300">{student.parentPhone || '-'}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Telegram</span>
                      <span className="text-gray-300 flex items-center gap-1.5">
                        {student.telegramChatId || '-'}
                        {student.telegramChatId && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); disconnectTelegram(student.id); }}
                            className="p-1 text-red-400 hover:bg-red-500/10 rounded transition-colors"
                            title="Disconnect Telegram"
                          >
                            <Unlink size={12} />
                          </button>
                        )}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Footer (Actions) */}
                <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                  <button 
                    onClick={() => viewStudentDetails(student.id)} 
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                  >
                    <Eye size={14} /> View
                  </button>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => { setEditForm(student); setCurrentView('enroll'); }} 
                      className="p-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded transition-colors"
                      title="Edit Profile"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(student.id)} 
                      className="p-1.5 text-red-400 hover:bg-red-500/10 rounded transition-colors"
                      title="Delete Student"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {currentView === 'detail' ? renderDetailView() : renderListView()}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-sm w-full mx-4 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">Delete Student</h3>
            <p className="text-gray-400 mb-8">Are you sure you want to delete this student? This action cannot be undone.</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-colors shadow-lg shadow-red-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit/Enroll Modal */}
      {editForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-2xl w-full my-auto shadow-2xl relative">
            <button 
              onClick={() => setEditForm(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            <h3 className="text-xl font-bold text-white mb-6">
              {students.some(s => s.id === editForm.id) ? 'Edit Profile' : 'Enroll Student'}
            </h3>
            
            <form onSubmit={handleSaveStudent} className="space-y-6">
              <div className="flex flex-col items-center mb-6">
                <div className="relative mb-3">
                  <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-dashed border-indigo-500/50 flex items-center justify-center relative overflow-hidden group">
                    {editForm.photo ? (
                      <img src={editForm.photo} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-3xl font-bold text-indigo-400">{editForm.name ? editForm.name.charAt(0) : '?'}</span>
                    )}
                    <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                      <span className="text-white text-xs font-bold">{editForm.photo ? 'Change' : 'Upload'}</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                  {editForm.photo && (
                    <button
                      type="button"
                      onClick={() => setEditForm({ ...editForm, photo: undefined })}
                      className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-colors z-10"
                      title="Remove Photo"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
                <div className="text-xs text-gray-500 text-center">Recommended: Square image, max 2MB</div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Full Name *</label>
                  <input required type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.name || ''} onChange={e => setEditForm({...editForm, name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Roll Number *</label>
                  <input required type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors disabled:opacity-50" 
                    value={editForm.rollNumber || ''} onChange={e => setEditForm({...editForm, rollNumber: e.target.value})} 
                    disabled={students.some(s => s.id === editForm.id)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Class *</label>
                  <select required className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                    value={editForm.className || ''} onChange={e => setEditForm({...editForm, className: e.target.value})}>
                    {classes.filter(c => c !== 'All Classes').map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Section *</label>
                  <select required className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                    value={editForm.section || ''} onChange={e => setEditForm({...editForm, section: e.target.value})}>
                    {sections.filter(s => s !== 'All Sections').map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Gender</label>
                  <select className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                    value={editForm.gender || ''} onChange={e => setEditForm({...editForm, gender: e.target.value})}>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Father's Name</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.fatherName || ''} onChange={e => setEditForm({...editForm, fatherName: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Mother's Name</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.motherName || ''} onChange={e => setEditForm({...editForm, motherName: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Parent Phone</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.parentPhone || ''} onChange={e => setEditForm({...editForm, parentPhone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Telegram Chat ID</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" placeholder="e.g. 123456" 
                    value={editForm.telegramChatId || ''} onChange={e => setEditForm({...editForm, telegramChatId: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Date of Birth</label>
                  <input type="date" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.dob || ''} onChange={e => setEditForm({...editForm, dob: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                  <input type="email" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.email || ''} onChange={e => setEditForm({...editForm, email: e.target.value})} />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Address</label>
                <textarea className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors resize-none" rows={3}
                  value={editForm.address || ''} onChange={e => setEditForm({...editForm, address: e.target.value})}></textarea>
              </div>

              <div className="flex justify-end gap-4 pt-4 border-t border-white/10">
                <button type="button" onClick={() => setEditForm(null)} className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors">
                  Cancel
                </button>
                <button type="submit" className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-indigo-500/20">
                  Save Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {paymentForm && selectedStudent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full my-auto shadow-2xl relative">
            <button 
              onClick={() => setPaymentForm(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            <h3 className="text-xl font-bold text-white mb-6">
              Record Fee Payment
            </h3>
            
            <form onSubmit={handleRecordPayment} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Amount Paid (₹) *</label>
                <input 
                  required 
                  type="number" 
                  min="1"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={paymentForm.amount} 
                  onChange={e => setPaymentForm({...paymentForm, amount: e.target.value})} 
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Payment Method *</label>
                <select 
                  required 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                  value={paymentForm.method} 
                  onChange={e => setPaymentForm({...paymentForm, method: e.target.value})}
                >
                  <option>Online</option>
                  <option>Cash</option>
                  <option>Cheque</option>
                  <option>Bank Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Remarks / Notes</label>
                <textarea 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors resize-none" 
                  rows={2}
                  value={paymentForm.remarks} 
                  onChange={e => setPaymentForm({...paymentForm, remarks: e.target.value})}
                ></textarea>
              </div>

              <div className="flex justify-end gap-4 pt-4 border-t border-white/10">
                <button type="button" onClick={() => setPaymentForm(null)} className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors">
                  Cancel
                </button>
                <button type="submit" className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-emerald-500/20">
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Promote Modal */}
      {promoteModal.isOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setPromoteModal({ ...promoteModal, isOpen: false })}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            
            <h3 className="text-xl font-bold text-white mb-6">Reassign Selected Students</h3>
            <p className="text-sm text-gray-400 mb-6">You are about to reassign {selectedIds.length} student(s) to a new class.</p>

            <form onSubmit={handlePromoteSelected} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Reassign To Class</label>
                <div className="relative">
                  <select 
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                    value={promoteModal.toClass}
                    onChange={e => setPromoteModal({...promoteModal, toClass: e.target.value})}
                  >
                    {classes.filter(c => c !== 'All Classes').map(c => <option key={c} value={c} className="bg-[#151515] text-white">{c}</option>)}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-2">
                <button 
                  type="button" 
                  onClick={() => setPromoteModal({ ...promoteModal, isOpen: false })}
                  className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={isPromoting}
                  className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isPromoting ? 'Processing...' : 'Confirm Reassign'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {previewData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 animate-in fade-in bg-black/60 backdrop-blur-sm">
          <div className="bg-[#151515] rounded-2xl w-full max-w-5xl h-[90vh] border border-white/10 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <FileText className="text-blue-400" /> Report Preview
              </h3>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => {
                    if (previewData.type === 'single') {
                      downloadMarksResult(previewData.data, previewData.student, 'download');
                    } else {
                      downloadFullReportCard(previewData.data, previewData.student, 'download');
                    }
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors shadow-lg flex items-center gap-2"
                >
                  <Download size={16} /> Download PDF
                </button>
                <button
                  onClick={() => setPreviewData(null)}
                  className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
            <div className="flex-1 p-8 bg-gray-100 overflow-y-auto">
              <div className="max-w-4xl mx-auto bg-white p-10 rounded-xl shadow-sm text-black">
                <div className="text-center mb-8 border-b-2 border-black pb-6">
                  <h1 className="text-4xl font-black uppercase tracking-widest text-gray-900">SchoolWise</h1>
                  <h2 className="text-2xl mt-2 text-gray-700">
                    {previewData.type === 'single' ? 'Examination Result' : 'Full Academic Report'}
                  </h2>
                </div>
                
                <div className="mb-8 grid grid-cols-2 gap-4 text-base">
                  <div>
                    <p className="mb-1"><span className="font-bold text-gray-600">Student Name:</span> <span className="font-semibold">{previewData.student.name}</span></p>
                    <p className="mb-1"><span className="font-bold text-gray-600">Roll Number:</span> <span className="font-semibold">{previewData.student.rollNumber}</span></p>
                    <p className="mb-1"><span className="font-bold text-gray-600">Class:</span> <span className="font-semibold">{previewData.student.className} {previewData.student.section ? `- ${previewData.student.section}` : ''}</span></p>
                  </div>
                  <div className="text-right">
                    <p className="mb-1"><span className="font-bold text-gray-600">Date:</span> <span className="font-semibold">{new Date().toLocaleDateString()}</span></p>
                    {previewData.type === 'single' && (
                      <p className="mb-1"><span className="font-bold text-gray-600">Exam:</span> <span className="font-semibold">{previewData.data.examName}</span></p>
                    )}
                  </div>
                </div>

                {previewData.type === 'single' ? (
                  <div className="border border-gray-300 rounded-lg overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-gray-100 border-b border-gray-300">
                          <th className="p-4 font-bold text-gray-700">Subject</th>
                          <th className="p-4 font-bold text-gray-700 text-right">Marks Obtained</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {previewData.data.subjects.map((subj: any, idx: number) => (
                          <tr key={idx}>
                            <td className="p-4">{subj.name}</td>
                            <td className="p-4 text-right font-medium">{subj.obtained}</td>
                          </tr>
                        ))}
                        <tr className="bg-gray-50 font-bold text-lg border-t-2 border-gray-300">
                          <td className="p-4">Total</td>
                          <td className="p-4 text-right">{previewData.data.obtained} / {previewData.data.total}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="space-y-10">
                    {previewData.data.map((exam: any, idx: number) => (
                      <div key={idx} className="break-inside-avoid">
                        <h3 className="text-xl font-bold mb-3 border-b border-gray-300 pb-2 text-gray-800">{exam.examName}</h3>
                        {exam.isBlank ? (
                          <div className="p-6 bg-gray-50 rounded-lg border border-gray-200 text-center">
                            <p className="text-gray-500 italic font-medium">Scores Not Recorded</p>
                          </div>
                        ) : (
                          <div className="border border-gray-300 rounded-lg overflow-hidden mb-3">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="bg-gray-100 border-b border-gray-300">
                                  <th className="p-3 font-bold text-gray-700">Subject</th>
                                  <th className="p-3 font-bold text-gray-700 text-right">Marks Obtained</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-gray-200">
                                {exam.subjects.map((subj: any, sIdx: number) => (
                                  <tr key={sIdx}>
                                    <td className="p-3">{subj.name}</td>
                                    <td className="p-3 text-right font-medium">{subj.obtained}</td>
                                  </tr>
                                ))}
                                <tr className="bg-gray-50 font-bold border-t-2 border-gray-300">
                                  <td className="p-3">Total</td>
                                  <td className="p-3 text-right">{exam.obtained} / {exam.total}</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        )}
                        {!exam.isBlank && (() => {
                          const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
                          let grade = 'F';
                          if (Number(percentage) >= 90) grade = 'A+';
                          else if (Number(percentage) >= 80) grade = 'A';
                          else if (Number(percentage) >= 70) grade = 'B';
                          else if (Number(percentage) >= 60) grade = 'C';
                          else if (Number(percentage) >= 50) grade = 'D';
                          return (
                            <div className="text-right font-bold text-lg text-gray-800 pr-2">
                              Percentage: <span className={Number(percentage) >= 50 ? 'text-green-600' : 'text-red-600'}>{percentage}%</span> | Grade: {grade}
                            </div>
                          );
                        })()}
                      </div>
                    ))}
                  </div>
                )}

                {previewData.type === 'single' && (() => {
                  const percentage = previewData.data.total > 0 ? ((previewData.data.obtained / previewData.data.total) * 100).toFixed(0) : '0';
                  let grade = 'F';
                  if (Number(percentage) >= 90) grade = 'A+';
                  else if (Number(percentage) >= 80) grade = 'A';
                  else if (Number(percentage) >= 70) grade = 'B';
                  else if (Number(percentage) >= 60) grade = 'C';
                  else if (Number(percentage) >= 50) grade = 'D';
                  return (
                    <div className="mt-6 text-right font-bold text-xl text-gray-800 pr-2">
                      Percentage: <span className={Number(percentage) >= 50 ? 'text-green-600' : 'text-red-600'}>{percentage}%</span> | Grade: {grade}
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-2">Delete Students</h3>
            <p className="text-gray-400 mb-6">Are you sure you want to delete {selectedIds.length} student(s)? This action cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 rounded-xl text-gray-300 hover:bg-white/5 transition-colors"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                onClick={executeDeleteSelected}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white transition-colors flex items-center gap-2"
                disabled={isDeleting}
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
