import { useEffect as UseEffectExams } from 'react';
import { useClasses } from '../../hooks/useClasses';
import { useState } from 'react';
import { UploadMarks } from './UploadMarks';
import { ProcessedDataList } from './ProcessedDataList';
import { ProcessingJobsList } from './ProcessingJobsList';
import { PendingVerificationList } from './PendingVerificationList';
import { Save, AlertCircle, Lock, Loader2, CheckCircle2, Download, FileText, Check, Send, X } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { User } from '../../types';

interface StudentMarks {
  rollNumber?: string;
  id: string;
  name: string;
  maths: string;
  science: string;
  hindi: string;
}

interface ExamsProps {
  user?: User;
  onUpdateUser?: (updated: User) => void;
}

export function Exams({ user, onUpdateUser }: ExamsProps = {}) {
  const [activeTab, setActiveTab] = useState<'results' | 'enter' | 'upload' | 'processing' | 'pending' | 'processed'>('enter');
  
  const { classes } = useClasses();
  const baseClasses = Array.from(new Set(classes.map(c => c.split(' - ')[0])));
  const sections = Array.from(new Set(classes.map(c => c.split(' - ')[1] || 'A'))).sort();

  // Enter Marks state
  const [selectedExam, setSelectedExam] = useState('Unit Test 1');
  const [maxMarks, setMaxMarks] = useState<number>(100);
  const [enterClass, setEnterClass] = useState('');
  const [enterSection, setEnterSection] = useState('');
  const [isGridLoaded, setIsGridLoaded] = useState(false);
  
  // Conflict Resolution State
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [conflicts, setConflicts] = useState<any[]>([]);
  const [resolvedConflicts, setResolvedConflicts] = useState<Record<string, 'old' | 'new'>>({});

  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [savingStudentId, setSavingStudentId] = useState<string | null>(null);
  const [students, setStudents] = useState<StudentMarks[]>([]);

  // Results state
  const [resultClass, setResultClass] = useState('');
  const [resultSection, setResultSection] = useState('');
  const [resultExamType, setResultExamType] = useState('Full Result');
  const [isResultLoaded, setIsResultLoaded] = useState(false);
  const [resultStudents, setResultStudents] = useState<any[]>([]);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);


  const [availableExams, setAvailableExams] = useState<string[]>(['Unit Test 1', 'Unit Test 2', 'Mid-year', 'Annual']);
  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);
  const [isSendingBulk, setIsSendingBulk] = useState(false);
  const [telegramStatus, setTelegramStatus] = useState<Record<string, 'sent' | 'failed' | 'pending'>>({});

  UseEffectExams(() => {
    if (classes.length > 0) {
      const cls = classes[0].split(' - ')[0];
      const sec = classes[0].split(' - ')[1] || 'A';
      if (!enterClass) setEnterClass(cls);
      if (!enterSection) setEnterSection(sec);
      if (!resultClass) setResultClass('All');
      if (!resultSection) setResultSection(sec);
    }
  }, [classes, enterClass, enterSection, resultClass, resultSection]);

  UseEffectExams(() => {
    const fetchExams = async () => {
      try {
        const response = await fetch('/api/exams/analysis');
        const data = await response.json();
        const defaultExams = ['Unit Test 1', 'Unit Test 2', 'Mid-year', 'Annual'];
        const uniqueExams = Array.from(new Set([...defaultExams, ...data.map((r: any) => r.examType)])).sort() as string[];
        if (uniqueExams.length > 0) {
          setAvailableExams(uniqueExams);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchExams();
  }, []);

  const handleMarkChange = (id: string, subject: keyof StudentMarks, value: string) => {
    // Only allow empty or numbers
    if (value !== '' && !/^\d+$/.test(value)) return;

    if (value !== '') {
      const num = parseInt(value, 10);
      if (num > maxMarks) {
        alert(`Maximum marks allowed is ${maxMarks}`);
        return;
      }
    }
    
    setStudents(students.map(s => {
      if (s.id === id) {
        return { ...s, [subject]: value };
      }
      return s;
    }));
  };

  const calculateTotal = (student: StudentMarks) => {
    const m = parseInt(student.maths) || 0;
    const s = parseInt(student.science) || 0;
    const h = parseInt(student.hindi) || 0;
    return m + s + h;
  };

  const loadGrid = async () => {
    setIsGridLoaded(false);
    try {
      const res = await fetch(`/api/students?className=${encodeURIComponent(enterClass + ' - ' + enterSection)}`);
      const data = await res.json();
      
      const marksRes = await fetch(`/api/marks/all?className=${encodeURIComponent(enterClass)}&section=${encodeURIComponent(enterSection)}`);
      let existingMarks: any = {};
      if (marksRes.ok) {
        existingMarks = await marksRes.json();
      }
      
      const filtered = data.filter((s: any) => s.section === enterSection);
      const formattedStudents = filtered.map((s: any) => {
        let maths = '', science = '', hindi = '', english = '', socialScience = '', computer = '';
        
        if (existingMarks[s.id]) {
          const studentExams = existingMarks[s.id];
          const currentExam = studentExams.find((e: any) => e.examName === selectedExam);
          
          if (currentExam && currentExam.subjects) {
            const getMark = (subjName: string) => {
              const subj = currentExam.subjects.find((sub: any) => sub.name === subjName);
              return subj && subj.obtained !== "0" && subj.obtained !== 0 ? String(subj.obtained) : (subj?.obtained === "0" || subj?.obtained === 0 ? "0" : "");
            };
            
            maths = getMark('Maths');
            science = getMark('Science');
            hindi = getMark('Hindi');
            english = getMark('English');
            socialScience = getMark('Social Science');
            computer = getMark('Computer');
          }
        }
        
        return {
          id: s.id,
          rollNumber: s.rollNumber,
          name: s.name,
          maths,
          science,
          hindi,
          english,
          socialScience,
          computer
        };
      });
      
      setStudents(formattedStudents);
      setIsGridLoaded(true);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveMarks = async (skipConflictCheck = false) => {
    setIsSaving(true);
    setIsSaved(false);
    
    try {
      if (!skipConflictCheck) {
        // Fetch existing marks to check for conflicts
        const marksRes = await fetch(`/api/marks/all?className=${encodeURIComponent(enterClass)}&section=${encodeURIComponent(enterSection)}`);
        if (marksRes.ok) {
          const marksData = await marksRes.json();
          const newConflicts: any[] = [];
          
          students.forEach(student => {
            const existingStudentExams = marksData[student.id] || [];
            const existingExam = existingStudentExams.find((e: any) => e.examName === selectedExam);
            if (existingExam) {
              const checkSubject = (subjName: string, newValue: string) => {
                if (newValue !== '') {
                  const existingSubj = existingExam.subjects.find((s: any) => s.name === subjName);
                  if (existingSubj && existingSubj.obtained !== newValue) {
                    newConflicts.push({
                      id: `${student.id}-${subjName}`,
                      studentId: student.id,
                      studentName: student.name,
                      rollNumber: student.rollNumber,
                      subject: subjName,
                      oldMark: existingSubj.obtained,
                      newMark: newValue
                    });
                  }
                }
              };
              checkSubject('Maths', student.maths || '');
              checkSubject('Science', student.science || '');
              checkSubject('Hindi', student.hindi || '');
            }
          });

          if (newConflicts.length > 0) {
            setConflicts(newConflicts);
            setResolvedConflicts({});
            setShowConflictModal(true);
            setIsSaving(false);
            return;
          }
        }
      }

      await fetch('/api/exams/save-grid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examName: selectedExam,
          className: enterClass,
          section: enterSection,
          students,
          maxMarks
        })
      });
      setIsSaved(true);
      setShowConflictModal(false);
      setTimeout(() => setIsSaved(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleResolveConflict = (conflictId: string, choice: 'old' | 'new') => {
    setResolvedConflicts(prev => ({ ...prev, [conflictId]: choice }));
    
    // Update the students array if 'old' is chosen
    if (choice === 'old') {
      const conflict = conflicts.find(c => c.id === conflictId);
      if (conflict) {
        setStudents(prev => prev.map(s => {
          if (s.id === conflict.studentId) {
            return { ...s, [conflict.subject.toLowerCase()]: conflict.oldMark };
          }
          return s;
        }));
      }
    }
  };
  
  const handleResolveAll = (choice: 'old' | 'new') => {
    const newResolved: Record<string, 'old' | 'new'> = {};
    conflicts.forEach(c => {
      newResolved[c.id] = choice;
      if (choice === 'old') {
        setStudents(prev => prev.map(s => {
          if (s.id === c.studentId) {
            return { ...s, [c.subject.toLowerCase()]: c.oldMark };
          }
          return s;
        }));
      }
    });
    setResolvedConflicts(newResolved);
  };


  
  const handleSaveIndividual = async (student: StudentMarks) => {
    setSavingStudentId(student.id);
    try {
      await fetch('/api/exams/save-grid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examName: selectedExam,
          className: enterClass,
          section: enterSection,
          students: [student],
          maxMarks
        })
      });
      // Keeping it active for a second to show success feedback
      setTimeout(() => setSavingStudentId(null), 1000);
    } catch (err) {
      console.error(err);
      setSavingStudentId(null);
    }
  };

  const loadResults = async () => {
    setIsResultLoaded(false);
    try {
      let res;
      let data;
      
      let fullClassName = resultClass;
      if (resultClass !== 'All' && resultSection && resultSection !== 'All') {
        fullClassName = resultClass + ' - ' + resultSection;
      }
      
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        res = await fetch(`/api/students?className=${encodeURIComponent(fullClassName)}`);
        data = await res.json();
      }
      
      const clsQuery = resultClass === 'All' ? 'All Classes' : fullClassName;
      let actualSection = resultSection;
      if (resultClass !== 'All' && resultClass.includes(' - ')) {
        actualSection = resultClass.split(' - ')[1];
      }
      const secQuery = resultClass === 'All' ? 'All Sections' : actualSection;
      const marksRes = await fetch(`/api/marks/all?className=${encodeURIComponent(clsQuery)}&section=${encodeURIComponent(secQuery)}`);
      const marksData = await marksRes.json();
      
      const STANDARD_SUBJECTS = ['Maths', 'Science', 'Hindi'];
      
      const studentsWithMarks = data.map((student: any) => {
        const studentRawMarks = marksData[student.id] || [];
        const displayMarks = availableExams.map(examName => {
          const existingExam = studentRawMarks.find((m: any) => m.examName === examName);
          if (existingExam) return existingExam;
          return {
            examName,
            total: 0,
            obtained: 0,
            isBlank: true,
            subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
          };
        });
        return { ...student, examMarks: displayMarks };
      });
      
      setResultStudents(studentsWithMarks);
      setSelectedResults([]);
      setIsResultLoaded(true);
    } catch (err) {
      console.error(err);
    }
  };

  const buildPDF = (displayMarks: any[], student: any, examType: string) => {
    const doc = new jsPDF();
    let y = 20;
    
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, y, { align: 'center' });
    y += 10;
    
    doc.setFontSize(16);
    doc.text(examType === 'Full Result' ? 'Full Academic Report' : `${examType} Result`, 105, y, { align: 'center' });
    y += 15;

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, y);
    y += 10;
    
    doc.text("Student Name: " + student.name, 20, y);
    y += 10;
    doc.text("Roll Number: " + student.rollNumber, 20, y);
    y += 10;
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, y);
    y += 15;
    
    doc.setLineWidth(0.5);
    doc.line(20, y, 190, y);
    y += 10;
    
    displayMarks.forEach(exam => {
      if (y > 250) {
        doc.addPage();
        y = 20;
      }

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text(exam.examName, 20, y);
      
      if (exam.isBlank) {
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text("Not Recorded", 150, y);
        y += 10;
      } else {
        y += 10;
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text('Subject', 20, y);
        doc.text('Marks', 150, y);
        y += 5;
        doc.line(20, y, 190, y);
        y += 8;

        doc.setFont("helvetica", "normal");
        exam.subjects.forEach((subj: any) => {
          doc.text(subj.name, 20, y);
          doc.text(String(subj.obtained), 150, y);
          y += 8;
        });
        
        doc.line(20, y, 190, y);
        y += 8;
        
        doc.setFont("helvetica", "bold");
        doc.text("Total", 20, y);
        doc.text(String(exam.obtained) + " / " + String(exam.total), 150, y);
        y += 8;
        
        const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
        let grade = 'F';
        if (Number(percentage) >= 90) grade = 'A+';
        else if (Number(percentage) >= 80) grade = 'A';
        else if (Number(percentage) >= 70) grade = 'B';
        else if (Number(percentage) >= 60) grade = 'C';
        else if (Number(percentage) >= 50) grade = 'D';

        doc.text(`Percentage: ${percentage}% | Grade: ${grade}`, 20, y);
        y += 15;
      }
    });
    
    return doc;
  };

  const generatePDF = (displayMarks: any[], student: any, examType: string) => {
    const doc = buildPDF(displayMarks, student, examType);
    doc.save(`${examType === 'Full Result' ? 'Full_Report' : examType.replace(/\s+/g, '_')}_${student.rollNumber}.pdf`);
  };

  const getStudentMarks = async (studentId: string) => {
    try {
      const res = await fetch(`/api/students/${studentId}/details`);
      const data = await res.json();
      
      const STANDARD_SUBJECTS = ['Maths', 'Science', 'Hindi'];
      const displayMarks = availableExams.map(examName => {
        const existingExam = data.marks.find((m: any) => m.examName === examName);
        if (existingExam) return existingExam;
        return {
          examName,
          total: 0,
          obtained: 0,
          isBlank: true,
          subjects: STANDARD_SUBJECTS.map(name => ({ name, obtained: '-' }))
        };
      });
      return displayMarks;
    } catch (err) {
      console.error(err);
      return [];
    }
  };

  const downloadIndividualResult = async (student: any) => {
    setIsDownloading(true);
    let marks = student.examMarks || await getStudentMarks(student.id);
    if (resultExamType !== 'Full Result') {
      marks = marks.filter((m: any) => m.examName === resultExamType);
    }
    generatePDF(marks, student, resultExamType);
    setIsDownloading(false);
  };

  const sendTelegramResult = async (student: any) => {
    setSendingTelegramId(student.id);
    setTelegramStatus(prev => ({ ...prev, [student.id]: 'pending' }));
    try {
      let marks = student.examMarks || await getStudentMarks(student.id);
      if (resultExamType !== 'Full Result') {
        marks = marks.filter((m: any) => m.examName === resultExamType);
      }
      
      let message = `*Academic Report - ${student.name}*\nRoll No: ${student.rollNumber}\nClass: ${student.className} ${student.section ? '- ' + student.section : ''}\n\n`;
      
      marks.forEach((exam: any) => {
        if (exam.isBlank) return;
        message += `*${exam.examName}*\n`;
        exam.subjects.forEach((subj: any) => {
          message += `${subj.name}: ${subj.obtained}\n`;
        });
        message += `Total: ${exam.obtained}/${exam.total}\n\n`;
      });
      
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = buildPDF(marks, student, resultExamType);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        setTelegramStatus(prev => ({ ...prev, [student.id]: 'sent' }));
        alert('Message sent successfully to ' + student.name);
      } else {
        setTelegramStatus(prev => ({ ...prev, [student.id]: 'failed' }));
        alert(`Failed to send message: ${data.message}`);
      }
    } catch (err) {
      setTelegramStatus(prev => ({ ...prev, [student.id]: 'failed' }));
      alert('An error occurred while sending the message.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  const sendBulkTelegramResults = async () => {
    if (selectedResults.length === 0) return;
    setIsSendingBulk(true);
    let successCount = 0;
    let failCount = 0;

    for (const id of selectedResults) {
      setTelegramStatus(prev => ({ ...prev, [id]: 'pending' }));
      const student = resultStudents.find(s => s.id === id);
      if (!student) continue;

      try {
        let marks = student.examMarks || await getStudentMarks(id);
        if (resultExamType !== 'Full Result') {
          marks = marks.filter((m: any) => m.examName === resultExamType);
        }

        let message = `*Academic Report - ${student.name}*\nRoll No: ${student.rollNumber}\nClass: ${student.className} ${student.section ? '- ' + student.section : ''}\n\n`;
        
        marks.forEach((exam: any) => {
          if (exam.isBlank) return;
          message += `*${exam.examName}*\n`;
          exam.subjects.forEach((subj: any) => {
            message += `${subj.name}: ${subj.obtained}\n`;
          });
          message += `Total: ${exam.obtained}/${exam.total}\n\n`;
        });

        const phone = student.parentPhone || '';
        const cleanPhone = phone.replace(/[^0-9+]/g, '');
        const defaultChatId = student.telegramChatId || cleanPhone;
        
        if (!defaultChatId) {
          failCount++;
          setTelegramStatus(prev => ({ ...prev, [id]: 'failed' }));
          continue;
        }

        const doc = buildPDF(marks, student, resultExamType);
        const pdfBase64 = doc.output('datauristring').split(',')[1];
        
        const res = await fetch('/api/telegram/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chatId: defaultChatId,
            message,
            pdfBase64
          })
        });

        const data = await res.json();
        if (data.success) {
          successCount++;
          setTelegramStatus(prev => ({ ...prev, [id]: 'sent' }));
        } else {
          failCount++;
          setTelegramStatus(prev => ({ ...prev, [id]: 'failed' }));
        }
      } catch (err) {
        failCount++;
        setTelegramStatus(prev => ({ ...prev, [id]: 'failed' }));
      }
    }

    setIsSendingBulk(false);
    alert(`Bulk Telegram Send Complete.\nSuccessfully sent: ${successCount}\nFailed or missing Contact: ${failCount}`);
  };

  const downloadBulkResults = async () => {
    if (selectedResults.length === 0) return;
    setIsDownloading(true);
    
    const doc = new jsPDF();
    let isFirstPage = true;

    for (const id of selectedResults) {
      const student = resultStudents.find(s => s.id === id);
      if (student) {
        let marks = student.examMarks || await getStudentMarks(id);
        if (resultExamType !== 'Full Result') {
          marks = marks.filter((m: any) => m.examName === resultExamType);
        }

        if (!isFirstPage) {
          doc.addPage();
        }
        isFirstPage = false;

        let y = 20;
        doc.setFontSize(22);
        doc.text('SchoolWise', 105, y, { align: 'center' });
        y += 10;
        
        doc.setFontSize(16);
        doc.text(resultExamType === 'Full Result' ? 'Full Academic Report' : `${resultExamType} Result`, 105, y, { align: 'center' });
        y += 15;

        doc.setFontSize(12);
        doc.text("Date: " + new Date().toLocaleDateString(), 20, y);
        y += 10;
        
        doc.text("Student Name: " + student.name, 20, y);
        y += 10;
        doc.text("Roll Number: " + student.rollNumber, 20, y);
        y += 10;
        doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, y);
        y += 15;
        
        doc.setLineWidth(0.5);
        doc.line(20, y, 190, y);
        y += 10;
        
        marks.forEach(exam => {
          if (y > 250) {
            doc.addPage();
            y = 20;
          }

          doc.setFontSize(14);
          doc.setFont("helvetica", "bold");
          doc.text(exam.examName, 20, y);
          
          if (exam.isBlank) {
            doc.setFontSize(12);
            doc.setFont("helvetica", "normal");
            doc.text("Not Recorded", 150, y);
            y += 10;
          } else {
            y += 10;
            doc.setFontSize(12);
            doc.setFont("helvetica", "bold");
            doc.text('Subject', 20, y);
            doc.text('Marks', 150, y);
            y += 5;
            doc.line(20, y, 190, y);
            y += 8;

            doc.setFont("helvetica", "normal");
            exam.subjects.forEach((subj: any) => {
              doc.text(subj.name, 20, y);
              doc.text(String(subj.obtained), 150, y);
              y += 8;
            });
            
            doc.line(20, y, 190, y);
            y += 8;
            
            doc.setFont("helvetica", "bold");
            doc.text("Total", 20, y);
            doc.text(String(exam.obtained) + " / " + String(exam.total), 150, y);
            y += 8;
            
            const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
            let grade = 'F';
            if (Number(percentage) >= 90) grade = 'A+';
            else if (Number(percentage) >= 80) grade = 'A';
            else if (Number(percentage) >= 70) grade = 'B';
            else if (Number(percentage) >= 60) grade = 'C';
            else if (Number(percentage) >= 50) grade = 'D';

            doc.text(`Percentage: ${percentage}% | Grade: ${grade}`, 20, y);
            y += 15;
          }
        });
      }
    }
    
    doc.save(`Bulk_${resultExamType === 'Full Result' ? 'Full_Report' : resultExamType.replace(/\s+/g, '_')}_${resultClass.replace(/\s+/g, '')}${resultClass === 'All' ? '' : resultSection}.pdf`);
    setIsDownloading(false);
  };

  const toggleSelectAll = () => {
    if (selectedResults.length === resultStudents.length) {
      setSelectedResults([]);
    } else {
      setSelectedResults(resultStudents.map(s => s.id));
    }
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedResults(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  return (
    <div className="p-6 md:p-8 animate-in fade-in max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-white mb-6">Exam Management</h1>

      <div className="bg-[#151515] border border-white/10 rounded-xl p-6 sm:p-8 shadow-2xl">
        {/* Tabs */}
                <div className="flex gap-6 border-b border-white/10 mb-8 overflow-x-auto whitespace-nowrap scrollbar-hide">
          <button
            onClick={() => setActiveTab('results')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'results' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Results
            {activeTab === 'results' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('enter')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'enter' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Enter Marks
            {activeTab === 'enter' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'upload' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Upload
            {activeTab === 'upload' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('processing')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'processing' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Processing
            {activeTab === 'processing' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'pending' ? 'text-amber-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Pending Verification
            {activeTab === 'pending' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-amber-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('processed')}
            className={`pb-4 text-sm font-medium transition-colors relative ${
              activeTab === 'processed' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Verified Data
            {activeTab === 'processed' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>

        {activeTab === 'results' ? (
          <div>
            <div className="flex flex-col sm:flex-row justify-between sm:items-end gap-4 mb-8">
              <div>
                <h2 className="text-xl font-medium text-white mb-6">Student Results</h2>
                <div className="flex flex-col md:flex-row gap-4 md:items-end">
                  <div className="flex-1 max-w-xs">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>
                    <div className="relative">
                      <select
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                        value={resultClass}
                        onChange={(e) => {
                          setResultClass(e.target.value);
                          setIsResultLoaded(false);
                        }}
                      >
                        <option value="All" className="bg-[#151515]">All Classes</option>
                        {classes.map(c => (
                          <option key={c} value={c} className="bg-[#151515]">{c}</option>
                        ))}
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 max-w-xs">
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Exam Type</label>
                    <div className="relative">
                      <select
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                        value={resultExamType}
                        onChange={(e) => setResultExamType(e.target.value)}
                      >
                        <option value="Full Result" className="bg-[#151515]">Full Result</option>
                        {availableExams.map(e => <option key={e} value={e} className="bg-[#151515]">{e}</option>)}
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={loadResults}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-6 py-2.5 rounded-lg transition-colors shadow-lg mt-2 md:mt-0"
                  >
                    Process
                  </button>
                </div>
              </div>
              
              {isResultLoaded && resultStudents.length > 0 && (
                <div className="flex items-center gap-3">
                  <button
                    onClick={sendBulkTelegramResults}
                    title="Send via Telegram"
                    disabled={selectedResults.length === 0 || isSendingBulk || isDownloading}
                    className="bg-[#229ED9] hover:bg-[#1CA0DE] disabled:opacity-50 text-white p-3 rounded-lg transition-colors shadow-lg flex items-center justify-center"
                  >
                    {isSendingBulk ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
                    {/* No text, just icon */}
                  </button>
                  <button
                    onClick={downloadBulkResults}
                    title="Download Selected"
                  disabled={selectedResults.length === 0 || isDownloading}
                  className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white p-3 rounded-lg transition-colors shadow-lg flex items-center justify-center"
                >
                  {isDownloading ? <Loader2 size={20} className="animate-spin" /> : <Download size={20} />}
                  {/* No text, just icon */}
                  </button>
                </div>
              )}
            </div>

            {isResultLoaded ? (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0a0a]">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/10 text-xs font-bold text-gray-500 uppercase tracking-wider bg-black/40">
                        <th className="p-4 whitespace-nowrap w-12">
                          <button onClick={toggleSelectAll} className="text-gray-400 hover:text-white transition-colors">
                            {selectedResults.length === resultStudents.length && resultStudents.length > 0 ? (
                              <Check className="w-5 h-5 bg-blue-500 text-white rounded border border-blue-500" />
                            ) : (
                              <div className="w-5 h-5 border-2 border-gray-500 rounded" />
                            )}
                          </button>
                        </th>
                        <th className="p-4 whitespace-nowrap">Roll No</th>
                        <th className="p-4 whitespace-nowrap">Student Name</th>
                        {resultExamType !== 'Full Result' && (
                          <>
                            <th className="p-4 whitespace-nowrap">Maths</th>
                            <th className="p-4 whitespace-nowrap">Science</th>
                            <th className="p-4 whitespace-nowrap">Hindi</th>
                            
                            <th className="p-4 whitespace-nowrap">Total</th>
                          </>
                        )}
                        <th className="p-4 whitespace-nowrap">Status</th>
                        <th className="p-4 whitespace-nowrap text-right sticky right-0 bg-[#0a0a0a] z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.3)]">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {resultStudents.length === 0 ? (
                        <tr>
                          <td colSpan={resultExamType !== 'Full Result' ? 9 : 5} className="p-8 text-center text-gray-500">
                            No students found in this class.
                          </td>
                        </tr>
                      ) : (
                        resultStudents.map((student) => (
                          <tr key={student.id} className={`hover:bg-white/5 transition-colors ${selectedResults.includes(student.id) ? 'bg-blue-500/5' : ''}`}>
                            <td className="p-4">
                              <button onClick={() => toggleSelectStudent(student.id)} className="text-gray-400 hover:text-white transition-colors">
                                {selectedResults.includes(student.id) ? (
                                  <Check className="w-5 h-5 bg-blue-500 text-white rounded border border-blue-500" />
                                ) : (
                                  <div className="w-5 h-5 border-2 border-gray-500 rounded" />
                                )}
                              </button>
                            </td>
                            <td className="p-4 text-gray-400 font-medium">{student.rollNumber}</td>
                            <td className="p-4 text-gray-300 font-bold">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                                  {student.photo ? (
                                    <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                                  ) : (
                                    <span className="text-xs font-bold text-indigo-300">{student.name.charAt(0)}</span>
                                  )}
                                </div>
                                {student.name}
                              </div>
                            </td>
                            {resultExamType !== 'Full Result' ? (() => {
                              const examMark = student.examMarks?.find((m: any) => m.examName === resultExamType);
                              if (!examMark || examMark.isBlank) {
                                return (
                                  <>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                    <td className="p-4 text-gray-600 font-medium">-</td>
                                  </>
                                );
                              }
                              const getSub = (name: string) => examMark.subjects.find((s: any) => s.name === name)?.obtained || '-';
                              return (
                                <>
                                  <td className="p-4 text-white font-bold">{getSub('Maths')}</td>
                                  <td className="p-4 text-white font-bold">{getSub('Science')}</td>
                                  <td className="p-4 text-white font-bold">{getSub('Hindi')}</td>
                                  
                                  <td className="p-4 text-emerald-400 font-bold">{examMark.obtained} / {examMark.total}</td>
                                </>
                              );
                            })() : null}
                            <td className="p-4 whitespace-nowrap">
                              {telegramStatus[student.id] === 'pending' && <span className="flex items-center gap-1.5 text-blue-400 text-xs font-bold uppercase tracking-wider"><Loader2 size={12} className="animate-spin" /> Pending</span>}
                              {telegramStatus[student.id] === 'sent' && <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold uppercase tracking-wider"><CheckCircle2 size={12} /> Sent</span>}
                              {telegramStatus[student.id] === 'failed' && <span className="flex items-center gap-1.5 text-red-400 text-xs font-bold uppercase tracking-wider"><X size={12} /> Failed</span>}
                              {!telegramStatus[student.id] && <span className="text-gray-600 text-xs font-bold">-</span>}
                            </td>
                            <td className="p-4 text-right whitespace-nowrap sticky right-0 bg-[#0a0a0a] z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.3)]">
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => sendTelegramResult(student)}
                                  disabled={sendingTelegramId === student.id}
                                  className="inline-flex items-center gap-1.5 p-2 bg-[#229ED9]/10 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors font-medium text-sm disabled:opacity-50"
                                  title="Send via Telegram"
                                >
                                  {sendingTelegramId === student.id ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                                </button>
                                <button
                                  onClick={() => downloadIndividualResult(student)}
                                  disabled={isDownloading}
                                  className="inline-flex items-center gap-1.5 p-2 bg-white/5 hover:bg-white/10 text-indigo-400 hover:text-indigo-300 rounded-lg transition-colors font-medium text-sm disabled:opacity-50"
                                  title="Download PDF"
                                >
                                  <Download size={16} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5 animate-in fade-in">
                <div className="text-4xl mb-4 opacity-50">🎓</div>
                <p className="text-gray-400 font-medium">Select a class and section, then click "Process" to view and download results.</p>
              </div>
            )}
          </div>
        ) : activeTab === 'enter' ? (
          <div>
            <h2 className="text-xl font-medium text-white mb-6">Enter Marks</h2>

            <div className="flex flex-col md:flex-row gap-4 mb-8 md:items-end">
              <div className="flex-1 max-w-xs">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Exam</label>
                <div className="relative">
                  <select
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                    value={selectedExam}
                    onChange={(e) => {
                      setSelectedExam(e.target.value);
                      setIsGridLoaded(false);
                      setIsSaved(false);
                    }}
                  >
                    {availableExams.map(e => <option key={e} value={e} className="bg-[#151515]">{e}</option>)}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>

              <div className="w-32">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Max Marks</label>
                <div className="relative">
                  <select
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                    value={maxMarks}
                    onChange={(e) => {
                      setMaxMarks(Number(e.target.value));
                    }}
                  >
                    {[10, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100].map(m => (
                      <option key={m} value={m} className="bg-[#151515]">{m}</option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>

              <div className="flex-1 max-w-xs">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <select
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                      value={enterClass}
                      onChange={(e) => {
                        setEnterClass(e.target.value);
                        setIsGridLoaded(false);
                        setIsSaved(false);
                      }}
                    >
                      {baseClasses.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                  <div className="relative flex-1">
                    <select
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                      value={enterSection}
                      onChange={(e) => {
                        setEnterSection(e.target.value);
                        setIsGridLoaded(false);
                        setIsSaved(false);
                      }}
                    >
                      {sections.map(s => <option key={s} value={s} className="bg-[#151515]">{s}</option>)}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>
              </div>

              <button 
                onClick={loadGrid}
                className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-6 py-2.5 rounded-lg transition-colors shadow-lg mt-2 md:mt-0"
              >
                Load Grid
              </button>
            </div>

            {/* Grid Area */}
            {isGridLoaded ? (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0a0a] mb-8">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/10 text-xs font-bold text-gray-500 uppercase tracking-wider bg-black/40">
                        <th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>
                        <th className="p-4 whitespace-nowrap text-center text-blue-400 font-bold">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {students.map((student) => (
                        <tr key={student.id} className="hover:bg-white/5 transition-colors">
                          <td className="p-4 text-gray-400 text-sm font-medium">
                            {student.rollNumber || '-'}
                          </td>
                          <td className="p-4 text-gray-300 text-sm">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                                {student.photo ? (
                                  <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                                ) : (
                                  <span className="text-xs font-bold text-indigo-300">{student.name.charAt(0)}</span>
                                )}
                              </div>
                              {student.name}
                            </div>
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.maths}
                              onChange={(e) => handleMarkChange(student.id, 'maths', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.science}
                              onChange={(e) => handleMarkChange(student.id, 'science', e.target.value)}
                            />
                          </td>
                          <td className="p-4">
                            <input
                              type="text"
                              inputMode="numeric"
                              className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                              value={student.hindi}
                              onChange={(e) => handleMarkChange(student.id, 'hindi', e.target.value)}
                            />
                          </td>
                          
                          <td className="p-4 text-gray-400 font-medium text-sm">
                            {calculateTotal(student)}
                          </td>
                          <td className="p-4 flex justify-center items-center">
                            <button 
                              onClick={() => handleSaveIndividual(student)}
                              disabled={savingStudentId === student.id}
                              className="bg-blue-600/20 hover:bg-blue-600/40 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
                            >
                              {savingStudentId === student.id ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                              {savingStudentId === student.id ? 'Saving...' : 'Save'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Actions */}
                <div className="flex gap-4 items-center">
                  <button 
                    onClick={handleSaveMarks}
                    disabled={isSaving}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold px-5 py-2.5 rounded-lg transition-colors shadow-lg"
                  >
                    {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {isSaving ? 'Saving...' : 'Save All Marks'}
                  </button>
                  <button className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold px-5 py-2.5 rounded-lg transition-colors shadow-lg">
                    <Lock size={16} />
                    Finalize Marks
                  </button>
                  
                  {isSaved && (
                    <span className="text-emerald-400 text-sm font-medium flex items-center gap-1.5 ml-2 animate-in fade-in">
                      <CheckCircle2 size={16} /> Marks saved successfully!
                    </span>
                  )}
                </div>
              </div>
            ) : (
              <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5 animate-in fade-in">
                <div className="text-4xl mb-4 opacity-50">📋</div>
                <p className="text-gray-400 font-medium">Select an exam and class, then click "Load Grid" to enter marks.</p>
              </div>
            )}
          </div>

        ) : null}
        
        {activeTab === 'upload' && (
          <UploadMarks 
            onUploadSuccess={() => setActiveTab('processing')} 
            user={user}
            onUpdateUser={onUpdateUser}
          />
        )}
        
        {activeTab === 'processing' && (
          <ProcessingJobsList 
            onJobComplete={() => setActiveTab('pending')} 
            user={user}
          />
        )}
        
        {activeTab === 'pending' && (
          <PendingVerificationList onVerifySuccess={() => setActiveTab('processed')} />
        )}

        {activeTab === 'processed' && (
          <ProcessedDataList />
        )}
      </div>
    
      {/* Conflict Resolution Modal */}
      {showConflictModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-white/10 rounded-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-amber-500/5 rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/20 text-amber-500 rounded-lg">
                  <AlertCircle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Duplicate Data Detected</h3>
                  <p className="text-sm text-amber-500/80 mt-1">Some entered marks conflict with existing database records.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleResolveAll('old')} className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-lg transition-colors border border-white/10">
                  <History size={16} /> Keep All Old
                </button>
                <button onClick={() => handleResolveAll('new')} className="flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-lg">
                  <Check size={16} /> Keep All New
                </button>
              </div>
            </div>
            
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/10 text-xs font-bold text-gray-500 uppercase tracking-wider bg-black/40">
                    <th className="p-4 whitespace-nowrap">Roll No</th>
                    <th className="p-4 whitespace-nowrap">Student Name</th>
                    <th className="p-4 whitespace-nowrap">Subject</th>
                    <th className="p-4 whitespace-nowrap text-center">Conflict</th>
                    <th className="p-4 whitespace-nowrap text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {conflicts.map(conflict => {
                    const isResolved = resolvedConflicts[conflict.id];
                    return (
                      <tr key={conflict.id} className={`border-b border-white/5 transition-colors ${isResolved ? 'opacity-50 bg-white/5' : 'hover:bg-white/5'}`}>
                        <td className="p-4 text-gray-400 font-medium">{conflict.rollNumber}</td>
                        <td className="p-4 text-gray-300 font-bold">{conflict.studentName}</td>
                        <td className="p-4 text-indigo-400 font-medium">{conflict.subject}</td>
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-4">
                            <div className="text-center">
                              <span className="text-[10px] text-gray-500 uppercase tracking-wider block mb-1">Old Data</span>
                              <span className="text-lg font-bold text-gray-300 bg-white/5 px-3 py-1 rounded">{conflict.oldMark}</span>
                            </div>
                            <div className="text-gray-600">vs</div>
                            <div className="text-center">
                              <span className="text-[10px] text-amber-500 uppercase tracking-wider block mb-1">New Data</span>
                              <span className="text-lg font-bold text-amber-500 bg-amber-500/10 px-3 py-1 rounded border border-amber-500/20">{conflict.newMark}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          {isResolved ? (
                            <div className="flex justify-end items-center gap-2 text-emerald-400 text-sm font-bold">
                              <CheckCircle2 size={16} />
                              Resolved: Kept {isResolved}
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <button onClick={() => handleResolveConflict(conflict.id, 'old')} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded transition-colors">
                                <History size={14} /> Keep Old
                              </button>
                              <button onClick={() => handleResolveConflict(conflict.id, 'new')} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded transition-colors shadow-lg">
                                <Check size={14} /> Keep New
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            
            <div className="p-6 border-t border-white/10 flex justify-end gap-4 bg-black/40 rounded-b-2xl">
              <button 
                onClick={() => setShowConflictModal(false)}
                className="px-6 py-2.5 bg-transparent hover:bg-white/5 text-gray-300 text-sm font-bold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => handleSaveMarks(true)}
                disabled={Object.keys(resolvedConflicts).length < conflicts.length || isSaving}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 text-white text-sm font-bold rounded-lg transition-colors shadow-lg"
              >
                {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                Confirm & Save Marks
              </button>
            </div>
          </div>
        </div>
      )}
</div>
  );
}
