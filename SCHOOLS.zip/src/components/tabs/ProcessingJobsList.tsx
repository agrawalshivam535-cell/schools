import React, { useState, useEffect } from 'react';
import { Loader2, FileText, Clock, RefreshCw, AlertTriangle, Play, Trash2, User as UserIcon } from 'lucide-react';
import { User } from '../../types';

interface ProcessingJobsListProps {
  onJobComplete?: () => void;
  user?: User;
}
export function ProcessingJobsList({ onJobComplete, user }: ProcessingJobsListProps = {}) {
  const [jobs, setJobs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchJobs = async () => {
    try {
      const res = await fetch('/api/exams/jobs');
      const data = await res.json();
      const currentProcessing = data.filter((j: any) => j.status === 'processing' || j.status === 'error');
      
      // If we previously had processing jobs and now we have fewer, one might have completed.
      // A more reliable way: check if we have any pending_verification jobs now, 
      // AND we are about to set an empty processing list.
      setJobs((prevJobs) => {
        if (prevJobs.length > 0 && currentProcessing.length === 0) {
          const hasPending = data.some((j: any) => j.status === 'pending_verification');
          if (hasPending && onJobComplete) {
             setTimeout(onJobComplete, 500);
          }
        }
        return currentProcessing;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };


  const handleRetry = async (jobId: string) => {
    try {
      const res = await fetch('/api/exams/jobs/' + jobId + '/retry', { 
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user?.loginId || '',
          'x-gemini-api-key': user?.apiKey || ''
        },
        body: JSON.stringify({
          loginId: user?.loginId,
          geminiApiKey: user?.apiKey
        })
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        alert(data.error || 'Retry failed');
      }
      fetchJobs(); // Optimistic refresh
    } catch (err) {
      console.error("Retry failed:", err);
    }
  };

  const handleDeleteJob = async (jobId: string) => {
    try {
      await fetch('/api/exams/jobs/' + jobId, { method: 'DELETE' });
      fetchJobs();
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  useEffect(() => {

    fetchJobs();
    const interval = setInterval(fetchJobs, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-medium text-white flex items-center gap-2">
            <RefreshCw className="text-blue-400 animate-spin" size={24} />
            Processing Documents
          </h2>
          <p className="text-gray-400 text-sm mt-1">These documents are currently being analyzed by AI in the background.</p>
        </div>
        <button 
          onClick={fetchJobs}
          className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
          title="Refresh List"
        >
          <Clock size={20} />
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <Loader2 className="w-8 h-8 animate-spin mb-4" />
          <p>Loading active jobs...</p>
        </div>
      ) : jobs.length === 0 ? (
        <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5">
          <div className="text-4xl mb-4 opacity-50">🤖</div>
          <p className="text-gray-400 font-medium">No documents are currently processing.</p>
          <p className="text-sm text-gray-500 mt-1">Upload a new document to start AI extraction.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map(job => (
            <div 
              key={job.id} 
              className={`bg-[#0a0a0a] border rounded-xl p-5 relative overflow-hidden group ${job.status === 'error' ? 'border-red-500/30' : 'border-blue-500/30'}`}
            >
              <div className={`absolute top-0 left-0 right-0 h-1 overflow-hidden ${job.status === 'error' ? 'bg-red-500/20' : 'bg-blue-500/20'}`}>
                {job.status === 'processing' && <div className="h-full bg-blue-500 w-1/2 animate-[progress_1s_ease-in-out_infinite]" />}
              </div>

              <div className="flex justify-between items-start mb-3 mt-1">
                {job.status === 'error' ? (
                  <span className="bg-red-500/20 text-red-400 text-xs font-bold px-2.5 py-1 rounded-md flex items-center gap-1.5">
                    <AlertTriangle size={12} />
                    FAILED
                  </span>
                ) : (
                  <span className="bg-blue-500/20 text-blue-400 text-xs font-bold px-2.5 py-1 rounded-md flex items-center gap-1.5">
                    <Loader2 size={12} className="animate-spin" />
                    PROCESSING
                  </span>
                )}
                <span className="text-gray-500 text-xs">
                  {new Date(job.timestamp).toLocaleTimeString()}
                </span>
              </div>
              
              <h3 className="text-lg font-bold text-white mb-2 truncate" title={job.filename}>
                <FileText size={16} className="inline mr-2 text-gray-400" />
                {job.filename}
              </h3>
              
              <div className="flex flex-col gap-1 text-sm text-gray-400 mb-3">
                <p>Class: {job.className} - {job.section}</p>
                <p>Subject: {job.subject}</p>
                <p>Exam: {job.examType}</p>
                {job.loginId && (
                  <p className="text-xs text-indigo-300 flex items-center gap-1 mt-1">
                    <UserIcon size={12} />
                    <span>User:</span>
                    <span className="font-mono bg-white/5 px-1 rounded">{job.loginId}</span>
                  </p>
                )}
              </div>

              {job.status === 'processing' && (
                <div className="mt-4 border-t border-white/5 pt-3 flex gap-2">
                  <button 
                    onClick={() => handleRetry(job.id)}
                    className="flex-1 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-blue-300 text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                    title="Restart analysis if needed"
                  >
                    <RefreshCw size={12} /> Restart
                  </button>
                  <button 
                    onClick={() => handleDeleteJob(job.id)}
                    className="px-3 py-1.5 bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 rounded-lg text-red-400 text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                    title="Cancel processing"
                  >
                    <Trash2 size={12} /> Cancel
                  </button>
                </div>
              )}

              {job.status === 'error' && (
                <div className="mt-4 border-t border-white/5 pt-3 flex flex-col gap-2">
                  <p className="text-xs text-red-400 break-words" title={job.errorMsg}>{job.errorMsg || 'Failed to process document'}</p>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleRetry(job.id)}
                      className="flex-1 py-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-blue-300 text-sm font-medium transition-colors flex items-center justify-center gap-2"
                    >
                      <Play size={14} /> Retry
                    </button>
                    <button 
                      onClick={() => handleDeleteJob(job.id)}
                      className="px-3 py-2 bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 rounded-lg text-red-400 text-sm font-medium transition-colors flex items-center justify-center gap-1.5"
                      title="Dismiss failed job"
                    >
                      <Trash2 size={14} /> Dismiss
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
