import React, { useState, useEffect, useMemo } from 'react';
import { UploadMarks, ProcessedRecord } from './UploadMarks';
import { Loader2, FileText, ChevronRight, Search, Clock, Users, BookOpen, Filter } from 'lucide-react';

export function ProcessedDataList() {
  const [records, setRecords] = useState<ProcessedRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState<ProcessedRecord | null>(null);

  // Filters state
  const [filterClass, setFilterClass] = useState('');
  const [filterSection, setFilterSection] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  const [filterExamType, setFilterExamType] = useState('');

  useEffect(() => {
    fetchRecords();
  }, []);

  const fetchRecords = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/exams/analysis');
      const data = await response.json();
      setRecords(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const uniqueClasses = useMemo(() => Array.from(new Set(records.map(r => r.className))).sort(), [records]);
  const uniqueSections = useMemo(() => Array.from(new Set(records.map(r => r.section))).sort(), [records]);
  const uniqueSubjects = useMemo(() => Array.from(new Set(records.map(r => r.subject))).sort(), [records]);
  const uniqueExamTypes = useMemo(() => Array.from(new Set(records.map(r => r.examType))).sort(), [records]);

  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (filterClass && r.className !== filterClass) return false;
      if (filterSection && r.section !== filterSection) return false;
      if (filterSubject && r.subject !== filterSubject) return false;
      if (filterExamType && r.examType !== filterExamType) return false;
      return true;
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [records, filterClass, filterSection, filterSubject, filterExamType]);

  if (selectedRecord) {
    return <UploadMarks initialRecord={selectedRecord} onBack={() => { setSelectedRecord(null); fetchRecords(); }} />;
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-medium text-white flex items-center gap-2">
            <FileText className="text-blue-400" size={24} />
            Processed Data
          </h2>
          <p className="text-gray-400 text-sm mt-1">Review and update previously saved exam data.</p>
        </div>
        <button 
          onClick={fetchRecords}
          className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
          title="Refresh Data"
        >
          <Clock size={20} />
        </button>
      </div>

      {/* Filters Section - Live Filtering without "Load Grid" button */}
      {!isLoading && records.length > 0 && (
        <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 mb-6">
          <div className="flex items-center gap-2 mb-4 text-sm font-medium text-gray-400">
            <Filter size={16} />
            <span>Filter Records</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <select
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500 transition-colors"
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
            >
              <option value="">All Classes</option>
              {uniqueClasses.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500 transition-colors"
              value={filterSection}
              onChange={(e) => setFilterSection(e.target.value)}
            >
              <option value="">All Sections</option>
              {uniqueSections.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500 transition-colors"
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
            >
              <option value="">All Subjects</option>
              {uniqueSubjects.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500 transition-colors"
              value={filterExamType}
              onChange={(e) => setFilterExamType(e.target.value)}
            >
              <option value="">All Exam Types</option>
              {uniqueExamTypes.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <Loader2 className="w-8 h-8 animate-spin mb-4" />
          <p>Loading processed records...</p>
        </div>
      ) : records.length === 0 ? (
        <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5">
          <div className="text-4xl mb-4 opacity-50">📂</div>
          <p className="text-gray-400 font-medium">No processed data found.</p>
          <p className="text-sm text-gray-500 mt-1">Upload and save marks first.</p>
        </div>
      ) : filteredRecords.length === 0 ? (
        <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5">
          <div className="text-4xl mb-4 opacity-50">🔍</div>
          <p className="text-gray-400 font-medium">No records match your filters.</p>
          <button 
            onClick={() => { setFilterClass(''); setFilterSection(''); setFilterSubject(''); setFilterExamType(''); }}
            className="mt-4 text-blue-400 text-sm hover:underline"
          >
            Clear all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredRecords.map(record => (
            <div 
              key={record.id} 
              onClick={() => setSelectedRecord(record)}
              className="bg-[#0a0a0a] border border-white/10 rounded-xl p-5 hover:bg-white/5 hover:border-white/20 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-3">
                <span className="bg-blue-500/20 text-blue-400 text-xs font-bold px-2.5 py-1 rounded-md uppercase tracking-wider">
                  {record.examType}
                </span>
                <span className="text-gray-500 text-xs">
                  {new Date(record.timestamp).toLocaleDateString()}
                </span>
              </div>
              
              <h3 className="text-lg font-bold text-white mb-4 group-hover:text-blue-400 transition-colors">
                {record.className} - {record.section}
              </h3>
              
              <div className="flex flex-col gap-2.5 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <BookOpen size={16} />
                  <span>{record.subject}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Users size={16} />
                  <span>{record.records?.length || 0} Students Processed</span>
                </div>
              </div>
              
              <div className="pt-4 border-t border-white/10 flex justify-between items-center text-sm font-medium text-gray-400 group-hover:text-white transition-colors">
                View & Edit Data
                <ChevronRight size={16} className="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
