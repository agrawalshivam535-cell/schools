import { useClasses } from '../../hooks/useClasses';
import { useState, useEffect } from 'react';
import { Calendar } from 'lucide-react';
import { AttendanceRecord } from '../../types';

export function Attendance() {
  const [date, setDate] = useState('');
  const [className, setClassName] = useState('');
  const [section, setSection] = useState('');
  
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [rowSaving, setRowSaving] = useState<string | null>(null);
  const [rowSaved, setRowSaved] = useState<string | null>(null);

  const { classes } = useClasses();
  const sections = ['A', 'B'];

  useEffect(() => {
    if (date && className && section) {
      loadData();
    }
  }, [date, className, section]);

  const loadData = async () => {
    setLoading(true);
    setHasSearched(true);
    setSaved(false);
    try {
      const res = await fetch("/api/attendance?date=" + date + "&className=" + encodeURIComponent(className) + "&section=" + encodeURIComponent(section));
      const data = await res.json();
      setRecords(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = (id: string, status: 'Present' | 'Absent' | 'Late') => {
    setRecords(records.map(r => r.id === id ? { ...r, status } : r));
    setSaved(false);
  };

  const saveAttendance = async () => {
    setSaving(true);
    try {
      await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date, className, section, records })
      });
      setSaved(true);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const saveIndividualRow = async (rollNumber: string) => {
    setRowSaving(rollNumber);
    setRowSaved(null);
    try {
      await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date, className, section, records })
      });
      setRowSaved(rollNumber);
      setTimeout(() => setRowSaved(null), 2000);
    } catch (err) {
      console.error(err);
    } finally {
      setRowSaving(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h1 className="text-2xl font-bold text-white">Mark Attendance</h1>
      
      <div className="bg-[#0f0f0f]/60 border border-white/5 p-5 sm:p-6 grid grid-cols-1 sm:grid-cols-3 gap-4 rounded-2xl">
        <div className="relative">
          <label className="block text-sm font-medium mb-1.5 text-gray-400">Date</label>
          <div className="relative">
            <input 
              type="date" 
              className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 [color-scheme:dark] cursor-pointer"
              value={date}
              onClick={(e) => {
                try {
                  (e.target as HTMLInputElement).showPicker?.();
                } catch (err) {
                  // Ignore if showPicker is not supported or fails
                }
              }}
              onChange={e => setDate(e.target.value)}
            />
            <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
              <Calendar size={18} />
            </div>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5 text-gray-400">Class</label>
          <select 
            className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
            value={className}
            onChange={e => setClassName(e.target.value)}
          >
            <option value="">Select...</option>
            {classes.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5 text-gray-400">Section</label>
          <select 
            className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
            value={section}
            onChange={e => setSection(e.target.value)}
          >
            <option value="">Select...</option>
            {sections.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {!hasSearched && (
        <div className="bg-[#0f0f0f]/60 p-10 text-center text-gray-400 border border-white/5 rounded-2xl">
          Select Date, Class & Section.
        </div>
      )}

      {loading && (
        <div className="bg-[#0f0f0f]/60 p-10 text-center text-gray-400 border border-white/5 rounded-2xl">Loading...</div>
      )}

      {hasSearched && !loading && records.length === 0 && (
        <div className="bg-[#0f0f0f]/60 p-10 text-center text-gray-400 border border-white/5 rounded-2xl">No students found.</div>
      )}

      {hasSearched && !loading && records.length > 0 && (
        <div className="bg-[#0f0f0f]/60 border border-white/5 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="p-4 text-gray-400 font-medium whitespace-nowrap">Roll No</th>
                  <th className="p-4 text-gray-400 font-medium w-full">Name</th>
                  <th className="p-4 text-gray-400 font-medium text-center">Present</th>
                  <th className="p-4 text-gray-400 font-medium text-center">Absent</th>
                  <th className="p-4 text-gray-400 font-medium text-center">Late</th>
                  <th className="p-4 text-gray-400 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {records.map((student) => (
                  <tr key={student.id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="p-4 text-gray-300">{student.rollNumber}</td>
                    <td className="p-4 text-white font-medium">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                          {student.photo ? (
                            <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-xs font-bold text-indigo-300">{student.name.charAt(0)}</span>
                          )}
                        </div>
                        {student.name}
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleStatusChange(student.id, 'Present')}
                        className={`w-8 h-8 mx-auto rounded-md flex items-center justify-center font-bold text-sm transition-all ${
                          student.status === 'Present'
                            ? 'bg-green-500 text-white shadow-[0_0_10px_rgba(34,197,94,0.4)]'
                            : 'bg-green-500/10 text-green-500 border border-green-500/20 hover:bg-green-500/20'
                        }`}
                        title="Present"
                      >
                        P
                      </button>
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleStatusChange(student.id, 'Absent')}
                        className={`w-8 h-8 mx-auto rounded-md flex items-center justify-center font-bold text-sm transition-all ${
                          student.status === 'Absent'
                            ? 'bg-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.4)]'
                            : 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20'
                        }`}
                        title="Absent"
                      >
                        A
                      </button>
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleStatusChange(student.id, 'Late')}
                        className={`w-8 h-8 mx-auto rounded-md flex items-center justify-center font-bold text-sm transition-all ${
                          student.status === 'Late'
                            ? 'bg-yellow-500 text-white shadow-[0_0_10px_rgba(234,179,8,0.4)]'
                            : 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 hover:bg-yellow-500/20'
                        }`}
                        title="Late"
                      >
                        L
                      </button>
                    </td>
                    <td className="p-4 text-right">
                      <button 
                        onClick={() => saveIndividualRow(student.rollNumber)}
                        disabled={rowSaving === student.rollNumber}
                        className="bg-white/5 hover:bg-white/10 text-indigo-400 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                      >
                        {rowSaving === student.rollNumber ? 'Saving...' : rowSaved === student.rollNumber ? 'Saved!' : 'Save'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="p-5 border-t border-white/10 flex items-center gap-4 bg-black/20">
            <button 
              onClick={saveAttendance}
              disabled={saving}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-lg font-medium disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Submit Attendance'}
            </button>
            {saved && <span className="text-emerald-400 text-sm font-medium">✅ Saved successfully</span>}
          </div>
        </div>
      )}
    </div>
  );
}
