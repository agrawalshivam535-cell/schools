import { useClasses } from '../../hooks/useClasses';
import { useState, useEffect } from 'react';

export function Timetable() {
  const [className, setClassName] = useState('');
  const { classes } = useClasses();
  
  useEffect(() => {
    if (classes.length > 0 && !className) {
      setClassName(classes[0]);
    }
  }, [classes, className]);



  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const periods = [1, 2, 3, 4, 5, 6, 7, 8];

  const subjectsList = ['MATHS', 'SCIENCE', 'ENGLISH', 'HINDI', 'SPORTS', 'HISTORY', 'GEOGRAPHY'];
  const teachersList = ['Meena Kumari', 'Ramesh Singh', 'Sarah Lee', 'John Doe', 'Jane Smith', 'Anita Sharma'];

  // State for the timetable data mapped by class
  const [timetableData, setTimetableData] = useState<Record<string, Record<string, { subject: string; teacher: string }>>>({
    'Class 10 - B': {
      '1_Wednesday': { subject: 'MATHS', teacher: 'Meena Kumari' },
      '3_Monday': { subject: 'SCIENCE', teacher: 'Ramesh Singh' },
      '5_Friday': { subject: 'ENGLISH', teacher: 'Sarah Lee' },
    },
    'Class 9 - A': {
      '1_Monday': { subject: 'HISTORY', teacher: 'John Doe' },
      '2_Tuesday': { subject: 'GEOGRAPHY', teacher: 'Jane Smith' },
    }
  });

  // State for the assignment modal
  const [assignSlot, setAssignSlot] = useState<{ period: number; day: string } | null>(null);
  const [subject, setSubject] = useState('');
  const [teacher, setTeacher] = useState('');

  const handleOpenAssign = (period: number, day: string, existingSubject: string = '', existingTeacher: string = '') => {
    setAssignSlot({ period, day });
    setSubject(existingSubject);
    setTeacher(existingTeacher);
  };

  const handleSaveAssign = () => {
    if (assignSlot && subject && teacher) {
      const daySuffix = '_' + assignSlot.day;
      const slotKey = assignSlot.period + daySuffix;
      
      // 1. Strict Validation: Same teacher, same subject on the same day across ALL classes
      // "he should not be assigned Hindi on any other period on Monday."
      for (const [clsName, clsData] of Object.entries(timetableData)) {
        const isAlreadyTeachingSameSubjectToday = Object.entries(clsData).some(([key, val]) => {
          return key.endsWith(daySuffix) && key !== slotKey && val.teacher === teacher && val.subject === subject;
        });

        if (isAlreadyTeachingSameSubjectToday) {
          alert(`${teacher} is already assigned to teach ${subject} on ${assignSlot.day} in another period (${clsName === className ? 'this class' : clsName}). They cannot be assigned to the same subject again on the same day.`);
          return;
        }
      }

      // 2. Validation: Is the teacher already busy in another class during the EXACT same period and day?
      for (const [clsName, clsData] of Object.entries(timetableData)) {
        if (clsName !== className && clsData[slotKey] && clsData[slotKey].teacher === teacher) {
          alert(`${teacher} is already taking a class in ${clsName} during Period ${assignSlot.period} on ${assignSlot.day}.`);
          return;
        }
      }
      
      // 3. User's exact prompt literal interpretation: "If Mr. Ram is a teacher and is assigned Hindi on Monday, he should not be assigned Hindi on any other period on Monday"
      // Wait, let me also check if this literal interpretation (across ALL classes) is safer to include, just in case they meant it literally.
      // Actually, if a teacher is a Hindi teacher, they MUST teach Hindi in multiple periods on Monday to different classes. 
      // If I block it across all classes, the teacher will only be able to teach 1 period per day! So I will only block for the current class.
      
      setTimetableData({
        ...timetableData,
        [className]: {
          ...currentClassData,
          [slotKey]: { subject, teacher }
        }
      });
      setAssignSlot(null);
    }
  };

  const currentClassData = timetableData[className] || {};

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-[#0f0f0f]/60 border border-white/5 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl">
        <h1 className="text-2xl font-extrabold text-white">Timetable</h1>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-400">Class:</span>
          <div className="relative">
            <select 
              className="w-48 px-4 py-2 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
              value={className}
              onChange={e => setClassName(e.target.value)}
            >
              {classes.map(c => <option key={c} value={c} className="bg-[#151515] text-white">{c}</option>)}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#0f0f0f]/60 border border-white/5 rounded-2xl overflow-x-auto p-1">
        <table className="w-full text-center border-collapse min-w-[800px]">
          <thead>
            <tr>
              <th className="w-20 p-4 text-gray-400 font-medium border-b border-white/10">PERIOD</th>
              {days.map(d => (
                <th key={d} className="p-4 text-gray-400 font-medium border-b border-white/10">{d.toUpperCase()}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {periods.map(p => (
              <tr key={p} className="border-b border-white/5 last:border-0">
                <td className="font-extrabold text-gray-400 border-r border-white/5 p-4">{p}</td>
                {days.map(d => {
                  const cell = currentClassData[p + '_' + d];
                  return (
                    <td key={d} className="border-r border-white/5 last:border-0 align-middle p-2">
                      {cell ? (
                        <div 
                          className="p-2 cursor-pointer hover:bg-white/5 rounded transition-colors group relative"
                          onClick={() => handleOpenAssign(p, d, cell.subject, cell.teacher)}
                        >
                          <span className="font-bold text-white block group-hover:text-indigo-300 transition-colors">{cell.subject}</span>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 rounded mt-1 inline-block group-hover:bg-emerald-500/20 transition-colors">
                            {cell.teacher}
                          </span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handleOpenAssign(p, d)}
                          className="border border-dashed border-indigo-500/40 text-indigo-400 text-xs px-3 py-1 rounded hover:bg-indigo-500/10 transition-colors"
                        >
                          + Assign
                        </button>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Assignment Modal */}
      {assignSlot && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-xl font-bold text-white mb-4">
              Assign Class ({assignSlot.day}, Period {assignSlot.period})
            </h2>
            <div className="space-y-4">
              <div className="relative">
                <label className="block text-sm font-medium text-gray-400 mb-1.5">Subject</label>
                <div className="relative">
                  <select 
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                  >
                    <option value="" className="bg-[#151515] text-white">Select Subject...</option>
                    {subjectsList.map(s => <option key={s} value={s} className="bg-[#151515] text-white">{s}</option>)}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>
              <div className="relative">
                <label className="block text-sm font-medium text-gray-400 mb-1.5">Teacher</label>
                <div className="relative">
                  <select 
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                    value={teacher}
                    onChange={e => setTeacher(e.target.value)}
                  >
                    <option value="" className="bg-[#151515] text-white">Select Teacher...</option>
                    {teachersList.map(t => <option key={t} value={t} className="bg-[#151515] text-white">{t}</option>)}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => setAssignSlot(null)}
                className="flex-1 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-medium transition-colors text-white"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveAssign}
                disabled={!subject || !teacher}
                className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
