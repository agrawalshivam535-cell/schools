import React, { useState, useEffect } from 'react';
import { Loader2, FileText, ChevronRight, Clock, ShieldAlert, Trash2 } from 'lucide-react';
import { UploadMarks } from './UploadMarks';

interface PendingVerificationListProps {
  onVerifySuccess?: () => void;
}
export function PendingVerificationList({ onVerifySuccess }: PendingVerificationListProps = {}) {
  const [jobs, setJobs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedJob, setSelectedJob] = useState<any | null>(null);

  const fetchJobs = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/exams/jobs');
      const data = await res.json();
      setJobs(data.filter((j: any) => j.status === 'pending_verification'));
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to discard this extracted data?')) return;
    
    try {
      await fetch('/api/exams/jobs/' + id, { method: 'DELETE' });
      fetchJobs();
    } catch (err) {
      console.error(err);
    }
  };

  if (selectedJob) {
    return <UploadMarks pendingJob={selectedJob} onBack={() => { 
      setSelectedJob(null); 
      fetchJobs(); 
      if (onVerifySuccess) onVerifySuccess(); 
    }} />;
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-medium text-white flex items-center gap-2">
            <ShieldAlert className="text-amber-400" size={24} />
            Pending Verification
          </h2>
          <p className="text-gray-400 text-sm mt-1">These documents have been processed by AI and are waiting for your review.</p>
        </div>
        <button 
          onClick={fetchJobs}
          className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
          title="Refresh List"
        >
          <Clock size={20} />
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <Loader2 className="w-8 h-8 animate-spin mb-4" />
          <p>Loading pending jobs...</p>
        </div>
      ) : jobs.length === 0 ? (
        <div className="py-16 text-center border-2 border-dashed border-white/10 rounded-xl bg-white/5">
          <div className="text-4xl mb-4 opacity-50">✨</div>
          <p className="text-gray-400 font-medium">No documents pending verification.</p>
          <p className="text-sm text-gray-500 mt-1">All processed documents have been verified.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map(job => (
            <div 
              key={job.id} 
              onClick={() => setSelectedJob(job)}
              className="bg-[#0a0a0a] border border-amber-500/30 rounded-xl p-5 hover:bg-white/5 hover:border-amber-500/50 transition-all cursor-pointer group relative"
            >
              <div className="flex justify-between items-start mb-3">
                <span className="bg-amber-500/20 text-amber-400 text-xs font-bold px-2.5 py-1 rounded-md">
                  NEEDS REVIEW
                </span>
                <button 
                  onClick={(e) => handleDelete(job.id, e)}
                  className="text-gray-500 hover:text-red-400 p-1 rounded transition-colors opacity-0 group-hover:opacity-100"
                  title="Discard Data"
                >
                  <Trash2 size={14} />
                </button>
              </div>
              
              <h3 className="text-lg font-bold text-white mb-2 truncate" title={job.filename}>
                <FileText size={16} className="inline mr-2 text-gray-400" />
                {job.filename}
              </h3>
              
              <div className="flex flex-col gap-1 text-sm text-gray-400 mb-4">
                <p>Class: {job.className} - {job.section}</p>
                <p>Subject: {job.subject}</p>
                <p>Exam: {job.examType}</p>
              </div>
              
              <div className="pt-4 border-t border-white/10 flex justify-between items-center text-sm font-medium text-amber-400 group-hover:text-amber-300 transition-colors">
                Verify Data
                <ChevronRight size={16} className="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
