import { useClasses } from '../../hooks/useClasses';
import { useState, useEffect } from 'react';
import { Plus, Trash2, Check, RefreshCw, FileText, IndianRupee, History, Download, Send, Loader2 } from 'lucide-react';
import { FeeStructureItem, StudentFeeData, FeePayment } from '../../types';
import jsPDF from 'jspdf';

export function Fees() {
  const [subTab, setSubTab] = useState<'structure' | 'collection'>('structure');
  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);

  const { classes } = useClasses();

  const sections = Array.from(new Set(classes.map(c => c.split(' - ')[1] || 'A'))).sort();


  // --- STRUCTURE TAB STATE ---
  const [structClass, setStructClass] = useState('');
  const [structSection, setStructSection] = useState('');
  const [feeItems, setFeeItems] = useState<FeeStructureItem[]>([]);
  const [loadingStructure, setLoadingStructure] = useState(false);
  const [savingStructure, setSavingStructure] = useState(false);

  // --- COLLECTION TAB STATE ---
  const [collClass, setCollClass] = useState('');
  const [collSection, setCollSection] = useState('');
  const [collectionData, setCollectionData] = useState<StudentFeeData[]>([]);
  const [loadingCollection, setLoadingCollection] = useState(false);

  // Modals
  const [payModal, setPayModal] = useState<{ id: string, name: string, rollNumber?: string, balance: number } | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('Cash');
  const [payRemarks, setPayRemarks] = useState('');

  const [historyModal, setHistoryModal] = useState<StudentFeeData | null>(null);


  useEffect(() => {
    if (classes.length > 0) {
      if (!structClass) setStructClass(classes[0]);
      if (!structSection && sections.length > 0) setStructSection(sections[0]);
      if (!collClass) setCollClass(classes[0]);
      if (!collSection && sections.length > 0) setCollSection(sections[0]);
    }
  }, [classes, structClass, structSection, collClass, collSection, sections]);

  // --- STRUCTURE LOGIC ---
  const DEFAULT_FEE_TYPES = ["Tuition Fee", "Library Fee", "Sports Fee", "Exam Fee"];

  useEffect(() => {
    if (subTab === 'structure' && structClass && structSection) {
      loadStructure();
    }
  }, [subTab, structClass, structSection]);

  const loadStructure = async () => {
    setLoadingStructure(true);
    try {
      const res = await fetch("/api/fees/structure?className=" + encodeURIComponent(structClass) + "&section=" + encodeURIComponent(structSection));
      const data = await res.json();
      
      let fetchedItems: FeeStructureItem[] = data.items || [];
      
      // Ensure default fee types exist
      DEFAULT_FEE_TYPES.forEach(type => {
        if (!fetchedItems.find(item => item.name.toLowerCase() === type.toLowerCase())) {
          fetchedItems.push({
            id: `default-${type.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}`,
            name: type,
            amount: 0
          });
        }
      });
      
      setFeeItems(fetchedItems);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingStructure(false);
    }
  };

  const addFeeItem = () => {
    setFeeItems([...feeItems, { id: Date.now().toString(), name: '', amount: 0 }]);
  };

  const updateFeeItem = (id: string, field: 'name' | 'amount', value: any) => {
    setFeeItems(feeItems.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const removeFeeItem = (id: string) => {
    setFeeItems(feeItems.filter(item => item.id !== id));
  };

  const saveStructure = async () => {
    setSavingStructure(true);
    try {
      await fetch('/api/fees/structure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ className: structClass, section: structSection, items: feeItems })
      });
      alert('Fee structure saved successfully!');
    } catch (e) {
      console.error(e);
    } finally {
      setSavingStructure(false);
    }
  };

  const totalStructureAmount = feeItems.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  // --- COLLECTION LOGIC ---
  useEffect(() => {
    if (subTab === 'collection' && collClass && collSection) {
      loadCollection();
    }
  }, [subTab, collClass, collSection]);

  const loadCollection = async () => {
    setLoadingCollection(true);
    try {
      const res = await fetch("/api/fees/collection?className=" + encodeURIComponent(collClass) + "&section=" + encodeURIComponent(collSection));
      const data = await res.json();
      setCollectionData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingCollection(false);
    }
  };

  const submitPayment = async () => {
    if (!payModal || !payAmount) return;
    try {
      await fetch('/api/fees/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: payModal.id,
          amount: Number(payAmount),
          method: payMethod,
          remarks: payRemarks
        })
      });
      setPayModal(null);
      setPayAmount('');
      setPayRemarks('');
      loadCollection();
    } catch (e) {
      console.error(e);
    }
  };

  const deletePayment = async (paymentId: string, studentId: string) => {
    try {
      const res = await fetch('/api/fees/payment/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: studentId, paymentId })
      });
      const data = await res.json();
      if (data.success) {
        // Update history modal data if it's currently open, and recalculate locally
        if (historyModal && historyModal.id === studentId) {
          setHistoryModal(prev => {
            if (!prev) return null;
            const updatedPayments = prev.payments.filter(p => p.id !== paymentId);
            const newPaidAmount = updatedPayments.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
            return {
              ...prev,
              payments: updatedPayments,
              paidAmount: newPaidAmount,
              balance: prev.totalFee - newPaidAmount
            };
          });
        }
        loadCollection();
      } else {
        console.error(data.message || 'Failed to delete payment');
      }
    } catch (e) {
      console.error('Error deleting payment:', e);
    }
  };

  const downloadReceipt = (payment: FeePayment, student: StudentFeeData) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('EduAI SaaS', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Fee Receipt', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Receipt ID: " + payment.id, 20, 50);
    doc.text("Date: " + new Date(payment.date).toLocaleString(), 20, 60);
    
    doc.text("Student Name: " + student.name, 20, 80);
    doc.text("Roll Number: " + student.id, 20, 90);
    doc.text("Class & Section: " + student.className + " - " + student.section, 20, 100);
    
    doc.setLineWidth(0.5);
    doc.line(20, 110, 190, 110);
    
    doc.text('Amount Paid:', 20, 120);
    doc.text("$" + payment.amount, 150, 120);
    
    doc.text('Payment Method:', 20, 130);
    doc.text(payment.method, 150, 130);
    
    if (payment.remarks) {
      doc.text('Remarks:', 20, 140);
      doc.text(payment.remarks, 150, 140);
    }
    
    doc.line(20, 150, 190, 150);
    doc.text('Thank you!', 105, 170, { align: 'center' });

    doc.save("Receipt_" + payment.id + ".pdf");
  };
  const sendReceiptViaTelegram = async (payment: FeePayment, student: StudentFeeData) => {
    setSendingTelegramId(payment.id);
    try {
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text('EduAI SaaS', 105, 20, { align: 'center' });
      
      doc.setFontSize(16);
      doc.text('Fee Receipt', 105, 30, { align: 'center' });

      doc.setFontSize(12);
      doc.text("Receipt ID: " + payment.id, 20, 50);
      doc.text("Date: " + new Date(payment.date).toLocaleString(), 20, 60);
      
      doc.text("Student Name: " + student.name, 20, 80);
      doc.text("Roll Number: " + student.id, 20, 90);
      doc.text("Class & Section: " + student.className + " - " + student.section, 20, 100);
      
      doc.setLineWidth(0.5);
      doc.line(20, 110, 190, 110);
      
      doc.text('Amount Paid:', 20, 120);
      doc.text("$" + payment.amount, 150, 120);
      
      doc.text('Payment Method:', 20, 130);
      doc.text(payment.method, 150, 130);
      
      if (payment.remarks) {
        doc.text('Remarks:', 20, 140);
        doc.text(payment.remarks, 150, 140);
      }
      
      doc.line(20, 150, 190, 150);
      doc.text('Thank you!', 105, 170, { align: 'center' });

      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const message = `*Fee Receipt*
Receipt ID: ${payment.id}
Date: ${new Date(payment.date).toLocaleString()}
Amount Paid: $${payment.amount}
Method: ${payment.method}

Thank you!`;
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Receipt sent successfully to ' + student.name);
      } else {
        alert(`Failed to send receipt: ${data.message}`);
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while sending the receipt.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-center border-b border-white/10 pb-4 flex-wrap gap-2">
        <button 
          onClick={() => setSubTab('structure')} 
          className={"px-6 py-2 font-bold border-b-2 transition-colors " + (subTab === 'structure' ? 'text-indigo-400 border-indigo-400' : 'text-gray-400 border-transparent hover:text-white')}
        >
          Fee Structure Setup
        </button>
        <button 
          onClick={() => setSubTab('collection')} 
          className={"px-6 py-2 font-bold border-b-2 transition-colors " + (subTab === 'collection' ? 'text-indigo-400 border-indigo-400' : 'text-gray-400 border-transparent hover:text-white')}
        >
          Fee Collection
        </button>
      </div>

      {subTab === 'structure' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-[#0f0f0f]/60 border border-white/5 p-5 flex flex-col sm:flex-row sm:items-center gap-4 rounded-2xl">
            <h2 className="text-xl font-bold text-white whitespace-nowrap">Context Setup</h2>
            <div className="flex items-center gap-4 w-full">
              <select 
                className="w-full sm:w-48 px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
                value={structClass}
                onChange={e => setStructClass(e.target.value)}
              >
                <option value="">Select Class...</option>
                {classes.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select 
                className="w-full sm:w-48 px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
                value={structSection}
                onChange={e => setStructSection(e.target.value)}
              >
                <option value="">Select Section...</option>
                {sections.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          {!structClass || !structSection ? (
            <div className="p-10 text-center text-gray-400 bg-[#0f0f0f]/60 rounded-2xl border border-dashed border-white/10">
              Select a class and section to configure its fee structure.
            </div>
          ) : loadingStructure ? (
            <div className="p-10 text-center text-gray-400">Loading...</div>
          ) : (
            <div className="bg-[#0f0f0f]/60 border border-white/5 p-6 rounded-2xl space-y-6 shadow-xl">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold text-white">Configured Fees</h3>
                <button 
                  onClick={addFeeItem}
                  className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-medium transition-colors"
                >
                  <Plus size={16} /> Add Fee Item
                </button>
              </div>

              {feeItems.length === 0 ? (
                <div className="text-center p-8 text-gray-400 border border-dashed border-white/10 rounded-xl">
                  No fees configured yet. Click "Add Fee Item" to start.
                </div>
              ) : (
                <div className="space-y-4">
                  {feeItems.map((item, idx) => (
                    <div key={item.id} className="flex gap-4 items-center bg-black/40 p-4 rounded-xl border border-white/5">
                      <div className="flex-1">
                        <label className="block text-xs font-medium text-gray-500 mb-1">Fee Name (e.g. Transport, Exam)</label>
                        <input 
                          type="text" 
                          placeholder="Fee Name"
                          className="w-full px-3 py-2 bg-transparent border-b border-white/10 text-white outline-none focus:border-indigo-500"
                          value={item.name}
                          onChange={e => updateFeeItem(item.id, 'name', e.target.value)}
                          disabled={DEFAULT_FEE_TYPES.some(d => d.toLowerCase() === item.name.toLowerCase())}
                        />
                      </div>
                      <div className="w-32">
                        <label className="block text-xs font-medium text-gray-500 mb-1">Amount ($)</label>
                        <input 
                          type="number" 
                          placeholder="0"
                          className="w-full px-3 py-2 bg-transparent border-b border-white/10 text-white outline-none focus:border-indigo-500"
                          value={item.amount}
                          onChange={e => updateFeeItem(item.id, 'amount', Number(e.target.value))}
                        />
                      </div>
                      <div className="pt-5">
                        {!DEFAULT_FEE_TYPES.some(d => d.toLowerCase() === item.name.toLowerCase()) && (
                          <button onClick={() => removeFeeItem(item.id)} className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                            <Trash2 size={18} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  <div className="flex justify-between items-center p-4 bg-indigo-500/10 rounded-xl border border-indigo-500/20">
                    <span className="font-bold text-indigo-200">Total Calculated Fee:</span>
                    <span className="text-xl font-extrabold text-indigo-400">${totalStructureAmount}</span>
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-white/10 flex justify-end">
                <button 
                  onClick={saveStructure}
                  disabled={savingStructure}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg disabled:opacity-50"
                >
                  <Check size={18} /> {savingStructure ? 'Saving...' : 'Save Structure'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {subTab === 'collection' && (
        <div className="space-y-6 animate-in fade-in">
           <div className="bg-[#0f0f0f]/60 border border-white/5 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl">
            <h2 className="text-xl font-bold text-white whitespace-nowrap">Collection Desk</h2>
            <div className="flex items-center gap-4">
              <select 
                className="w-full sm:w-48 px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
                value={collClass}
                onChange={e => setCollClass(e.target.value)}
              >
                <option value="">Select Class...</option>
                {classes.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select 
                className="w-full sm:w-48 px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
                value={collSection}
                onChange={e => setCollSection(e.target.value)}
              >
                <option value="">Select Section...</option>
                {sections.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <button onClick={loadCollection} disabled={!collClass || !collSection} className="bg-white/10 hover:bg-white/20 p-2.5 rounded-xl disabled:opacity-50">
                <RefreshCw size={20} className="text-white" />
              </button>
            </div>
          </div>

          {!collClass || !collSection ? (
            <div className="p-10 text-center text-gray-400 bg-[#0f0f0f]/60 rounded-2xl border border-dashed border-white/10">
              Select a class and section to view student collections.
            </div>
          ) : loadingCollection ? (
            <div className="p-10 text-center text-gray-400">Loading...</div>
          ) : collectionData.length === 0 ? (
            <div className="p-10 text-center text-gray-400 bg-[#0f0f0f]/60 rounded-2xl border border-white/5">
              No students found in this class.
            </div>
          ) : (
            <div className="bg-[#0f0f0f]/60 border border-white/5 rounded-2xl overflow-x-auto shadow-xl">
              <table className="w-full text-left min-w-[800px]">
                <thead>
                  <tr className="border-b border-white/10 bg-black/20">
                    <th className="p-4 text-gray-400 font-medium">Roll No</th>
                    <th className="p-4 text-gray-400 font-medium">Student Name</th>
                    <th className="p-4 text-gray-400 font-medium">Total Fee</th>
                    <th className="p-4 text-gray-400 font-medium">Paid Amount</th>
                    <th className="p-4 text-gray-400 font-medium">Balance</th>
                    
                    <th className="p-4 text-gray-400 font-medium">Status</th>
                    <th className="p-4 text-right text-gray-400 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {collectionData.map((s) => (
                    <tr key={s.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="p-4 text-gray-300">{s.rollNumber}</td>
                      <td className="p-4 font-medium text-white">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center border border-white/10 overflow-hidden shrink-0">
                            {s.photo ? (
                              <img src={s.photo} alt={s.name} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-xs font-bold text-indigo-300">{s.name.charAt(0)}</span>
                            )}
                          </div>
                          {s.name}
                        </div>
                      </td>
                      <td className="p-4 text-gray-300">${s.totalFee}</td>
                      <td className="p-4 text-emerald-400 font-medium">${s.paidAmount}</td>
                      <td className="p-4 text-red-400 font-medium">${s.balance}</td>
                      
                      <td className="p-4">
                        <span className={"px-2.5 py-1 rounded-md text-xs font-bold " + (
                          s.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' :
                          s.status === 'Partial' ? 'bg-orange-500/10 text-orange-400' :
                          'bg-red-500/10 text-red-400'
                        )}>
                          {s.status}
                        </span>
                      </td>
                      <td className="p-4 text-right flex justify-end gap-2">
                        <button 
                          onClick={() => setHistoryModal(s)}
                          className="bg-white/5 hover:bg-white/10 text-indigo-300 px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors"
                        >
                          <History size={14} /> History
                        </button>
                        <button 
                          onClick={() => setPayModal({ id: s.id, name: s.name, rollNumber: s.rollNumber, balance: s.balance })}
                          disabled={s.status === 'Paid'}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                        >
                          <IndianRupee size={14} /> Pay
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Payment Modal */}
      {payModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-xl font-bold text-white mb-2">Record Payment</h2>
            <p className="text-gray-400 text-sm mb-6">Recording fee for <strong className="text-white">{payModal.name}</strong> ({payModal.rollNumber})</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1.5">Amount ($)</label>
                <div className="flex justify-between text-xs mb-1 text-gray-500">
                  <span>Enter amount to pay</span>
                  <span>Max: ${payModal.balance}</span>
                </div>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500"
                  value={payAmount}
                  onChange={e => {
                    const val = Number(e.target.value);
                    if (val > payModal.balance) {
                      setPayAmount(payModal.balance.toString());
                    } else {
                      setPayAmount(e.target.value);
                    }
                  }}
                  max={payModal.balance}
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1.5">Payment Method</label>
                <select 
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none"
                  value={payMethod}
                  onChange={e => setPayMethod(e.target.value)}
                >
                  <option>Cash</option>
                  <option>Card</option>
                  <option>Bank Transfer</option>
                  <option>UPI / Online</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1.5">Remarks (Optional)</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500"
                  value={payRemarks}
                  onChange={e => setPayRemarks(e.target.value)}
                  placeholder="e.g. Q1 Transport Fee"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setPayModal(null)}
                className="flex-1 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-medium transition-colors text-white"
              >
                Cancel
              </button>
              <button 
                onClick={submitPayment}
                disabled={!payAmount}
                className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
              >
                Record Payment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 w-full max-w-2xl shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-xl font-bold text-white">Payment History</h2>
                <p className="text-gray-400 text-sm mt-1">{historyModal.name} ({historyModal.rollNumber})</p>
              </div>
              <button 
                onClick={() => setHistoryModal(null)}
                className="text-gray-400 hover:text-white p-2"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
              {historyModal.payments.length === 0 ? (
                <div className="text-center p-6 text-gray-500 border border-dashed border-white/10 rounded-xl">
                  No previous payments found.
                </div>
              ) : (
                historyModal.payments.map((p, idx) => (
                  <div key={idx} className="bg-black/40 border border-white/5 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-white">${p.amount}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-white/10 text-gray-300">{p.method}</span>
                      </div>
                      <div className="text-sm text-gray-400 mt-1">
                        {new Date(p.date).toLocaleString()}
                      </div>
                      {p.remarks && <div className="text-sm text-gray-500 mt-1">{p.remarks}</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => downloadReceipt(p, historyModal)}
                        className="flex items-center gap-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                      >
                        <Download size={14} /> Receipt
                      </button>
                      <button 
                        onClick={() => sendReceiptViaTelegram(p, historyModal)}
                        disabled={sendingTelegramId === p.id}
                        className="flex items-center gap-2 bg-[#229ED9]/10 hover:bg-[#229ED9]/20 text-[#229ED9] px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                      >
                        {sendingTelegramId === p.id ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                        Telegram
                      </button>
                      <button 
                        onClick={() => deletePayment(p.id, historyModal.id)}
                        className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors"
                        title="Delete record"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
              <button 
                onClick={() => setHistoryModal(null)}
                className="w-full px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-medium transition-colors text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
