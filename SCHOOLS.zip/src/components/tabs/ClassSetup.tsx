import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Search, Settings, ArrowRight, ArrowUpRight, Users, ChevronLeft } from 'lucide-react';

interface ClassData {
  id: string;
  className: string;
  section: string;
  classTeacher: string;
  totalStudents: number;
}





export function ClassSetup() {
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [staffList, setStaffList] = useState<any[]>([]);

  const [promoteForm, setPromoteForm] = useState({ fromClass: '', toClass: '' });
  const [selectiveToClass, setSelectiveToClass] = useState('');
  const [search, setSearch] = useState('');
  const [promoteModal, setPromoteModal] = useState(false);
  const [isPromoting, setIsPromoting] = useState(false);
  const [selectedClassForPromotion, setSelectedClassForPromotion] = useState<any>(null);
  const [classStudents, setClassStudents] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [selectivePromoteModal, setSelectivePromoteModal] = useState(false);
  const [actionType, setActionType] = useState<'promote' | 'demote' | 'reassign'>('promote');


  
  const fetchClasses = async () => {
    try {
      const res = await fetch('/api/classes');
      if (res.ok) {
        const data = await res.json();
        // Sort classes
        data.sort((a: any, b: any) => a.className.localeCompare(b.className) || a.section.localeCompare(b.section));
        setClasses(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const dynamicClassesList = classes.map(c => c.className + (c.section ? ' - ' + c.section : ''));

  useEffect(() => {
    if (classes.length > 0) {
      if (!promoteForm.fromClass) {
        setPromoteForm({ fromClass: dynamicClassesList[0] || '', toClass: dynamicClassesList[1] || dynamicClassesList[0] || '' });
      }
      if (!selectiveToClass) {
        setSelectiveToClass(dynamicClassesList[0] || '');
      }
    }
  }, [classes, promoteForm.fromClass, selectiveToClass]);
  
  useEffect(() => {
    fetchClasses();
    fetch('/api/staff').then(res => res.json()).then(data => setStaffList(data)).catch(console.error);
  }, []);


  
  
  // Bulk promote modal states

  // Class Students view states
  const [isBulkMode, setIsBulkMode] = useState(false);

  const [classForm, setClassForm] = useState<Partial<ClassData> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleSaveClass = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!classForm) return;
    
    const isEdit = classForm.id && classes.some(c => c.id === classForm.id);
    const method = isEdit ? 'PUT' : 'POST';
    const url = isEdit ? '/api/classes/' + classForm.id : '/api/classes';
    
    const payload = { ...classForm };
    if (!isEdit && !payload.id) {
       payload.id = 'CLS' + Math.floor(Math.random() * 10000);
       payload.totalStudents = 0;
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        fetchClasses();
        setClassForm(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const confirmDeleteClass = async () => {
    if (deleteConfirmId) {
      try {
        const res = await fetch('/api/classes/' + deleteConfirmId, { method: 'DELETE' });
        if (res.ok) {
          fetchClasses();
          setDeleteConfirmId(null);
        }
      } catch (e) {
        console.error(e);
      }
    }
  };


  const handleSinglePromoteClick = (studentId: string, e: any, type: 'promote' | 'demote' = 'promote') => {
    e.stopPropagation();
    setSelectedIds([studentId]);
    setActionType(type);
    setSelectivePromoteModal(true);
  };

  const handlePromote = async (e: import("react").FormEvent) => {
    e.preventDefault();
    setIsPromoting(true);
    try {
      const res = await fetch('/api/students/bulk-promote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromClassName: promoteForm.fromClass,
          toClassName: promoteForm.toClass
        })
      });
      if (res.ok) {
        const data = await res.json();
        alert(`Successfully promoted ${data.promotedCount} students!`);
        setPromoteModal(false);
        fetchClasses();
      }
    } catch (err) {
      console.error(err);
    }
    setIsPromoting(false);
  };

  const fetchClassStudents = async (cls: ClassData) => {
    try {
      const formattedClassName = `${cls.className} - ${cls.section}`;
      const res = await fetch(`/api/students?className=${encodeURIComponent(formattedClassName)}`);
      if (res.ok) {
        const data = await res.json();
        setClassStudents(data);
        setSelectedIds([]);
        setSelectedClassForPromotion(cls);
      }
    } catch (err) {
      console.error("Failed to fetch students", err);
    }
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const handleSelectivePromote = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (selectedIds.length === 0) return;
    setIsPromoting(true);
    try {
      const res = await fetch('/api/students/promote-selected', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentIds: selectedIds,
          toClassName: selectiveToClass
        })
      });
      if (res.ok) {
        const data = await res.json();
        alert(`Successfully promoted ${data.promotedCount} students!`);
        setSelectivePromoteModal(false);
        setSelectedIds([]);
        // Re-fetch students to reflect changes
        if (selectedClassForPromotion) {
          fetchClassStudents(selectedClassForPromotion);
          fetchClasses();
        }
      }
    } catch (err) {
      console.error(err);
    }
    setIsPromoting(false);
  };

  const filteredClasses = classes.filter(c => 
    c.className.toLowerCase().includes(search.toLowerCase()) || 
    c.section.toLowerCase().includes(search.toLowerCase())
  );

  if (selectedClassForPromotion) {
    return (
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSelectedClassForPromotion(null)}
              className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors"
            >
              <ChevronLeft size={24} />
            </button>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Students - {selectedClassForPromotion.className} Section {selectedClassForPromotion.section}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                setIsBulkMode(!isBulkMode);
                if (isBulkMode) setSelectedIds([]);
              }}
              className={`px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg ${isBulkMode ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20' : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'}`}
            >
              {isBulkMode ? 'Cancel Bulk Mode' : 'Bulk Promote Mode'}
            </button>
            {isBulkMode && selectedIds.length > 0 && (
              <button 
                onClick={() => { setActionType('reassign'); setSelectivePromoteModal(true); }}
                className="bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                <ArrowUpRight size={18} /> Reassign Selected ({selectedIds.length})
              </button>
            )}
          </div>
        </div>

                <div>
          {classStudents.length === 0 ? (
            <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No students found in this class.</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {classStudents.map((student) => (
                <div 
                  key={student.id} 
                  className={`bg-[#151515] border ${selectedIds.includes(student.id) ? 'border-indigo-500 shadow-lg shadow-indigo-500/10' : 'border-white/5 hover:border-white/10'} rounded-2xl overflow-hidden transition-all group flex flex-col`}
                >
                  <div className="p-5 relative flex-1">
                    {isBulkMode && (
                      <div className="absolute top-4 left-4 z-10">
                        <input 
                          type="checkbox" 
                          className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                          checked={selectedIds.includes(student.id)}
                          onChange={() => toggleSelectStudent(student.id)}
                        />
                      </div>
                    )}
                    
                    <div className="flex flex-col items-center mt-2">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner overflow-hidden">
                        {student.photo ? (
                          <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-2xl font-bold text-indigo-300">
                            {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{student.name}</h3>
                      <div className="text-xs text-gray-400 mt-1 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                        Roll No: {student.rollNumber}
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                    <span className="text-xs text-gray-400 font-medium px-2">{student.gender || '-'}</span>
                    {!isBulkMode && (
                      <button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e, 'promote')}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
                      >
                        Promote
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selective Promote Modal */}
        {selectivePromoteModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
            <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative">
              <button 
                onClick={() => setSelectivePromoteModal(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
              >
                ✕
              </button>
              
              <h3 className="text-xl font-bold text-white mb-6">
                {actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign'} Selected Students
              </h3>
              <p className="text-sm text-gray-400 mb-6">
                You are about to {actionType === 'promote' ? 'promote' : actionType === 'demote' ? 'demote' : 'reassign'} {selectedIds.length} student(s) to a new class.
              </p>

              <form onSubmit={handleSelectivePromote} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign'} To Class
                  </label>
                  <div className="relative">
                    <select 
                      className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                      value={selectiveToClass}
                      onChange={e => setSelectiveToClass(e.target.value)}
                    >
                      {dynamicClassesList.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setSelectivePromoteModal(false)}
                    className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    disabled={isPromoting}
                    className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isPromoting ? 'Processing...' : (actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white tracking-tight">Class Setup</h1>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setPromoteModal(true)}
            className="bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            <ArrowUpRight size={18} /> Bulk Reassign
          </button>
          <button onClick={() => setClassForm({ className: '', section: '', classTeacher: 'Unassigned' })} className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20">
            <Plus size={18} /> Add Class
          </button>
        </div>
      </div>

      <div className="bg-[#151515] border border-white/5 p-4 rounded-2xl flex flex-col md:flex-row gap-4 shadow-lg">
        <div className="flex-1 relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Search classes or sections..."
            className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 transition-colors"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-[#151515] border border-white/5 rounded-2xl overflow-x-auto shadow-xl">
        <table className="w-full text-left min-w-[800px]">
          <thead>
            <tr className="bg-black/20 border-b border-white/10">
              <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Class</th>
              <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Section</th>
              <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Class Teacher</th>
              <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Total Students</th>
              <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredClasses.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-8 text-center text-gray-500">No classes found.</td>
              </tr>
            ) : (
              filteredClasses.map((cls) => (
                <tr 
                  key={cls.id} 
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="p-5 font-bold text-white">{cls.className}</td>
                  <td className="p-5 text-gray-300">
                    <span className="px-3 py-1 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-full text-xs font-bold">
                      {cls.section}
                    </span>
                  </td>
                  <td className="p-5 text-gray-400">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setClassForm(cls); }}
                      className="hover:text-indigo-400 transition-colors font-medium border-b border-dashed border-gray-600 hover:border-indigo-400 pb-0.5"
                    >
                      {cls.classTeacher || 'Unassigned'}
                    </button>
                  </td>
                  <td className="p-5 text-gray-400">
                    <button 
                      onClick={(e) => { e.stopPropagation(); fetchClassStudents(cls); }}
                      className="hover:text-emerald-400 transition-colors font-medium border-b border-dashed border-gray-600 hover:border-emerald-400 pb-0.5 flex items-center gap-1.5"
                    >
                      <Users size={14} />
                      {cls.totalStudents}
                    </button>
                  </td>
                  <td className="p-5">
                    <div className="flex justify-end gap-2">
                      
                      <button onClick={(e) => { e.stopPropagation(); setClassForm(cls); }} className="flex items-center gap-1.5 px-3 py-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Edit size={16} /> Edit
                      </button>
                      <button onClick={(e) => { e.stopPropagation(); setDeleteConfirmId(cls.id); }} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-sm font-bold transition-colors">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {promoteModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setPromoteModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            
            <h3 className="text-xl font-bold text-white mb-6">Bulk Reassign Students</h3>
            <p className="text-sm text-gray-400 mb-6">Move all students from one class to another at once.</p>

            <form onSubmit={handlePromote} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">From Class</label>
                  <div className="relative">
                    <select 
                      className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                      value={promoteForm.fromClass}
                      onChange={e => setPromoteForm({...promoteForm, fromClass: e.target.value})}
                    >
                      {dynamicClassesList.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center text-gray-500 py-2">
                  <ArrowRight size={20} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">To Class</label>
                  <div className="relative">
                    <select 
                      className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
                      value={promoteForm.toClass}
                      onChange={e => setPromoteForm({...promoteForm, toClass: e.target.value})}
                    >
                      {dynamicClassesList.map(c => <option key={c} value={c} className="bg-[#151515]">{c}</option>)}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-2">
                <button 
                  type="button" 
                  onClick={() => setPromoteModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={isPromoting || promoteForm.fromClass === promoteForm.toClass}
                  className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isPromoting ? 'Processing...' : 'Confirm Reassign'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Class Form Modal */}
      {classForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setClassForm(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            
            <h3 className="text-xl font-bold text-white mb-6">
              {classForm.id ? 'Edit Class' : 'Add New Class'}
            </h3>
            
            <form onSubmit={handleSaveClass} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Class Name *</label>
                <input 
                  required
                  type="text" 
                  placeholder="e.g. Class 11"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.className || ''} 
                  onChange={e => setClassForm({...classForm, className: e.target.value})} 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Section *</label>
                <input 
                  required
                  type="text" 
                  placeholder="e.g. A"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.section || ''} 
                  onChange={e => setClassForm({...classForm, section: e.target.value})} 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Class Teacher</label>
                <select 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none cursor-pointer" 
                  value={classForm.classTeacher || ''} 
                  onChange={e => setClassForm({...classForm, classTeacher: e.target.value})} 
                >
                  <option value="" className="bg-[#151515]">Select a Class Teacher</option>
                  {staffList
                    .filter(staff => {
                      if (classForm.classTeacher === staff.name) return true;
                      return !classes.some(c => c.classTeacher === staff.name && c.id !== classForm.id);
                    })
                    .map(staff => (
                      <option key={staff.id} value={staff.name} className="bg-[#151515]">{staff.name} ({staff.role})</option>
                  ))}
                </select>
              </div>
              
              <div className="flex gap-4 pt-2">
                <button 
                  type="button" 
                  onClick={() => setClassForm(null)}
                  className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-indigo-500/20"
                >
                  Save Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-sm w-full mx-4 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">Delete Class</h3>
            <p className="text-gray-400 mb-8">Are you sure you want to delete this class? Students in this class will need to be reassigned.</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDeleteClass}
                className="flex-1 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-colors shadow-lg shadow-red-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
