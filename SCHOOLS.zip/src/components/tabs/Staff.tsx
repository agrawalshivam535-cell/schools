import React, { useState, useEffect } from 'react';
import { Search, Plus, Eye, Trash2, Edit, Phone, Mail } from 'lucide-react';

interface StaffMember {
  id: string;
  name: string;
  role: string;
  department: string;
  phone: string;
  email: string;
  status: 'Active' | 'On Leave' | 'Inactive';
  photo?: string;
}



export function Staff() {
  const [staffList, setStaffList] = useState<StaffMember[]>([]);
  


  const fetchStaff = async () => {
    try {
      const res = await fetch('/api/staff');
      if (res.ok) {
        const data = await res.json();
        setStaffList(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);
  
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All Departments');

  // Modals state
  const [editForm, setEditForm] = useState<Partial<StaffMember> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [viewDetails, setViewDetails] = useState<StaffMember | null>(null);

  const departments = ['All Departments', 'Administration', 'Mathematics', 'Science', 'English', 'Physical Education'];

  const filteredStaff = staffList.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchesDept = departmentFilter === 'All Departments' || s.department === departmentFilter;
    return matchesSearch && matchesDept;
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image must be smaller than 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (editForm) {
          setEditForm({ ...editForm, photo: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveStaff = async (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!editForm) return;

    const isEdit = editForm.id && staffList.some(s => s.id === editForm.id);
    const method = isEdit ? 'PUT' : 'POST';
    const url = isEdit ? '/api/staff/' + editForm.id : '/api/staff';
    
    const payload = { ...editForm };
    if (!isEdit && !payload.id) {
       payload.id = 'S' + Math.floor(Math.random() * 1000 + 100);
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        fetchStaff();
        setEditForm(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const confirmDelete = async () => {
    if (deleteConfirmId) {
      try {
        const res = await fetch('/api/staff/' + deleteConfirmId, { method: 'DELETE' });
        if (res.ok) {
          fetchStaff();
          setDeleteConfirmId(null);
        }
      } catch (e) {
        console.error(e);
      }
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white tracking-tight">Staff Directory</h1>
        <button 
          onClick={() => setEditForm({ name: '', role: '', department: 'Administration', phone: '', email: '', status: 'Active' })}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20"
        >
          <Plus size={18} /> Add Staff
        </button>
      </div>

      <div className="bg-[#151515] border border-white/5 p-4 rounded-2xl flex flex-col md:flex-row gap-4 shadow-lg">
        <div className="flex-1 relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Search by name or ID..."
            className="w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 transition-colors"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <select 
              className="w-full sm:w-56 px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-500 appearance-none cursor-pointer"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            >
              {departments.map(d => <option key={d} value={d} className="bg-[#151515] text-white">{d}</option>)}
            </select>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
          </div>
        </div>
      </div>

            <div>
        {filteredStaff.length === 0 ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No staff found matching your criteria.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredStaff.map((staff) => (
              <div 
                key={staff.id} 
                className="bg-[#151515] border border-white/5 hover:border-white/10 rounded-2xl overflow-hidden transition-all group flex flex-col"
              >
                <div 
                  className="p-5 cursor-pointer relative"
                  onClick={() => setViewDetails(staff)}
                >
                  <div className="flex flex-col items-center mt-2">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner overflow-hidden">
                      {staff.photo ? (
                        <img src={staff.photo} alt={staff.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl font-bold text-indigo-300">
                          {staff.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{staff.name}</h3>
                    <div className="text-sm text-indigo-300 mt-1 font-medium">{staff.role}</div>
                    <div className="text-xs text-gray-400 mt-2 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                      ID: {staff.id}
                    </div>
                  </div>
                </div>

                <div 
                  className="px-5 pb-5 cursor-pointer flex-1 flex flex-col justify-center"
                  onClick={() => setViewDetails(staff)}
                >
                  <div className="space-y-3 mt-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Dept</span>
                      <span className="text-gray-300 bg-white/5 px-2 py-0.5 rounded border border-white/10">{staff.department}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Status</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold border ${
                        staff.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                        staff.status === 'On Leave' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 
                        'bg-red-500/10 text-red-400 border-red-500/20'
                      }`}>
                        {staff.status}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-white/5">
                      <div className="flex items-center gap-2 text-xs text-gray-400 mb-1.5">
                        <Phone size={12} className="text-gray-500" /> {staff.phone}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <Mail size={12} className="text-gray-500" /> {staff.email}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                  <button 
                    onClick={() => setViewDetails(staff)} 
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                  >
                    <Eye size={14} /> View
                  </button>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => setEditForm(staff)} 
                      className="p-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded transition-colors"
                      title="Edit Staff"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(staff.id)} 
                      className="p-1.5 text-red-400 hover:bg-red-500/10 rounded transition-colors"
                      title="Delete Staff"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60  flex items-center justify-center z-50 animate-in fade-in p-4">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-sm w-full shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">Delete Staff</h3>
            <p className="text-gray-400 mb-8">Are you sure you want to delete this staff member? This action cannot be undone.</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-colors shadow-lg shadow-red-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit/Add Modal */}
      {editForm && (
        <div className="fixed inset-0 bg-black/60  z-50 overflow-y-auto animate-in fade-in flex flex-col p-4">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-2xl w-full m-auto shadow-2xl relative shrink-0">
            <button 
              onClick={() => setEditForm(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            <h3 className="text-xl font-bold text-white mb-6">
              {editForm.id ? 'Edit Staff Profile' : 'Add New Staff'}
            </h3>
            
            <div className="space-y-6">
              <div className="flex flex-col items-center mb-2">
                <div className="relative mb-3">
                  <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-dashed border-indigo-500/50 flex items-center justify-center relative overflow-hidden group">
                    {editForm.photo ? (
                      <img src={editForm.photo} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-3xl font-bold text-indigo-400">{editForm.name ? editForm.name.charAt(0) : '?'}</span>
                    )}
                    <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                      <span className="text-white text-xs font-bold">{editForm.photo ? 'Change' : 'Upload'}</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                  {editForm.photo && (
                    <button
                      type="button"
                      onClick={() => setEditForm({ ...editForm, photo: undefined })}
                      className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-colors z-10"
                      title="Remove Photo"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
                <div className="text-xs text-gray-500 text-center">Recommended: Square image, max 2MB</div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Full Name *</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.name || ''} onChange={e => setEditForm({...editForm, name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Staff ID (Optional)</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    placeholder="Auto-generated if left blank"
                    value={editForm.id || ''} onChange={e => setEditForm({...editForm, id: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Role *</label>
                  <input type="text" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    placeholder="e.g. Teacher, Admin"
                    value={editForm.role || ''} onChange={e => setEditForm({...editForm, role: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Department *</label>
                  <div className="relative">
                    <select className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none cursor-pointer" 
                      value={editForm.department || ''} onChange={e => setEditForm({...editForm, department: e.target.value})}>
                      {departments.filter(d => d !== 'All Departments').map(d => <option key={d} className="bg-[#151515] text-white">{d}</option>)}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Phone Number *</label>
                  <input type="tel" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.phone || ''} onChange={e => setEditForm({...editForm, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Email Address *</label>
                  <input type="email" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                    value={editForm.email || ''} onChange={e => setEditForm({...editForm, email: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Status *</label>
                  <div className="flex gap-2">
                    {['Active', 'On Leave', 'Inactive'].map((statusOption) => (
                      <button
                        key={statusOption}
                        type="button"
                        onClick={() => setEditForm({ ...editForm, status: statusOption as any })}
                        className={`flex-1 py-3 px-2 rounded-xl text-sm font-medium transition-colors border ${
                          editForm.status === statusOption
                            ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                            : 'bg-black/40 border-white/10 text-gray-400 hover:bg-white/5'
                        }`}
                      >
                        {statusOption}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-4 pt-4 border-t border-white/5 mt-8">
                <button type="button" onClick={() => setEditForm(null)} className="px-6 py-2.5 text-gray-400 hover:text-white font-medium transition-colors">
                  Cancel
                </button>
                <button type="button" onClick={(e) => handleSaveStaff(e as any)} className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors shadow-lg shadow-indigo-500/20">
                  {editForm.id ? 'Save Changes' : 'Add Staff'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Details Modal */}
      {viewDetails && (
        <div className="fixed inset-0 bg-black/60  z-50 overflow-y-auto animate-in fade-in flex flex-col p-4">
          <div className="bg-[#151515] border border-white/10 rounded-2xl p-6 sm:p-8 max-w-lg w-full m-auto shadow-2xl relative shrink-0">
            <button 
              onClick={() => setViewDetails(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
            
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-2xl font-bold border border-indigo-500/30 overflow-hidden">
                {viewDetails.photo ? (
                  <img src={viewDetails.photo} alt={viewDetails.name} className="w-full h-full object-cover" />
                ) : (
                  viewDetails.name.charAt(0)
                )}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{viewDetails.name}</h3>
                <p className="text-indigo-400 text-sm font-medium">{viewDetails.role}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-gray-500 text-sm">Staff ID:</span>
                <span className="text-white text-sm font-medium">{viewDetails.id}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-gray-500 text-sm">Department:</span>
                <span className="text-white text-sm">{viewDetails.department}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-gray-500 text-sm">Phone Number:</span>
                <span className="text-white text-sm">{viewDetails.phone}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-gray-500 text-sm">Email Address:</span>
                <span className="text-white text-sm">{viewDetails.email}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-gray-500 text-sm">Status:</span>
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${
                  viewDetails.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                  viewDetails.status === 'On Leave' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 
                  'bg-red-500/10 text-red-400 border-red-500/20'
                }`}>
                  {viewDetails.status}
                </span>
              </div>
            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button 
                onClick={() => {
                  setEditForm(viewDetails);
                  setViewDetails(null);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm font-medium transition-colors"
              >
                <Edit size={16} /> Edit Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

