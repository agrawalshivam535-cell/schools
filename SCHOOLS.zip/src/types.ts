export interface User {
  id?: string;
  loginId: string;
  name: string;
  email: string;
  hasApiKey?: boolean;
  maskedApiKey?: string;
  apiKey?: string;
}

export interface Student {
  id: string;
  rollNumber: string;
  name: string;
  className: string;
  section?: string;
  parentPhone?: string;
  telegramChatId?: string;
  dob?: string;
  gender?: string;
  address?: string;
  fatherName?: string;
  motherName?: string;
  email?: string;
  status?: string;
}

export interface AttendanceRecord {
  id: string;
  rollNumber: string;
  name: string;
  status: 'Present' | 'Absent' | 'Late';
}

export interface ExamRecord {
  id: string;
  rollNumber: string;
  name: string;
  totalMarks: string;
  marksObtained: string;
  previousMarks?: string | null;
}

export interface FeeStructureItem {
  id: string;
  name: string;
  amount: number;
}

export interface FeePayment {
  id: string;
  date: string;
  amount: number;
  method: string;
  remarks: string;
}

export interface StudentFeeData {
  id: string;
  rollNumber: string;
  name: string;
  className: string;
  section: string;
  parentPhone?: string;
  telegramChatId?: string;
  totalFee: number;
  paidAmount: number;
  balance: number;
  status: 'Paid' | 'Partial' | 'Unpaid';
  payments: FeePayment[];
  paidMonths?: string[];
}
