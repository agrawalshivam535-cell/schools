
// Silence transient network errors in AI Studio previews
const originalConsoleError = console.error;
console.error = (...args) => {
  if (args[0] && typeof args[0] === 'string' && args[0].includes('Failed to fetch')) return;
  if (args[0] && args[0] instanceof TypeError && args[0].message === 'Failed to fetch') return;
  originalConsoleError(...args);
};

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
