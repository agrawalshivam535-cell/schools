import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { Dashboard } from './components/tabs/Dashboard';
import { Students } from './components/tabs/Students';
import { Attendance } from './components/tabs/Attendance';
import { Exams } from './components/tabs/Exams';
import { Timetable } from './components/tabs/Timetable';
import { Fees } from './components/tabs/Fees';
import { ClassSetup } from './components/tabs/ClassSetup';
import { Staff } from './components/tabs/Staff';
import { AuthPage } from './components/AuthPage';
import { User } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('schoolos_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  const handleLogin = (newUser: User) => {
    setUser(newUser);
    try {
      localStorage.setItem('schoolos_user', JSON.stringify(newUser));
    } catch (e) {}
  };

  const handleLogout = () => {
    setUser(null);
    try {
      localStorage.removeItem('schoolos_user');
    } catch (e) {}
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
    try {
      localStorage.setItem('schoolos_user', JSON.stringify(updatedUser));
    } catch (e) {}
  };

  const [activeTab, setActiveTab] = useState('dashboard');
  const [tabAction, setTabAction] = useState<string | null>(null);

  const handleNavigate = (tab: string, action?: string) => {
    setActiveTab(tab);
    setTabAction(action || null);
  };
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const renderTab = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard onNavigate={handleNavigate} />;
      case 'students': return <Students initialAction={tabAction} onActionComplete={() => setTabAction(null)} />;
      case 'attendance': return <Attendance />;
      case 'fees': return <Fees />;
      case 'exams': return <Exams user={user || undefined} onUpdateUser={handleUpdateUser} />;
      case 'timetable': return <Timetable />;
      case 'classsetup': return <ClassSetup />;
      case 'staff': return <Staff />;
      default: return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  if (!user) {
    return <AuthPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-[#050505] text-[#e5e7eb] font-sans antialiased overflow-x-hidden">
      {/* Animated Subtle Background Glows */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px]" />
        <div className="absolute top-1/2 -left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-[100px]" />
      </div>
      {/* Sidebar Backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={(t) => { setActiveTab(t); setSidebarOpen(false); }} 
        isOpen={sidebarOpen}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex flex-col min-w-0 lg:ml-[15.5rem] transition-all duration-300">
        <Topbar 
          user={user} 
          onOpenSidebar={() => setSidebarOpen(true)} 
          title={activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
          onLogout={handleLogout}
          onUpdateUser={handleUpdateUser}
        />
        <main className="p-5 sm:p-8 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              {renderTab()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
