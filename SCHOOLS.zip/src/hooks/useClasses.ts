import { useState, useEffect } from 'react';

export function useClasses() {
  const [classes, setClasses] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const res = await fetch('/api/classes');
        if (res.ok) {
          const data = await res.json();
          // Sort logically by class and section
          data.sort((a: any, b: any) => {
             const nameA = a.className;
             const nameB = b.className;
             const numA = parseInt(nameA.match(/\d+/)?.[0] || "0");
             const numB = parseInt(nameB.match(/\d+/)?.[0] || "0");
             if (numA !== numB) return numA - numB;
             return (a.section || 'A').localeCompare(b.section || 'A');
          });
          setClasses(data.map((c: any) => c.className + ' - ' + (c.section || 'A')));
        }
      } catch (e) {
        console.error('Failed to fetch classes', e);
      } finally {
        setLoading(false);
      }
    };
    fetchClasses();
  }, []);

  return { classes, loading };
}
