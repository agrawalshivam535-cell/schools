const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf8');

const target = `      let fullClassName = resultClass;
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        res = await fetch(\`/api/students?className=\${encodeURIComponent(fullClassName)}\`);
        data = await res.json();
      }`;

const replacement = `      let fullClassName = resultClass;
      if (resultClass !== 'All' && resultSection && resultSection !== 'All') {
        fullClassName = resultClass + ' - ' + resultSection;
      }
      
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        res = await fetch(\`/api/students?className=\${encodeURIComponent(fullClassName)}\`);
        data = await res.json();
      }`;

if (!code.includes(target)) {
  console.error("Could not find target!");
  process.exit(1);
}
code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log("Patched results fetching");
