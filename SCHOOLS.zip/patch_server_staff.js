import fs from 'fs';
let serverCode = fs.readFileSync('server.ts', 'utf-8');

const importLines = `
let staff: any[] = [];
try {
  staff = JSON.parse(fs.readFileSync('./staff.json', 'utf-8'));
} catch (e) {
  console.error("Could not load staff.json", e);
}
`;
serverCode = serverCode.replace('let attendanceRecords = [];', importLines + '\nlet attendanceRecords = [];');

const staffApi = `
  app.get("/api/staff", (req, res) => {
    res.json(staff);
  });
  app.post("/api/staff", (req, res) => {
    staff.push(req.body);
    res.json({ success: true, staff });
  });
  app.put("/api/staff/:id", (req, res) => {
    const idx = staff.findIndex(s => s.id === req.params.id);
    if (idx !== -1) {
      staff[idx] = { ...staff[idx], ...req.body };
      res.json({ success: true, staff });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });
  app.delete("/api/staff/:id", (req, res) => {
    staff = staff.filter(s => s.id !== req.params.id);
    res.json({ success: true, staff });
  });
`;

serverCode = serverCode.replace('  app.get("/api/dashboard", (req, res) => {', staffApi + '\n  app.get("/api/dashboard", (req, res) => {');

// Also update dashboard to use actual staff count
serverCode = serverCode.replace(
  'totalStaff: 12,',
  'totalStaff: staff.length,'
);

fs.writeFileSync('server.ts', serverCode);
console.log('patched server.ts with staff endpoints');
