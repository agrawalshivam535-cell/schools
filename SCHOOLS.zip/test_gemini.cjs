require('dotenv').config();
const { GoogleGenAI } = require('@google/genai');

async function test() {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = "Extract rollNumber, name, totalMarks (100), marksObtained in JSON array. Ensure the properties in the JSON objects are exactly \"rollNumber\", \"name\", \"totalMarks\", \"marksObtained\". Data: Roll 1 got 45, Roll 2 got 88.";
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [ { role: 'user', parts: [ { text: prompt } ] } ],
    config: { responseMimeType: 'application/json' }
  });
  
  console.log("Raw response:", response.text);
  const records = JSON.parse(response.text);
  console.log("Parsed:", records);
}
test().catch(console.error);
