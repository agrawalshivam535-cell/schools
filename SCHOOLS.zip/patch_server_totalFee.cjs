const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const oldTotalFee = `const totalFee = struct?.items?.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0) || 0;`;
const newTotalFee = `const totalFee = struct?.items?.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0) || 2200;`;

content = content.replace(oldTotalFee, newTotalFee);
fs.writeFileSync('server.ts', content);
console.log("Patched server.ts with default totalFee 2200");
