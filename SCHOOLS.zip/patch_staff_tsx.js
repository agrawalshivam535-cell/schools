import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Staff.tsx', 'utf-8');

code = code.replace(/const mockStaff[\s\S]*?\];/m, '');
code = code.replace(
  "const [staffList, setStaffList] = useState<StaffMember[]>(mockStaff);",
  `const [staffList, setStaffList] = useState<StaffMember[]>([]);
  
  import { useEffect } from 'react';

  const fetchStaff = async () => {
    try {
      const res = await fetch('/api/staff');
      if (res.ok) {
        const data = await res.json();
        setStaffList(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);
  `
);

// fix the import
code = code.replace("import { useState } from 'react';", "import { useState } from 'react';");
// Wait, we added `import { useEffect } from 'react';` inline, that's better placed at top, but tsx will allow it if at top level or we just merge it.
code = code.replace("import { useState } from 'react';", "import { useState, useEffect } from 'react';");
code = code.replace("  import { useEffect } from 'react';", "");

// patch handleSaveStaff
code = code.replace(
  "const handleSaveStaff = (e: import(\"react\").FormEvent) => {",
  `const handleSaveStaff = async (e: import("react").FormEvent) => {`
);

code = code.replace(
  `    if (editForm.id && staffList.some(s => s.id === editForm.id)) {
      setStaffList(staffList.map(s => s.id === editForm.id ? editForm as StaffMember : s));
    } else {
      const newId = editForm.id || 'S' + Math.floor(Math.random() * 1000 + 100);
      setStaffList([...staffList, { ...editForm, id: newId } as StaffMember]);
    }
    setEditForm(null);`,
  `    const isEdit = editForm.id && staffList.some(s => s.id === editForm.id);
    const method = isEdit ? 'PUT' : 'POST';
    const url = isEdit ? '/api/staff/' + editForm.id : '/api/staff';
    
    const payload = { ...editForm };
    if (!isEdit && !payload.id) {
       payload.id = 'S' + Math.floor(Math.random() * 1000 + 100);
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        fetchStaff();
        setEditForm(null);
      }
    } catch (e) {
      console.error(e);
    }`
);

// patch confirmDelete
code = code.replace(
  `const confirmDelete = () => {
    if (deleteConfirmId) {
      setStaffList(staffList.filter(s => s.id !== deleteConfirmId));
      setDeleteConfirmId(null);
    }
  };`,
  `const confirmDelete = async () => {
    if (deleteConfirmId) {
      try {
        const res = await fetch('/api/staff/' + deleteConfirmId, { method: 'DELETE' });
        if (res.ok) {
          fetchStaff();
          setDeleteConfirmId(null);
        }
      } catch (e) {
        console.error(e);
      }
    }
  };`
);

fs.writeFileSync('src/components/tabs/Staff.tsx', code);
console.log('Staff.tsx patched');
