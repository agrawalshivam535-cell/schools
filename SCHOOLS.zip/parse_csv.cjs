const fs = require('fs');

const csv = `Atudent ID,Student Name,Roll Number,Class,Section,Gender,Date of Birth,Blood Group,Father's Name,Mother's Name,Contact Number,Email Address,Address,City,State,PIN Code,Admission Date
STU-01A-001,Vivaan Bansal,1,Class 1,A,Male,12-03-2020,AB+,Rudra Bansal,Kavya Bansal,+91-8001338908,vivaan.bansal1A01@yahoo.com,"House No. 45, Vivekanand Puram",Bengaluru,Karnataka,560001,14-04-2018
STU-01A-002,Tanish Rastogi,2,Class 1,A,Male,22-03-2020,A+,Shaurya Rastogi,Aanya Rastogi,+91-7351161559,tanish.rastogi1A02@outlook.com,"House No. 175, Civil Lines",Surat,Gujarat,395001,29-06-2018
STU-01A-003,Ridhi Nair,3,Class 1,A,Female,09-10-2020,O+,Harsh Nair,Anika Nair,+91-8931034131,ridhi.nair1A03@rediffmail.com,"House No. 454, Patel Nagar",Chennai,Tamil Nadu,600001,08-05-2018
STU-01A-004,Disha Mehta,4,Class 1,A,Female,17-04-2020,O-,Aman Mehta,Charvi Mehta,+91-9192832764,disha.mehta1A04@yahoo.com,"House No. 360, Ram Bagh",Patna,Bihar,800001,25-06-2018
STU-01A-005,Karan Gupta,5,Class 1,A,Male,17-05-2020,AB+,Nikhil Gupta,Gauri Gupta,+91-9537672423,karan.gupta1A05@outlook.com,"House No. 468, Vivekanand Puram",Bhopal,Madhya Pradesh,462001,09-04-2018
STU-01A-006,Disha Mishra,6,Class 1,A,Female,09-09-2020,A+,Ishaan Mishra,Ojasvi Mishra,+91-7269166978,disha.mishra1A06@outlook.com,"House No. 441, Nehru Road",Kanpur,Uttar Pradesh,208001,12-04-2018
STU-01A-007,Samar Bansal,7,Class 1,A,Male,30-05-2020,O-,Raj Bansal,Riya Bansal,+91-9482814893,samar.bansal1A07@yahoo.com,"House No. 233, Gandhi Marg",Jaipur,Rajasthan,302001,26-05-2018
STU-01A-008,Samar Banerjee,8,Class 1,A,Male,14-06-2020,B+,Aarav Banerjee,Vidhi Banerjee,+91-8430391171,samar.banerjee1A08@yahoo.com,"House No. 58, Ram Bagh",Lucknow,Uttar Pradesh,226001,02-06-2018
STU-01A-009,Simran Mehta,9,Class 1,A,Female,06-11-2020,A-,Aryan Mehta,Pihu Mehta,+91-9346578713,simran.mehta1A09@yahoo.com,"House No. 476, Rajendra Nagar",Bhopal,Madhya Pradesh,462001,25-05-2018
STU-01A-010,Diya Rastogi,10,Class 1,A,Female,28-10-2020,B-,Veer Rastogi,Kavya Rastogi,+91-9031051834,diya.rastogi1A10@rediffmail.com,"House No. 37, Tagore Colony",Lucknow,Uttar Pradesh,226001,29-04-2018
STU-01A-011,Yuvraj Sinha,11,Class 1,A,Male,30-08-2020,A-,Laksh Sinha,Meera Sinha,+91-9656670106,yuvraj.sinha1A11@outlook.com,"House No. 49, Nehru Road",Bhopal,Madhya Pradesh,462001,23-05-2018
STU-01A-012,Dev Chauhan,12,Class 1,A,Male,12-03-2020,AB+,Samar Chauhan,Khushi Chauhan,+91-7178108013,dev.chauhan1A12@yahoo.com,"House No. 143, Ashok Vihar",Jaipur,Rajasthan,302001,25-05-2018
STU-01A-013,Manya Yadav,13,Class 1,A,Female,25-03-2020,O-,Om Yadav,Myra Yadav,+91-8468723430,manya.yadav1A13@gmail.com,"House No. 200, Civil Lines",Lucknow,Uttar Pradesh,226001,19-05-2018
STU-01A-014,Vihaan Rastogi,14,Class 1,A,Male,28-09-2020,A-,Laksh Rastogi,Ojasvi Rastogi,+91-7219136193,vihaan.rastogi1A14@gmail.com,"House No. 492, Rajendra Nagar",Kanpur,Uttar Pradesh,208001,21-04-2018
STU-01A-015,Urvi Sinha,15,Class 1,A,Female,13-05-2020,A-,Rehan Sinha,Ananya Sinha,+91-8247510799,urvi.sinha1A15@gmail.com,"House No. 123, Civil Lines",Pune,Maharashtra,411001,27-04-2018
STU-01A-016,Parth Agarwal,16,Class 1,A,Male,05-02-2020,A-,Ishaan Agarwal,Charvi Agarwal,+91-8849808412,parth.agarwal1A16@outlook.com,"House No. 146, MG Road",Nagpur,Maharashtra,440001,02-05-2018
STU-01A-017,Veer Rao,17,Class 1,A,Male,05-11-2020,O-,Shaurya Rao,Vanya Rao,+91-9487401640,veer.rao1A17@gmail.com,"House No. 105, Subhash Nagar",Pune,Maharashtra,411001,27-04-2018
STU-01A-018,Aryan Mehta,18,Class 1,A,Male,27-12-2020,O+,Tanish Mehta,Simran Mehta,+91-7280598262,aryan.mehta1A18@gmail.com,"House No. 5, Nehru Road",Bengaluru,Karnataka,560001,25-05-2018
STU-01A-019,Ira Srivastava,19,Class 1,A,Female,07-12-2020,B-,Yash Srivastava,Meera Srivastava,+91-8923226025,ira.srivastava1A19@rediffmail.com,"House No. 400, Rajendra Nagar",Nagpur,Maharashtra,440001,14-04-2018
STU-01A-020,Pari Reddy,20,Class 1,A,Female,28-08-2020,O+,Harsh Reddy,Ira Reddy,+91-8543303654,pari.reddy1A20@gmail.com,"House No. 419, Ram Bagh",Bhopal,Madhya Pradesh,462001,29-04-2018
STU-01A-021,Ojasvi Trivedi,21,Class 1,A,Female,15-01-2020,AB+,Samar Trivedi,Bhavya Trivedi,+91-8019655698,ojasvi.trivedi1A21@gmail.com,"House No. 92, Vivekanand Puram",Patna,Bihar,800001,15-04-2018
STU-01A-022,Aryan Gupta,22,Class 1,A,Male,23-09-2020,O+,Siddharth Gupta,Aanya Gupta,+91-7595148465,aryan.gupta1A22@rediffmail.com,"House No. 187, Shastri Nagar",Bhopal,Madhya Pradesh,462001,08-06-2018
STU-01A-023,Dev Bhatt,23,Class 1,A,Male,11-11-2020,B-,Harsh Bhatt,Saanvi Bhatt,+91-7443699577,dev.bhatt1A23@rediffmail.com,"House No. 208, Rajendra Nagar",Ranchi,Jharkhand,834001,12-06-2018
STU-01A-024,Pari Patel,24,Class 1,A,Female,05-12-2020,AB-,Atharv Patel,Ojasvi Patel,+91-7433200379,pari.patel1A24@gmail.com,"House No. 172, Nehru Road",Chennai,Tamil Nadu,600001,21-06-2018
STU-01A-025,Trisha Chauhan,25,Class 1,A,Female,23-07-2020,AB-,Harsh Chauhan,Nitya Chauhan,+91-7163287083,trisha.chauhan1A25@gmail.com,"House No. 336, Tagore Colony",Delhi,Delhi,110001,02-05-2018
STU-01A-026,Ansh Banerjee,26,Class 1,A,Male,11-06-2020,B-,Veer Banerjee,Vidhi Banerjee,+91-9687277434,ansh.banerjee1A26@rediffmail.com,"House No. 418, Tagore Colony",Chennai,Tamil Nadu,600001,27-05-2018
STU-01A-027,Khushi Kumar,27,Class 1,A,Female,19-05-2020,AB-,Atharv Kumar,Meera Kumar,+91-7223623166,khushi.kumar1A27@outlook.com,"House No. 458, Rajendra Nagar",Pune,Maharashtra,411001,13-05-2018
STU-01A-028,Myra Yadav,28,Class 1,A,Female,26-10-2020,AB-,Pranav Yadav,Esha Yadav,+91-9670546688,myra.yadav1A28@yahoo.com,"House No. 439, Ram Bagh",Lucknow,Uttar Pradesh,226001,29-06-2018
STU-01A-029,Shaurya Desai,29,Class 1,A,Male,18-07-2020,B+,Naman Desai,Diya Desai,+91-8298069901,shaurya.desai1A29@rediffmail.com,"House No. 371, MG Road",Ahmedabad,Gujarat,380001,14-05-2018
STU-01A-030,Saanvi Singh,30,Class 1,A,Female,16-06-2020,A-,Aryan Singh,Esha Singh,+91-8464170805,saanvi.singh1A30@yahoo.com,"House No. 168, Model Town",Chandigarh,Chandigarh,160001,28-04-2018
STU-01A-031,Vivaan Tiwari,31,Class 1,A,Male,14-11-2020,B+,Dev Tiwari,Diya Tiwari,+91-9193745299,vivaan.tiwari1A31@gmail.com,"House No. 65, Ashok Vihar",Indore,Madhya Pradesh,452001,20-04-2018
STU-01A-032,Navya Rastogi,32,Class 1,A,Female,21-10-2020,AB+,Vivaan Rastogi,Zara Rastogi,+91-7193149190,navya.rastogi1A32@outlook.com,"House No. 204, Tagore Colony",Ahmedabad,Gujarat,380001,26-06-2018
STU-01A-033,Sara Ghosh,33,Class 1,A,Female,03-08-2020,AB+,Raj Ghosh,Aanya Ghosh,+91-9726284987,sara.ghosh1A33@rediffmail.com,"House No. 222, Model Town",Varanasi,Uttar Pradesh,221001,02-06-2018
STU-01A-034,Ananya Tiwari,34,Class 1,A,Female,18-08-2020,O-,Sai Tiwari,Tara Tiwari,+91-9650752735,ananya.tiwari1A34@outlook.com,"House No. 292, Vivekanand Puram",Chandigarh,Chandigarh,160001,02-05-2018
STU-01A-035,Vidhi Bansal,35,Class 1,A,Female,21-09-2020,AB+,Veer Bansal,Aanya Bansal,+91-8783777014,vidhi.bansal1A35@yahoo.com,"House No. 124, Tagore Colony",Agra,Uttar Pradesh,282001,25-04-2018
STU-01A-036,Dhruv Rastogi,36,Class 1,A,Male,10-10-2020,A-,Aman Rastogi,Manya Rastogi,+91-9557444313,dhruv.rastogi1A36@outlook.com,"House No. 218, Tagore Colony",Nagpur,Maharashtra,440001,07-06-2018
STU-01A-037,Dev Yadav,37,Class 1,A,Male,28-10-2020,A+,Laksh Yadav,Tara Yadav,+91-7435240824,dev.yadav1A37@gmail.com,"House No. 145, Nehru Road",Chennai,Tamil Nadu,600001,07-06-2018
STU-01A-038,Kiara Das,38,Class 1,A,Female,20-10-2020,B+,Reyansh Das,Aanya Das,+91-8204711671,kiara.das1A38@gmail.com,"House No. 246, Ashok Vihar",Dehradun,Uttarakhand,248001,07-05-2018
STU-01A-039,Yuvraj Kapoor,39,Class 1,A,Male,01-03-2020,A-,Sai Kapoor,Meera Kapoor,+91-9386774964,yuvraj.kapoor1A39@gmail.com,"House No. 311, Vivekanand Puram",Surat,Gujarat,395001,11-06-2018
STU-01A-040,Yash Agarwal,40,Class 1,A,Male,02-05-2020,A-,Sai Agarwal,Pari Agarwal,+91-7679740344,yash.agarwal1A40@rediffmail.com,"House No. 39, MG Road",Bengaluru,Karnataka,560001,23-04-2018
STU-01A-041,Aryan Rastogi,41,Class 1,A,Male,28-02-2020,AB-,Dev Rastogi,Jhanvi Rastogi,+91-8210249947,aryan.rastogi1A41@gmail.com,"House No. 332, MG Road",Indore,Madhya Pradesh,452001,09-06-2018
STU-01A-042,Gauri Bansal,42,Class 1,A,Female,09-09-2020,A+,Parth Bansal,Ridhi Bansal,+91-8594013990,gauri.bansal1A42@outlook.com,"House No. 307, Gandhi Marg",Agra,Uttar Pradesh,282001,27-05-2018
STU-01A-043,Laksh Banerjee,43,Class 1,A,Male,02-04-2020,AB-,Tanish Banerjee,Tara Banerjee,+91-8175655125,laksh.banerjee1A43@rediffmail.com,"House No. 326, Patel Nagar",Surat,Gujarat,395001,14-06-2018
STU-01A-044,Gauri Mukherjee,44,Class 1,A,Female,15-02-2020,AB-,Aditya Mukherjee,Lavanya Mukherjee,+91-8808760385,gauri.mukherjee1A44@rediffmail.com,"House No. 166, Nehru Road",Patna,Bihar,800001,11-05-2018
STU-01A-045,Yash Bansal,45,Class 1,A,Male,27-05-2020,A-,Veer Bansal,Kiara Bansal,+91-9932480861,yash.bansal1A45@yahoo.com,"House No. 63, Gandhi Marg",Dehradun,Uttarakhand,248001,27-05-2018
STU-01A-046,Riya Rao,46,Class 1,A,Female,17-09-2020,A-,Naman Rao,Vanya Rao,+91-8737826398,riya.rao1A46@yahoo.com,"House No. 213, Patel Nagar",Patna,Bihar,800001,30-06-2018
STU-01A-047,Hiya Saxena,47,Class 1,A,Female,02-01-2020,AB-,Parth Saxena,Tara Saxena,+91-9727875588,hiya.saxena1A47@rediffmail.com,"House No. 429, Vivekanand Puram",Ranchi,Jharkhand,834001,07-05-2018
STU-01A-048,Anaya Tiwari,48,Class 1,A,Female,29-04-2020,AB-,Yuvraj Tiwari,Esha Tiwari,+91-8662702895,anaya.tiwari1A48@gmail.com,"House No. 163, Tagore Colony",Kanpur,Uttar Pradesh,208001,23-05-2018
STU-01A-049,Rehan Jain,49,Class 1,A,Male,28-07-2020,A-,Aarav Jain,Aditi Jain,+91-8596158657,rehan.jain1A49@gmail.com,"House No. 39, Ashok Vihar",Delhi,Delhi,110001,23-06-2018
STU-01A-050,Atharv Mishra,50,Class 1,A,Male,20-02-2020,B-,Sai Mishra,Jhanvi Mishra,+91-9400504556,atharv.mishra1A50@yahoo.com,"House No. 228, MG Road",Varanasi,Uttar Pradesh,221001,21-06-2018`;

const lines = csv.trim().split('\n');
const headers = lines[0].split(',');
const students = [];

// A simple CSV parser to handle quotes
function parseCsvLine(text) {
  let ret = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    let char = text[i];
    if (inQuotes) {
      if (char === '"') {
        if (i + 1 < text.length && text[i + 1] === '"') {
          current += '"';
          i++; // Skip the second quote
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        ret.push(current);
        current = '';
      } else {
        current += char;
      }
    }
  }
  ret.push(current);
  return ret;
}

for (let i = 1; i < lines.length; i++) {
  const values = parseCsvLine(lines[i]);
  const student = {
    "Atudent ID": values[0],
    "id": values[0], // using Student ID as the primary id
    "name": values[1],
    "rollNumber": values[2],
    "className": values[3] + " - " + values[4],
    "section": values[4],
    "gender": values[5],
    "dob": values[6],
    "bloodGroup": values[7],
    "fatherName": values[8],
    "motherName": values[9],
    "parentPhone": values[10],
    "email": values[11],
    "address": values[12],
    "city": values[13],
    "state": values[14],
    "pinCode": values[15],
    "admissionDate": values[16],
    "status": "Active Student"
  };
  students.push(student);
}

fs.writeFileSync('students.json', JSON.stringify(students, null, 2));
console.log('Successfully saved to students.json');
