const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const rxRender = /  const renderDetailView = \(\) => \{/m;

const replacementRender = `  const sendTelegramResult = async (exam: any, student: any) => {
    let message = \`*Academic Report - \${student.name}*\\nRoll No: \${student.rollNumber}\\nClass: \${student.className} \${student.section ? '- ' + student.section : ''}\\n\\n\`;
    message += \`*\${exam.examName}*\\n\`;
    exam.subjects.forEach((subj: any) => {
      message += \`\${subj.name}: \${subj.obtained}\\n\`;
    });
    message += \`Total: \${exam.obtained}/\${exam.total}\\n\\n\`;
    
    const phone = student.parentPhone || '';
    const cleanPhone = phone.replace(/[^0-9+]/g, '');
    const defaultChatId = student.telegramChatId || cleanPhone;
    
    const doc = buildSinglePDF(exam, student);
    const pdfBase64 = doc.output('datauristring').split(',')[1];
    
    setTelegramModal({
      isOpen: true,
      studentName: student.name,
      message,
      chatId: defaultChatId,
      pdfBase64,
      isSending: false
    });
  };

  const confirmSendTelegram = async () => {
    if (!telegramModal || !telegramModal.chatId) return;
    setTelegramModal({ ...telegramModal, isSending: true });

    try {
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: telegramModal.chatId,
          message: telegramModal.message,
          pdfBase64: telegramModal.pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        setTelegramModal(null);
      } else {
        alert(\`Failed to send message: \${data.message}\`);
        setTelegramModal({ ...telegramModal, isSending: false });
      }
    } catch (err) {
      alert('An error occurred while sending the message.');
      setTelegramModal({ ...telegramModal, isSending: false });
    }
  };

  const renderDetailView = () => {`;

if(rxRender.test(content)) {
  content = content.replace(rxRender, replacementRender);
  fs.writeFileSync('src/components/tabs/Students.tsx', content);
  console.log("Patched renderDetailView logic successfully!");
} else {
  console.log("Regex did not match renderDetailView.");
}

const rxTable = /                              <button \n                                onClick=\{\(\) => downloadMarksResult\(exam, selectedStudent\.student, 'preview'\)\}\n                                className="p-1\.5 hover:bg-white\/10 text-gray-400 hover:text-white rounded-lg transition-colors"\n                                title="Preview PDF"\n                              >\n                                <Eye size=\{18\} \/>\n                              <\/button>\n                              <button \n                                onClick=\{\(\) => downloadMarksResult\(exam, selectedStudent\.student\)\}/m;

const replacementTable = `                              <button 
                                onClick={() => downloadMarksResult(exam, selectedStudent.student, 'preview')}
                                className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                                title="Preview PDF"
                              >
                                <Eye size={18} />
                              </button>
                              <button 
                                onClick={() => sendTelegramResult(exam, selectedStudent.student)}
                                className="p-1.5 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors"
                                title="Send via Telegram"
                              >
                                <Send size={18} />
                              </button>
                              <button 
                                onClick={() => downloadMarksResult(exam, selectedStudent.student)}`;

if(rxTable.test(content)) {
  content = content.replace(rxTable, replacementTable);
  fs.writeFileSync('src/components/tabs/Students.tsx', content);
  console.log("Patched buttons logic successfully!");
} else {
  console.log("Regex did not match buttons.");
}

const rxReturn = /    <\/div>\n  \);\n\}/m;

const replacementReturn = `      {/* Telegram Modal */}
      {telegramModal && telegramModal.isOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-6 border-b border-white/5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Send className="w-5 h-5 text-[#229ED9]" /> Send via Telegram
              </h2>
              <button 
                onClick={() => setTelegramModal(null)}
                className="text-gray-400 hover:text-white transition-colors"
                disabled={telegramModal.isSending}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">
                  Telegram Chat ID / Phone
                </label>
                <input
                  type="text"
                  value={telegramModal.chatId}
                  onChange={(e) => setTelegramModal({ ...telegramModal, chatId: e.target.value })}
                  placeholder="e.g. 123456789 or +919876543210"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-[#229ED9] focus:ring-1 focus:ring-[#229ED9] transition-all"
                  disabled={telegramModal.isSending}
                />
                <p className="text-xs text-gray-500 mt-2">
                  To send via Bot API, the recipient must have started a conversation with your bot.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">
                  Message Preview
                </label>
                <div className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-400 max-h-48 overflow-y-auto whitespace-pre-wrap">
                  {telegramModal.message}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-white/5 flex justify-end gap-3 bg-white/[0.02]">
              <button
                onClick={() => setTelegramModal(null)}
                className="px-5 py-2.5 rounded-xl text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-all"
                disabled={telegramModal.isSending}
              >
                Cancel
              </button>
              <button
                onClick={confirmSendTelegram}
                disabled={!telegramModal.chatId || telegramModal.isSending}
                className="px-5 py-2.5 rounded-xl text-sm font-medium bg-[#229ED9] hover:bg-[#1CA0DE] text-white disabled:opacity-50 disabled:hover:bg-[#229ED9] transition-all flex items-center gap-2"
              >
                {telegramModal.isSending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" /> Send Message
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}`;

if(rxReturn.test(content)) {
  content = content.replace(rxReturn, replacementReturn);
  fs.writeFileSync('src/components/tabs/Students.tsx', content);
  console.log("Patched return logic successfully!");
} else {
  console.log("Regex did not match return.");
}
