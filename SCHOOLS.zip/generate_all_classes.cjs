const fs = require('fs');

const firstNamesMale = ["Vivaan", "Ishaan", "Vedant", "Sai", "Tanish", "Raj", "Gaurav", "Eshan", "Jatin", "Reyansh", "Sahil", "Chirag", "Ayaan", "Uday", "Abhinav", "Pranav", "Shaurya", "Yash", "Darsh", "Daksh", "Nikhil", "Vikram", "Advik", "Harshit", "Manav", "Siddharth", "Krishna", "Raj", "Arjun", "Zaid", "Atharv", "Akshat", "Om", "Rishabh", "Rudra", "Varun", "Kabir", "Parth", "Dev", "Devansh"];
const firstNamesFemale = ["Esha", "Ananya", "Meera", "Ira", "Kashvi", "Navya", "Ovi", "Pihu", "Radha", "Tara", "Simran", "Ojaswi", "Pari", "Falak", "Vidhi", "Tanvi", "Bhoomi", "Kavya", "Myra", "Disha", "Urvi", "Diya", "Manya", "Gauri", "Charvi", "Rhea", "Riya", "Bhavya", "Kiara", "Jiya", "Anika", "Hiya", "Juhi", "Ekta", "Isha", "Avni", "Sara", "Lavanya", "Pooja", "Gunjan", "Chhavi", "Devika", "Lakshmi"];
const lastNames = ["Reddy", "Mishra", "Tripathi", "Tiwari", "Bansal", "Jain", "Rathi", "Malhotra", "Rao", "Patel", "Yadav", "Ghosh", "Singh", "Nair", "Bhatt", "Khanna", "Saxena", "Kapoor", "Gupta", "Banerjee", "Dubey", "Kumar", "Sharma", "Pillai", "Iyer", "Verma", "Desai", "Menon", "Shah", "Mehta", "Chatterjee", "Trivedi", "Naidu", "Mukherjee", "Pandey", "Chauhan", "Agarwal"];
const cities = ["Mumbai", "Delhi", "Bengaluru", "Chennai", "Kolkata", "Hyderabad", "Pune", "Ahmedabad", "Jaipur", "Lucknow", "Surat", "Kanpur", "Nagpur", "Patna", "Indore"];
const states = ["Maharashtra", "Delhi", "Karnataka", "Tamil Nadu", "West Bengal", "Telangana", "Maharashtra", "Gujarat", "Rajasthan", "Uttar Pradesh", "Gujarat", "Uttar Pradesh", "Maharashtra", "Bihar", "Madhya Pradesh"];
const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

function getRandomDate(start, end) {
    const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
}

let students = [];

for (let c = 1; c <= 8; c++) {
  for (let s of ['A', 'B', 'C', 'D']) {
    let numStudents = 50; 
    for (let r = 1; r <= numStudents; r++) {
      let isMale = Math.random() > 0.5;
      let fName = isMale ? firstNamesMale[Math.floor(Math.random() * firstNamesMale.length)] : firstNamesFemale[Math.floor(Math.random() * firstNamesFemale.length)];
      let lName = lastNames[Math.floor(Math.random() * lastNames.length)];
      let name = `${fName} ${lName}`;
      
      let parentPhone = "+91-" + Math.floor(Math.random() * 900000000 + 700000000).toString();
      
      let fatherFName = firstNamesMale[Math.floor(Math.random() * firstNamesMale.length)];
      let motherFName = firstNamesFemale[Math.floor(Math.random() * firstNamesFemale.length)];
      
      let locIndex = Math.floor(Math.random() * cities.length);
      let city = cities[locIndex];
      let state = states[locIndex];
      let pinCode = String(Math.floor(Math.random() * 800000 + 100000));
      let address = `House No. ${Math.floor(Math.random() * 500) + 1}, ${city} Nagar`;
      
      // Calculate realistic DOB based on class
      let ageBase = 5 + c; // Class 1 -> 6 years, Class 2 -> 7 years...
      let startYear = 2026 - ageBase - 1; // Assuming current year is 2026
      let endYear = 2026 - ageBase;
      let dob = getRandomDate(new Date(startYear, 0, 1), new Date(endYear, 11, 31));
      let admissionDate = getRandomDate(new Date(2018, 2, 1), new Date(2022, 5, 30));
      
      // Formatting STU ID like STU-01A-001
      let classFormatted = String(c).padStart(2, '0');
      let rollFormatted = String(r).padStart(3, '0');
      let stuId = `STU-${classFormatted}${s}-${rollFormatted}`;

      students.push({
        "Atudent ID": stuId,
        id: stuId,
        name: name,
        rollNumber: String(r),
        className: `Class ${c} - ${s}`,
        section: s,
        gender: isMale ? "Male" : "Female",
        dob: dob,
        bloodGroup: bloodGroups[Math.floor(Math.random() * bloodGroups.length)],
        fatherName: `${fatherFName} ${lName}`,
        motherName: `${motherFName} ${lName}`,
        parentPhone: parentPhone,
        email: `${fName.toLowerCase()}.${lName.toLowerCase()}${c}${s}${rollFormatted}@gmail.com`,
        address: address,
        city: city,
        state: state,
        pinCode: pinCode,
        admissionDate: admissionDate,
        status: "Active Student"
      });
    }
  }
}

// Preserve existing real data for Class 1A from original prompt if possible
// To do that, we overwrite first 50 with the original uploaded ones
let existing = [];
try {
  existing = JSON.parse(fs.readFileSync('students.json', 'utf8'));
} catch (e) {}

if (existing.length > 0) {
    let existingIds = new Set(existing.map(e => e.id));
    students = students.filter(s => !existingIds.has(s.id));
    students = existing.concat(students);
}

fs.writeFileSync('students.json', JSON.stringify(students, null, 2));
console.log(`Generated and updated ${students.length} students in total.`);
