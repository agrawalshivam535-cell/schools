import fs from 'fs';
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  "title={activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}",
  "title={activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}\n          onLogout={() => setUser(null)}"
);

fs.writeFileSync('src/App.tsx', code);
