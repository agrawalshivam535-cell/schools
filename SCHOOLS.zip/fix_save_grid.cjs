const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const rx = /app\.post\("\/api\/exams\/save-grid", \(req, res\) => \{\s*const \{ examName, className, section, students \} = req\.body;\s*\/\/ Create analysis records for each subject based on the grid data\s*const subjects = \["Maths", "Science", "Hindi"\];\s*subjects\.forEach\(subject => \{\s*const records = students\.map\(\(s: any\) => \(\{\s*id: s\.id,\s*name: s\.name,\s*totalMarks: "100", \/\/ Defaulting to 100 for the grid\s*marksObtained: s\[subject\.toLowerCase\(\)\] \|\| "0"\s*\}\)\);/m;

const replacement = `app.post("/api/exams/save-grid", (req, res) => {
    const { examName, className, section, students, maxMarks } = req.body;
    
    // Create analysis records for each subject based on the grid data
    const subjects = ["Maths", "Science", "Hindi"];
    
    subjects.forEach(subject => {
      const records = students.map((s: any) => ({
        id: s.id,
        name: s.name,
        totalMarks: String(maxMarks || 100),
        marksObtained: s[subject.toLowerCase()] || "0"
      }));`;

content = content.replace(rx, replacement);
fs.writeFileSync('server.ts', content);
console.log('Fixed /api/exams/save-grid');
