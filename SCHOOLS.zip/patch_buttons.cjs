const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

// 1. Add History to imports
content = content.replace(
  `import { UploadCloud, CheckCircle2, Loader2, Edit2, Check, LayoutGrid, RefreshCw } from 'lucide-react';`,
  `import { UploadCloud, CheckCircle2, Loader2, Edit2, Check, LayoutGrid, RefreshCw, History } from 'lucide-react';`
);

// 2. Modify handleMarkChange
const oldHandleMarkChangeEnd = `    const newData = [...analyzedData];
    const index = newData.findIndex(r => r.id === id);
    if (index !== -1) {
      newData[index].marksObtained = value;
      setAnalyzedData(newData);
    }`;
const newHandleMarkChangeEnd = `    const newData = [...analyzedData];
    const index = newData.findIndex(r => r.id === id);
    if (index !== -1) {
      newData[index].marksObtained = value;
      if (newData[index].previousMarks !== undefined) {
        newData[index].resolvedMismatch = true;
      }
      setAnalyzedData(newData);
    }`;
content = content.replace(oldHandleMarkChangeEnd, newHandleMarkChangeEnd);

// 3. Update Bulk Buttons
const oldBulkKeepOld = `<button onClick={() => handleKeepOld()} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-lg transition-colors border border-white/10">Keep All Old</button>`;
const newBulkKeepOld = `<button onClick={() => handleKeepOld()} className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-lg transition-colors border border-white/10"><History size={16} /> Keep All Old</button>`;
content = content.replace(oldBulkKeepOld, newBulkKeepOld);

const oldBulkKeepNew = `<button onClick={() => handleKeepNew()} className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-lg">Keep All New</button>`;
const newBulkKeepNew = `<button onClick={() => handleKeepNew()} className="flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-lg"><Check size={16} /> Keep All New</button>`;
content = content.replace(oldBulkKeepNew, newBulkKeepNew);

// 4. Update Row Buttons
const oldRowKeepOld = `<button onClick={() => handleKeepOld(row.id)} className="text-[10px] bg-white/10 hover:bg-white/20 text-white px-1.5 py-0.5 rounded transition-colors whitespace-nowrap">Keep Old</button>`;
const newRowKeepOld = `<button onClick={() => handleKeepOld(row.id)} className="text-[10px] bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded transition-colors whitespace-nowrap flex items-center justify-center gap-1 w-full"><History size={12} /> Old</button>`;
content = content.replace(oldRowKeepOld, newRowKeepOld);

const oldRowKeepNew = `<button onClick={() => handleKeepNew(row.id)} className="text-[10px] bg-amber-600/50 hover:bg-amber-600 text-white px-1.5 py-0.5 rounded transition-colors whitespace-nowrap">Keep New</button>`;
const newRowKeepNew = `<button onClick={() => handleKeepNew(row.id)} className="text-[10px] bg-amber-600 hover:bg-amber-700 text-white px-2 py-1 rounded transition-colors whitespace-nowrap flex items-center justify-center gap-1 w-full"><Check size={12} /> New</button>`;
content = content.replace(oldRowKeepNew, newRowKeepNew);

// Make the layout for row buttons slightly better (stack them or space them evenly)
const oldFlexGap1 = `<div className="flex gap-1">`;
const newFlexGap1 = `<div className="flex flex-col gap-1 w-full mt-1">`;
content = content.replace(oldFlexGap1, newFlexGap1);

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log("Patched successfully");
