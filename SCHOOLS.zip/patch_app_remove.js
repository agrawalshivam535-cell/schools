import fs from 'fs';
let code = fs.readFileSync('src/App.tsx', 'utf-8');
code = code.replace("import { AppScriptUpload } from './components/tabs/AppScriptUpload';\n", "");
code = code.replace("      case 'upload': return <AppScriptUpload />;\n", "");
fs.writeFileSync('src/App.tsx', code);
