import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Mock Database
import fs from "fs";
let students: any[] = [];
try {
  students = JSON.parse(fs.readFileSync('./students.json', 'utf-8'));
} catch (e) {
  console.error("Could not load students.json", e);
}


let classes: any[] = [];
try {
  classes = JSON.parse(fs.readFileSync('./classes.json', 'utf-8'));
} catch (e) {
  console.error("Could not load classes.json", e);
}


let staff: any[] = [];
try {
  staff = JSON.parse(fs.readFileSync('./staff.json', 'utf-8'));
} catch (e) {
  console.error("Could not load staff.json", e);
}


let attendanceRecords: any[] = [];
try { attendanceRecords = JSON.parse(fs.readFileSync('./attendance.json', 'utf-8')); } catch(e) {}
let analysisRecords: any[] = [];
try { analysisRecords = JSON.parse(fs.readFileSync('./analysis.json', 'utf-8')); } catch(e) {}
let feeStructures: any[] = [];
try { feeStructures = JSON.parse(fs.readFileSync('./feeStructures.json', 'utf-8')); } catch(e) {}
let feePayments: any[] = [];
try { feePayments = JSON.parse(fs.readFileSync('./feePayments.json', 'utf-8')); } catch(e) {}

let telegramMessages: any[] = [];
try { telegramMessages = JSON.parse(fs.readFileSync('./telegramMessages.json', 'utf-8')); } catch(e) {}

interface UserAccount {
  id: string;
  loginId: string;
  name: string;
  email: string;
  password?: string;
  geminiApiKey?: string;
  createdAt: string;
}

let users: UserAccount[] = [];
try {
  users = JSON.parse(fs.readFileSync('./users.json', 'utf-8'));
} catch (e) {
  users = [
    {
      id: 'demo',
      loginId: 'Demo',
      name: 'Demo User',
      email: 'demo@example.com',
      password: 'password',
      geminiApiKey: process.env.GEMINI_API_KEY || '',
      createdAt: new Date().toISOString()
    }
  ];
  saveDb('users.json', users);
}

function maskApiKey(key?: string): string {
  if (!key) return '';
  const trimmed = key.trim();
  if (trimmed.length <= 8) return '••••••••';
  return `${trimmed.substring(0, 6)}••••••••${trimmed.substring(trimmed.length - 4)}`;
}

function getUserGeminiApiKey(loginId?: string, overrideKey?: string): string {
  if (overrideKey && overrideKey.trim()) {
    return overrideKey.trim();
  }
  if (loginId) {
    const cleanId = loginId.trim().toLowerCase();
    const found = users.find(u => u.loginId.toLowerCase() === cleanId || u.id.toLowerCase() === cleanId || u.email.toLowerCase() === cleanId);
    if (found?.geminiApiKey && found.geminiApiKey.trim()) {
      return found.geminiApiKey.trim();
    }
  }
  return process.env.GEMINI_API_KEY || '';
}

function saveDb(filename: string, data: any) {
  try {
    fs.writeFileSync('./' + filename, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Failed to save " + filename, e);
  }
}

function isTransientGeminiError(err: any): boolean {
  if (!err) return false;
  const status = err?.status || err?.error?.status || '';
  const code = err?.code || err?.error?.code || err?.status || '';
  const msg = (err?.message || err?.error?.message || (typeof err === 'string' ? err : JSON.stringify(err)) || '').toLowerCase();

  if (code === 503 || code === '503' || status === 'UNAVAILABLE') return true;
  if (code === 429 || code === '429' || status === 'RESOURCE_EXHAUSTED') return true;
  if (code === 500 || code === '500' || code === 504 || code === '504' || status === 'INTERNAL' || status === 'DEADLINE_EXCEEDED') return true;
  if (
    msg.includes('high demand') ||
    msg.includes('spikes in demand') ||
    msg.includes('temporarily') ||
    msg.includes('unavailable') ||
    msg.includes('overloaded') ||
    msg.includes('try again later') ||
    msg.includes('rate limit') ||
    msg.includes('resource exhausted') ||
    msg.includes('quota') ||
    msg.includes('503') ||
    msg.includes('429') ||
    msg.includes('econnreset') ||
    msg.includes('etimedout')
  ) {
    return true;
  }
  return false;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function generateContentWithRetryAndFallback(
  ai: GoogleGenAI,
  requestContent: any,
  config?: any,
  options?: { maxAttemptsPerModel?: number }
) {
  // Candidate models in prioritized order:
  // 1. gemini-3.8-flash (Primary text & multimodal flash model)
  // 2. gemini-3.1-flash-lite (Ultra-fast, separate lightweight pool, high availability)
  // 3. gemini-2.5-flash (Standard fallback)
  // 4. gemini-flash-latest (Alias fallback)
  const candidateModels = [
    'gemini-3.8-flash',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash',
    'gemini-flash-latest',
  ];

  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      console.log(`[Gemini Request] Invoking model "${model}"...`);
      const response = await ai.models.generateContent({
        model,
        contents: requestContent,
        ...(config ? { config } : {}),
      });

      if (response && response.text) {
        console.log(`[Gemini Request] Succeeded with model "${model}".`);
        return response;
      }
      throw new Error(`Empty response received from model "${model}".`);
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || (typeof err === 'string' ? err : JSON.stringify(err));
      console.log(`[Gemini Request] Model "${model}" failed: ${errMsg}`);

      const isHighDemand =
        err?.status === 503 ||
        err?.status === 'UNAVAILABLE' ||
        err?.code === 503 ||
        errMsg.toLowerCase().includes('high demand') ||
        errMsg.toLowerCase().includes('spikes in demand') ||
        errMsg.toLowerCase().includes('unavailable');

      if (!isHighDemand && isTransientGeminiError(err)) {
        // Quick transient retry for socket/network hiccups (500ms)
        try {
          console.log(`[Gemini Request] Quick transient retry for "${model}"...`);
          await sleep(500);
          const retryRes = await ai.models.generateContent({
            model,
            contents: requestContent,
            ...(config ? { config } : {}),
          });
          if (retryRes && retryRes.text) {
            console.log(`[Gemini Request] Succeeded on retry with "${model}".`);
            return retryRes;
          }
        } catch (retryErr: any) {
          lastError = retryErr;
          console.log(`[Gemini Request] Retry on "${model}" failed.`);
        }
      }

      console.log(`[Gemini Request] Falling back from "${model}" to next candidate model...`);
    }
  }

  // If all candidate models failed
  const errorMsg = lastError?.message || (typeof lastError === 'string' ? lastError : JSON.stringify(lastError)) || 'Unknown error';
  if (isTransientGeminiError(lastError)) {
    throw new Error(
      `Gemini AI service is currently experiencing temporary high demand across models. Please wait a moment and click Retry.`
    );
  }
  throw new Error(`Gemini processing failed: ${errorMsg}`);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Authentication & User Gemini API Key Routes
  app.post("/api/auth/login", (req, res) => {
    const { loginId, email, password } = req.body;
    const queryId = (loginId || email || '').trim();
    if (!queryId) {
      return res.status(400).json({ success: false, message: "Login ID is required" });
    }

    let user = users.find(u => u.loginId.toLowerCase() === queryId.toLowerCase() || u.email.toLowerCase() === queryId.toLowerCase());
    
    // Auto-create Demo user if missing
    if (!user && queryId.toLowerCase() === 'demo') {
      user = {
        id: 'demo',
        loginId: 'Demo',
        name: 'Demo User',
        email: 'demo@example.com',
        password: 'password',
        geminiApiKey: process.env.GEMINI_API_KEY || '',
        createdAt: new Date().toISOString(),
      };
      users.push(user);
      saveDb('users.json', users);
    }

    if (!user) {
      return res.status(401).json({ success: false, message: "Invalid credentials. User not found." });
    }

    const isValidPass = (queryId.toLowerCase() === 'demo' && (password === 'Asdf@1234' || password === 'password')) ||
                         user.password === password;

    if (!isValidPass) {
      return res.status(401).json({ success: false, message: "Invalid password. (Hint: Demo password is 'Asdf@1234')" });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        loginId: user.loginId,
        name: user.name,
        email: user.email,
        hasApiKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
        maskedApiKey: maskApiKey(user.geminiApiKey)
      }
    });
  });

  app.post("/api/login", (req, res) => {
    const { loginId, email, password } = req.body;
    const queryId = (loginId || email || '').trim();
    let user = users.find(u => u.loginId.toLowerCase() === queryId.toLowerCase() || u.email.toLowerCase() === queryId.toLowerCase());
    
    if (queryId.toLowerCase() === 'demo' || (email && password === 'password')) {
      if (!user) {
        user = {
          id: 'demo',
          loginId: 'Demo',
          name: 'Demo User',
          email: email || 'demo@example.com',
          password: 'password',
          geminiApiKey: process.env.GEMINI_API_KEY || '',
          createdAt: new Date().toISOString()
        };
        users.push(user);
        saveDb('users.json', users);
      }
      return res.json({
        success: true,
        name: user.name,
        email: user.email,
        loginId: user.loginId,
        hasKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
        hasApiKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
        maskedApiKey: maskApiKey(user.geminiApiKey),
        user: {
          id: user.id,
          loginId: user.loginId,
          name: user.name,
          email: user.email,
          hasApiKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
          maskedApiKey: maskApiKey(user.geminiApiKey)
        }
      });
    }

    if (user && user.password === password) {
      return res.json({
        success: true,
        name: user.name,
        email: user.email,
        loginId: user.loginId,
        hasKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
        hasApiKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
        maskedApiKey: maskApiKey(user.geminiApiKey),
        user: {
          id: user.id,
          loginId: user.loginId,
          name: user.name,
          email: user.email,
          hasApiKey: !!(user.geminiApiKey && user.geminiApiKey.trim()),
          maskedApiKey: maskApiKey(user.geminiApiKey)
        }
      });
    }

    res.status(401).json({ success: false, message: "Invalid credentials." });
  });

  app.post("/api/auth/register", (req, res) => {
    const { loginId, name, password, geminiApiKey } = req.body;
    if (!loginId || !name || !password) {
      return res.status(400).json({ success: false, message: "Login ID, Name, and Password are required" });
    }

    const cleanId = loginId.trim();
    const existing = users.find(u => u.loginId.toLowerCase() === cleanId.toLowerCase());
    if (existing) {
      return res.status(400).json({ success: false, message: "A user with this Login ID already exists" });
    }

    const newUser: UserAccount = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 4),
      loginId: cleanId,
      name: name.trim(),
      email: req.body.email || `${cleanId}@school.internal`,
      password: password,
      geminiApiKey: geminiApiKey ? geminiApiKey.trim() : '',
      createdAt: new Date().toISOString()
    };
    users.push(newUser);
    saveDb('users.json', users);

    res.json({
      success: true,
      user: {
        id: newUser.id,
        loginId: newUser.loginId,
        name: newUser.name,
        email: newUser.email,
        hasApiKey: !!(newUser.geminiApiKey && newUser.geminiApiKey.trim()),
        maskedApiKey: maskApiKey(newUser.geminiApiKey)
      }
    });
  });

  app.post("/api/user/gemini-key", (req, res) => {
    const { loginId, geminiApiKey } = req.body;
    const qId = (loginId || req.headers['x-user-id'] || '').toString().trim();
    if (!qId) {
      return res.status(400).json({ success: false, message: "Login ID is required" });
    }

    let userIdx = users.findIndex(u => u.loginId.toLowerCase() === qId.toLowerCase() || u.id.toLowerCase() === qId.toLowerCase());
    if (userIdx === -1) {
      const newUser: UserAccount = {
        id: Date.now().toString(),
        loginId: qId,
        name: qId,
        email: `${qId}@school.internal`,
        geminiApiKey: (geminiApiKey || '').trim(),
        createdAt: new Date().toISOString()
      };
      users.push(newUser);
      saveDb('users.json', users);
      return res.json({
        success: true,
        hasApiKey: !!(newUser.geminiApiKey && newUser.geminiApiKey.trim()),
        maskedApiKey: maskApiKey(newUser.geminiApiKey)
      });
    }

    users[userIdx].geminiApiKey = (geminiApiKey || '').trim();
    saveDb('users.json', users);

    res.json({
      success: true,
      hasApiKey: !!(users[userIdx].geminiApiKey && users[userIdx].geminiApiKey.trim()),
      maskedApiKey: maskApiKey(users[userIdx].geminiApiKey)
    });
  });

  app.get("/api/user/key-status", (req, res) => {
    const qId = ((req.query.loginId as string) || (req.headers['x-user-id'] as string) || '').trim();
    const user = users.find(u => u.loginId.toLowerCase() === qId.toLowerCase());
    res.json({
      loginId: qId,
      hasApiKey: !!(user?.geminiApiKey && user.geminiApiKey.trim()),
      maskedApiKey: maskApiKey(user?.geminiApiKey)
    });
  });

  app.post("/api/user/test-gemini-key", async (req, res) => {
    const { geminiApiKey } = req.body;
    if (!geminiApiKey || !geminiApiKey.trim()) {
      return res.status(400).json({ success: false, message: "API key is required" });
    }
    try {
      const ai = new GoogleGenAI({
        apiKey: geminiApiKey.trim(),
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
      });
      const testRes = await generateContentWithRetryAndFallback(
        ai, 
        'Ping', 
        { temperature: 0.1 },
        { maxAttemptsPerModel: 2 }
      );
      if (testRes) {
        return res.json({ success: true, message: "Gemini API key is valid and working!" });
      }
      res.status(400).json({ success: false, message: "Failed to verify key" });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message || "Invalid Gemini API key" });
    }
  });


  app.get("/api/staff", (req, res) => {
    res.json(staff);
  });
  app.post("/api/staff", (req, res) => {
    staff.push(req.body);
    saveDb('staff.json', staff);
    res.json({ success: true, staff });
  });
  app.put("/api/staff/:id", (req, res) => {
    const idx = staff.findIndex(s => s.id === req.params.id);
    if (idx !== -1) {
      staff[idx] = { ...staff[idx], ...req.body };
      saveDb('staff.json', staff);
      res.json({ success: true, staff });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });
  app.delete("/api/staff/:id", (req, res) => {
    staff = staff.filter(s => s.id !== req.params.id);
    saveDb('staff.json', staff);
    res.json({ success: true, staff });
  });

  app.get("/api/dashboard", (req, res) => {
    res.json({
      totalStudents: students.length,
      // compute attendance
      attendancePct: (() => {
        let present = 0;
        let total = 0;
        attendanceRecords.forEach(ar => {
          ar.records.forEach(r => {
            total++;
            if (r.status === 'Present') present++;
          });
        });
        return total === 0 ? "100%" : Math.round((present/total)*100) + "%";
      })(),
      totalStaff: staff.length,
      // compute fees
      feesCollected: "$" + feePayments.reduce((acc, curr) => acc + curr.payments.reduce((a, p) => a + Number(p.amount), 0), 0).toLocaleString(),
      feesPending: "$" + students.reduce((acc, s) => {
         const struct = feeStructures.find(f => f.className === s.className && f.section === s.section);
         const totalFee = struct?.items?.reduce((a, c) => a + Number(c.amount), 0) || 2200;
         const paid = feePayments.find(p => p.id === s.id)?.payments.reduce((a, c) => a + Number(c.amount), 0) || 0;
         return acc + Math.max(0, totalFee - paid);
      }, 0).toLocaleString()
    });
  });


  app.get("/api/classes", (req, res) => {
    // dynamically compute totalStudents
    const result = classes.map(c => {
      const classNameFormatted = c.className + " - " + c.section;
      const totalStudents = students.filter(s => {
         // handle if student has className="Class 1 - A" or className="Class 1", section="A"
         let sClass = s.className;
         let sSec = s.section;
         if (s.className && s.className.includes(" - ")) {
            sClass = s.className.split(" - ")[0];
            sSec = s.className.split(" - ")[1];
         } else {
            sClass = s.className || "Class 1";
            sSec = s.section || "A";
         }
         return sClass === c.className && sSec === c.section;
      }).length;
      return { ...c, totalStudents };
    });
    res.json(result);
  });


  app.post("/api/classes", (req, res) => {
    classes.push(req.body);
    saveDb('classes.json', classes);
    res.json({ success: true, classes });
  });
  app.put("/api/classes/:id", (req, res) => {
    const idx = classes.findIndex(c => c.id === req.params.id);
    if (idx !== -1) {
      classes[idx] = { ...classes[idx], ...req.body };
      saveDb('classes.json', classes);
      res.json({ success: true, class: classes[idx] });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });
  app.delete("/api/classes/:id", (req, res) => {
    classes = classes.filter(c => c.id !== req.params.id);
    saveDb('classes.json', classes);
    res.json({ success: true });
  });

  app.get("/api/students", (req, res) => {
    const { className, section, search } = req.query;
    let filtered = students;
    if (className && className !== 'All Classes') {
      filtered = filtered.filter(s => s.className === className);
    }
    if (section && section !== 'All Sections') {
      filtered = filtered.filter(s => s.section === section);
    }
    if (search) {
      const q = (search as string).toLowerCase();
      filtered = filtered.filter(s => s.name.toLowerCase().includes(q) || s.rollNumber.includes(q));
    }
    res.json(filtered);
  });
  app.get("/api/marks/all", (req, res) => {
    const { className, section } = req.query;
    // We want a map of studentId -> marks array
    const studentMarksMap: Record<string, any> = {};

    let filteredAnalysis = analysisRecords;
    if (className && className !== 'All Classes' && className !== 'All') {
      const cls = (className as string).split(' - ')[0];
      filteredAnalysis = filteredAnalysis.filter(ar => ar.className === cls);
    }
    if (section && section !== 'All Sections') {
      filteredAnalysis = filteredAnalysis.filter(ar => (ar as any).section === section);
    }

    filteredAnalysis.forEach(ar => {
      (ar as any).records.forEach((rec: any) => {
        const sid = rec.id;
        if (!studentMarksMap[sid]) {
          studentMarksMap[sid] = {};
        }
        const examType = (ar as any).examType;
        if (!studentMarksMap[sid][examType]) {
          studentMarksMap[sid][examType] = { examName: examType, total: 0, obtained: 0, subjects: [] };
        }
        studentMarksMap[sid][examType].subjects.push({ name: (ar as any).subject, obtained: rec.marksObtained });
        studentMarksMap[sid][examType].total += Number(rec.totalMarks) || 0;
        studentMarksMap[sid][examType].obtained += Number(rec.marksObtained) || 0;
      });
    });

    const result: Record<string, any[]> = {};
    for (const sid in studentMarksMap) {
      result[sid] = Object.values(studentMarksMap[sid]);
    }
    res.json(result);
  });


  app.get("/api/students/:id/details", (req, res) => {
    const id = req.params.id;
    const student = students.find(s => s.id === id);
    if (!student) return res.status(404).json({error: 'Not found'});

    // Attendance History
    const studentAttendance: any[] = [];
    attendanceRecords.forEach(ar => {
      const rec = (ar as any).records.find((r: any) => String(r.id) === String(id));
      if (rec) studentAttendance.push({ date: (ar as any).date, status: rec.status });
    });
    studentAttendance.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // Fee Details
    const struct = feeStructures.find(f => f.className === student.className && (f as any).section === student.section);
    const totalFee = (struct as any)?.items?.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0) || 2200; // default for demo
    const studentFeeData = feePayments.find(p => p.id === id);
    const payments = (studentFeeData as any)?.payments || [];
    const paidAmount = payments.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0);
    const balance = totalFee - paidAmount;
    let feeStatus = 'Unpaid';
    if (paidAmount > 0) {
      feeStatus = balance <= 0 ? 'Paid' : 'Partial';
    }

    const fees = { totalFee, paidAmount, balance, status: feeStatus, payments };

    // Marks / Exam Results
    const marks: any[] = [];
    analysisRecords.forEach(ar => {
      const rec = (ar as any).records.find((r: any) => String(r.id) === String(id));
      if (rec) {
        marks.push({
          examName: (ar as any).examType,
          subject: (ar as any).subject,
          totalMarks: rec.totalMarks,
          marksObtained: rec.marksObtained
        });
      }
    });

    const subjectMap: any = {};
    marks.forEach(curr => {
      if (!subjectMap[curr.examName]) subjectMap[curr.examName] = { examName: curr.examName, subjects: {} };
      
      // Override duplicates
      subjectMap[curr.examName].subjects[curr.subject] = {
        name: curr.subject,
        obtained: Number(curr.marksObtained) || 0,
        totalMarks: Number(curr.totalMarks) || 0
      };
    });

    const exams = Object.values(subjectMap).map(examObj => {
      const subjectsObj = (examObj as any).subjects;
      const subjects = Object.values(subjectsObj);
      const total = subjects.reduce((acc: number, curr: any) => acc + curr.totalMarks, 0);
      const obtained = subjects.reduce((acc: number, curr: any) => acc + curr.obtained, 0);
      return {
        examName: (examObj as any).examName,
        total,
        obtained,
        subjects: subjects.map((s: any) => ({ name: s.name, obtained: s.obtained }))
      };
    });

    res.json({
      student,
      attendance: studentAttendance,
      fees,
      marks: exams
    });
  });

  app.post("/api/students/bulk-delete", (req, res) => {
    const { studentIds } = req.body;
    if (Array.isArray(studentIds)) {
      students = students.filter(s => !studentIds.includes(s.id));
      saveDb('students.json', students);
    }
    res.json({ success: true });
  });

  app.delete("/api/students/:id", (req, res) => {
    students = students.filter(s => s.id !== req.params.id);
    saveDb('students.json', students);
    res.json({ success: true });
  });

  app.put("/api/students/:id", (req, res) => {
    const idx = students.findIndex(s => s.id === req.params.id);
    if (idx !== -1) {
      students[idx] = { ...students[idx], ...req.body };
      saveDb('students.json', students);
      res.json({ success: true, student: students[idx] });
    } else {
      res.status(404).json({ error: 'Student not found' });
    }
  });


  app.post("/api/students/:id/disconnect-telegram", (req, res) => {
    const idx = students.findIndex(s => s.id === req.params.id);
    if (idx !== -1) {
      students[idx] = { ...students[idx], telegramChatId: '' };
      saveDb('students.json', students);
      res.json({ success: true, student: students[idx] });
    } else {
      res.status(404).json({ error: 'Student not found' });
    }
  });

  app.post("/api/students/promote-selected", (req, res) => {
    const { studentIds, toClassName } = req.body;
    let promotedCount = 0;
    
    // Parse section from toClassName if it exists (e.g., "Class 10 - B" -> "B")
    const toSection = toClassName.includes(" - ") ? toClassName.split(" - ")[1] : "";

    students = students.map(s => {
      if (studentIds.includes(s.id)) {
        promotedCount++;
        return { ...s, className: toClassName, section: toSection };
      }
      return s;
    });

    // Remove from old data (attendance, marks, fees)
    attendanceRecords.forEach(ar => {
      ar.records = ar.records.filter((r: any) => !studentIds.includes(r.id));
    });
    analysisRecords.forEach(ar => {
      ar.records = ar.records.filter((r: any) => !studentIds.includes(r.id));
    });
    feePayments = feePayments.filter(fp => !studentIds.includes(fp.id));
    saveDb('students.json', students);
    saveDb('attendance.json', attendanceRecords);
    saveDb('analysis.json', analysisRecords);
    saveDb('feePayments.json', feePayments);
    res.json({ success: true, promotedCount });
  });

  app.post("/api/students/bulk-promote", (req, res) => {
    const { fromClassName, toClassName } = req.body;
    let promotedCount = 0;
    
    // Parse section from toClassName if it exists (e.g., "Class 10 - B" -> "B")
    const toSection = toClassName.includes(" - ") ? toClassName.split(" - ")[1] : "";

    const promotedRolls: string[] = [];
    students = students.map(s => {
      if (s.className === fromClassName) {
        promotedRolls.push(s.id);
        promotedCount++;
        return { ...s, className: toClassName, section: toSection };
      }
      return s;
    });

    // Remove from old data (attendance, marks, fees)
    attendanceRecords.forEach(ar => {
      ar.records = ar.records.filter((r: any) => !promotedRolls.includes(r.id));
    });
    analysisRecords.forEach(ar => {
      ar.records = ar.records.filter((r: any) => !promotedRolls.includes(r.id));
    });
    feePayments = feePayments.filter(fp => !promotedRolls.includes(fp.id));
    saveDb('students.json', students);
    saveDb('attendance.json', attendanceRecords);
    saveDb('analysis.json', analysisRecords);
    saveDb('feePayments.json', feePayments);
    res.json({ success: true, promotedCount });
  });

  app.post("/api/students/enroll", (req, res) => {
    const newStudent = { 
      ...req.body, 
      id: req.body.id || 'STU' + Date.now() + Math.floor(Math.random() * 1000),
      status: "Active Student" 
    };
    students.push(newStudent);
    saveDb('students.json', students);
    res.json({ success: true, student: newStudent });
  });

  app.post("/api/students/bulk-csv", (req, res) => {
    const { students: newStudents } = req.body;
    let added = 0;
    let updated = 0;
    console.log(`Received ${newStudents ? newStudents.length : 0} students for bulk import`);
    
    if (Array.isArray(newStudents)) {
      newStudents.forEach((row) => {
        if (!row.name || !row.rollNumber || !row.className) return;

        // Try to find an existing student by rollNumber, className, and section (if provided)
        const existingIdx = students.findIndex(s => 
          String(s.rollNumber).trim().toLowerCase() === String(row.rollNumber).trim().toLowerCase() && 
          String(s.className).trim().toLowerCase() === String(row.className).trim().toLowerCase() &&
          (!row.section || !s.section || String(s.section).trim().toLowerCase() === String(row.section).trim().toLowerCase())
        );

        if (existingIdx > -1) {
          students[existingIdx] = {
            ...students[existingIdx],
            ...row,
            status: row.status || students[existingIdx].status || "Active Student"
          };
          updated++;
        } else {
          const newStudent = { 
            ...row, 
            id: row.id || 'STU' + Date.now() + Math.floor(Math.random() * 1000000),
            status: row.status || "Active Student"
          };
          students.push(newStudent);
          added++;
        }
      });
      saveDb('students.json', students);
    }
    res.json({ success: true, added, updated });
  });

  app.post("/api/students/bulk", (req, res) => {
    const { className, section, rows } = req.body;
    // Simple update/insert logic for mock DB
    rows.forEach((row: any) => {
      const idx = students.findIndex(s => s.id === row.id);
      if (idx > -1) {
        students[idx].name = row.name;
      } else {
        students.push({ ...row, className, section });
      }
    });
    saveDb('students.json', students);
    res.json({ success: true });
  });

  app.get("/api/attendance", (req, res) => {
    const { date, className, section } = req.query;
    const roster = students.filter(s => s.className === className);
    const existing = attendanceRecords.find(a => a.date === date && a.className === className);
    
    const result = roster.map(student => {
      const existingStatus = existing?.records.find((r: any) => r.id === student.id)?.status;
      return {
        id: student.id, rollNumber: student.rollNumber,
        name: student.name,
        status: existingStatus || 'Present'
      };
    });
    res.json(result);
  });

  app.post("/api/attendance", (req, res) => {
    const { date, className, section, records } = req.body;
    const idx = attendanceRecords.findIndex(a => a.date === date && a.className === className);
    if (idx > -1) {
      attendanceRecords[idx].records = records;
    } else {
      attendanceRecords.push({ date, className, section, records });
    }
    saveDb('attendance.json', attendanceRecords);
    res.json({ success: true });
  });

  app.get("/api/fees/structure", (req, res) => {
    const { className, section } = req.query;
    const existing = feeStructures.find(f => f.className === className && f.section === section);
    res.json(existing || { items: [] });
  });

  app.post("/api/fees/structure", (req, res) => {
    const { className, section, items } = req.body;
    const idx = feeStructures.findIndex(f => f.className === className && f.section === section);
    if (idx > -1) {
      feeStructures[idx].items = items;
    } else {
      feeStructures.push({ className, section, items });
    }
    saveDb('feeStructures.json', feeStructures);
    res.json({ success: true });
  });

  app.get("/api/fees/collection", (req, res) => {
    const { className, section } = req.query;
    const roster = students.filter(s => s.className === className && (!section || s.section === section));
    const struct = feeStructures.find(f => f.className === className && f.section === section);
    const totalFee = struct?.items?.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0) || 2200;

    const result = roster.map(student => {
      const studentData = feePayments.find(p => p.id === student.id);
      const payments = studentData?.payments || [];
      const paidAmount = payments.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0);
      const balance = totalFee - paidAmount;
      
      let status = 'Unpaid';
      if (paidAmount > 0) {
        status = balance <= 0 ? 'Paid' : 'Partial';
      }

      const ACADEMIC_MONTHS = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
      const monthlyFee = totalFee / 12;
      let paidMonths: string[] = [];
      if (monthlyFee > 0) {
        const fullyPaidCount = Math.floor(paidAmount / monthlyFee);
        paidMonths = ACADEMIC_MONTHS.slice(0, fullyPaidCount);
        const partial = paidAmount % monthlyFee;
        if (partial > 0 && fullyPaidCount < 12) {
          paidMonths.push(`${ACADEMIC_MONTHS[fullyPaidCount]} (Partial)`);
        }
      }

      return {
        id: student.id, rollNumber: student.rollNumber,
        name: student.name,
        className: student.className,
        section: student.section,
        parentPhone: student.parentPhone,
        telegramChatId: student.telegramChatId,
        totalFee,
        paidAmount,
        balance,
        status,
        payments,
        paidMonths
      };
    });

    res.json(result);
  });

  app.post("/api/fees/payment", (req, res) => {
    const { id, amount, method, remarks } = req.body;
    
    // Find student to determine total fee
    const student = students.find(s => s.id === id);
    if (!student) {
       return res.status(404).json({ success: false, message: 'Student not found' });
    }
    const struct = feeStructures.find(f => f.className === student.className && f.section === student.section);
    const totalFee = struct?.items?.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0) || 2200;

    let studentData = feePayments.find(p => p.id === id);
    if (!studentData) {
      studentData = { id, rollNumber: "", payments: [] };
      feePayments.push(studentData);
    }

    const paidAmount = studentData.payments.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0);
    const balance = totalFee - paidAmount;

    if (amount > balance) {
      return res.status(400).json({ success: false, message: 'Payment exceeds remaining balance' });
    }

    studentData.payments.push({
      id: 'REC' + Date.now(),
      date: new Date().toISOString(),
      amount,
      method,
      remarks
    });
    
    saveDb('feePayments.json', feePayments);

    res.json({ success: true });
  });

  app.post("/api/fees/payment/delete", (req, res) => {
    const { id, paymentId } = req.body;
    console.log("DELETE payment called with body:", req.body);
    const studentData = feePayments.find(p => p.id === id);
    if (!studentData) {
      return res.status(404).json({ success: false, message: 'Student not found' });
    }
    const idx = studentData.payments.findIndex(p => p.id === paymentId);
    if (idx > -1) {
      studentData.payments.splice(idx, 1);
      saveDb('feePayments.json', feePayments);
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, message: 'Payment record not found' });
    }
  });

  
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      const body = req.body;
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) return res.status(500).send("No bot token");

      if (body.message) {
        const chatId = body.message.chat.id;

        // Log the message
        const incomingMsg = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5),
          date: new Date().toISOString(),
          chatId: chatId,
          username: body.message.from?.username || body.message.from?.first_name || 'Unknown',
          text: body.message.text || (body.message.contact ? '📱 Shared Contact: ' + body.message.contact.phone_number : 'Attachment/Other')
        };
        telegramMessages.unshift(incomingMsg);
        if (telegramMessages.length > 200) telegramMessages.length = 200;
        saveDb('telegramMessages.json', telegramMessages);


        // If user sends a contact
        if (body.message.contact) {
          const phone = body.message.contact.phone_number;
          
          // Normalize phone to last 10 digits to be safe
          const cleanPhone = phone.replace(/[^0-9]/g, '');
          const last10 = cleanPhone.slice(-10);

          // Find student
          const matchedStudents = students.filter(s => {
            if (!s.parentPhone) return false;
            const sPhone = s.parentPhone.replace(/[^0-9]/g, '');
            return sPhone.includes(last10);
          });

          if (matchedStudents.length > 0) {
            // Update all matched students
            matchedStudents.forEach(s => {
              s.telegramChatId = String(chatId);
            });
            saveDb('students.json', students);

            const names = matchedStudents.map(s => s.name).join(', ');
            await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                text: `✅ Successfully linked your Telegram to student(s): ${names}. You will now receive automated fee receipts and reports here.`,
                reply_markup: { remove_keyboard: true }
              })
            });
          } else {
            await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                text: `❌ We couldn't find a student associated with the phone number ${phone}. Please update your phone number with the school administration.`,
                reply_markup: { remove_keyboard: true }
              })
            });
          }
        } 
        // If user sends normal text
        else if (body.message.text) {
          await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              text: "Welcome to EduAI Bot! Please share your contact number to link your child's account so you can receive receipts and reports automatically.",
              reply_markup: {
                keyboard: [
                  [{ text: "📱 Share Phone Number", request_contact: true }]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
              }
            })
          });
        }
      }
      res.sendStatus(200); // Always respond 200 to Telegram
    } catch (e) {
      console.error("Webhook error", e);
      res.sendStatus(500);
    }
  });

  app.get("/api/headers", (req, res) => res.json(req.headers));
  app.get("/api/telegram/setup", async (req, res) => {
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) return res.status(500).json({error: "No token"});
      
      const host = req.headers['x-forwarded-host'] || req.headers.host;
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
      
      // Force HTTPS if not localhost
      const finalProtocol = host.includes('localhost') ? protocol : 'https';
      const webhookUrl = `${finalProtocol}://${host}/api/telegram/webhook`;

      const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: webhookUrl })
      });
      const data = await response.json();
      res.json({ webhookUrl, telegramResponse: data });
    } catch (e) {
      res.status(500).json({ error: String(e) });
    }
  });


  app.get("/api/telegram/messages", (req, res) => {
    res.json(telegramMessages);
  });

  app.post("/api/telegram/send", async (req, res) => {
    try {
      const { chatId, message, pdfBase64 } = req.body;
      const botToken = process.env.TELEGRAM_BOT_TOKEN;

      if (!botToken) {
        return res.status(500).json({ success: false, message: 'TELEGRAM_BOT_TOKEN is not configured on the server.' });
      }

      if (!chatId) {
        return res.status(400).json({ success: false, message: 'Telegram Chat ID is required.' });
      }

      let response;
      if (pdfBase64) {
        const formData = new FormData();
        formData.append('chat_id', chatId);
        formData.append('caption', message);
        formData.append('parse_mode', 'Markdown');
        
        const buffer = Buffer.from(pdfBase64, 'base64');
        const blob = new Blob([buffer], { type: 'application/pdf' });
        formData.append('document', blob, 'Result_Report.pdf');

        response = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
          method: 'POST',
          body: formData
        });
      } else {
        response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'Markdown'
          })
        });
      }

      const data = await response.json();
      if (data.ok) {
        res.json({ success: true });
      } else {
        res.status(400).json({ success: false, message: data.description || 'Failed to send Telegram message' });
      }
    } catch (err) {
      console.error('Telegram API Error:', err);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

  function parseImageData(rawInput: any, defaultMime = 'image/jpeg'): { cleanBase64: string; mimeType: string } {
    if (!rawInput || typeof rawInput !== 'string') {
      return { cleanBase64: '', mimeType: defaultMime };
    }
    let str = rawInput.trim();
    let mimeType = defaultMime || 'image/jpeg';

    if (str.startsWith('data:')) {
      const commaIndex = str.indexOf(',');
      if (commaIndex !== -1) {
        const header = str.substring(5, commaIndex);
        const match = header.match(/^([^;]+)/);
        if (match && match[1]) {
          mimeType = match[1];
        }
        str = str.substring(commaIndex + 1);
      }
    }

    str = str.replace(/[\r\n\s]+/g, '');
    return { cleanBase64: str, mimeType };
  }

  async function extractMarksWithGemini(
    fileData: string, 
    inputMimeType: string, 
    jobInfo: {
      className: string;
      section: string;
      subject: string;
      examType: string;
      maxMarks: string;
    },
    userApiKey?: string,
    loginId?: string
  ) {
    const apiKey = getUserGeminiApiKey(loginId, userApiKey);
    if (!apiKey) {
      throw new Error(`No Gemini API key found for user "${loginId || 'Current User'}". Every user must configure their own Gemini API key for marks extraction.`);
    }

    const { cleanBase64, mimeType } = parseImageData(fileData, inputMimeType);
    if (!cleanBase64) {
      throw new Error("Invalid or missing image data. Please upload a clear document image.");
    }

    const prompt = `You are a high-precision OCR and document analysis AI specializing in school marksheets, student grade registers, and assessment lists.

DOCUMENT CONTEXT:
- Class: ${jobInfo.className}
- Section: ${jobInfo.section}
- Subject: ${jobInfo.subject}
- Exam: ${jobInfo.examType}
- Maximum Marks: ${jobInfo.maxMarks}

TASK:
Accurately read and extract EVERY SINGLE student mark record present anywhere in this document/image.

STRICT INSTRUCTIONS:
1. EXTRACT ALL ROWS: Marksheets typically contain 10 to 50+ students. You MUST extract every single row top-to-bottom and left-to-right. Do NOT stop after 1 or 2 rows.
2. FIELDS TO EXTRACT FOR EACH STUDENT:
   - "rollNumber": (string) The roll number or serial number (e.g. "1", "2", "03").
   - "name": (string) The student's name if written on the sheet; if blank or not visible, use "".
   - "marksObtained": (string) The marks scored by the student (e.g. "45", "78.5", "AB" if absent). Do NOT mix up marks with roll number or total marks.
   - "totalMarks": (string) Total possible marks (use "${jobInfo.maxMarks}").
3. ACCURACY: Look closely at handwritten and printed digits. Distinguish between 1, 7; 5, 6; 0, 8. If marks are written in a specific subject column, pick the marks for ${jobInfo.subject} or the main marks column.
4. OUTPUT FORMAT: Output ONLY a valid JSON array of objects. No introductory text, no markdown formatting outside JSON.`;

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await generateContentWithRetryAndFallback(
      ai,
      [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType, data: cleanBase64 } },
            { text: prompt },
          ],
        },
      ],
      {
        responseMimeType: 'application/json',
        temperature: 0.1,
      }
    );

    if (!response?.text) throw new Error("No response received from Gemini.");

    let cleanText = response.text.trim();
    cleanText = cleanText.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();

    let parsed: any;
    try {
      parsed = JSON.parse(cleanText);
    } catch {
      const jsonMatch = cleanText.match(/\[[\s\S]*\]/) || cleanText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("Could not parse AI response as valid JSON.");
      }
    }

    let rawRecords: any[] = [];
    if (Array.isArray(parsed)) {
      rawRecords = parsed;
    } else if (parsed && typeof parsed === 'object') {
      rawRecords = parsed.records || parsed.students || parsed.data || Object.values(parsed).find(v => Array.isArray(v)) || [];
    }

    if (!Array.isArray(rawRecords) || rawRecords.length === 0) {
      throw new Error("No student records could be detected in the document. Please ensure the image is clear and well-lit.");
    }

    // Enrich with mock DB students
    const studentClass = (jobInfo.className + ' - ' + jobInfo.section).toLowerCase().trim();
    const enriched = rawRecords.map((r: any) => {
      const rRoll = String(r.rollNumber ?? '').trim();
      const rNum = parseInt(rRoll, 10);
      const rName = String(r.name ?? '').toLowerCase().trim();

      const student = students.find((s: any) => {
        const sClass = String(s.className ?? '').toLowerCase().trim();
        if (sClass !== studentClass) return false;
        const sRoll = String(s.rollNumber ?? '').trim();
        const sNum = parseInt(sRoll, 10);
        if (sRoll === rRoll) return true;
        if (!isNaN(rNum) && !isNaN(sNum) && rNum === sNum) return true;
        if (rName && rName !== 'not found' && String(s.name ?? '').toLowerCase().trim() === rName) return true;
        return false;
      });

      return {
        id: student ? student.id : (r.id || 'Unknown_' + rRoll),
        rollNumber: rRoll || (student ? String(student.rollNumber) : ''),
        name: student ? student.name : (r.name && r.name !== 'Not Found' ? r.name : 'Not Found'),
        totalMarks: String(r.totalMarks || jobInfo.maxMarks || '100'),
        marksObtained: String(r.marksObtained ?? ''),
        previousMarks: null,
      };
    });

    return enriched;
  }

  app.post("/api/exams/analyze", async (req, res) => {
    try {
      const { fileData, mimeType, answers, loginId, geminiApiKey } = req.body;
      const userLoginId = loginId || (req.headers['x-user-id'] as string) || 'Demo';
      const userKey = geminiApiKey || (req.headers['x-gemini-api-key'] as string);

      const rawImage = fileData || req.body.image;
      const { cleanBase64, mimeType: parsedMime } = parseImageData(rawImage, mimeType);

      const enriched = await extractMarksWithGemini(cleanBase64, parsedMime, {
        className: answers.q1,
        section: answers.q2,
        subject: answers.q3,
        examType: answers.q4,
        maxMarks: answers.q5 || '100',
      }, userKey, userLoginId);

      res.json(enriched);
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  
  app.post("/api/exams/remap", (req, res) => {
    try {
      const { records, answers } = req.body;
      const enriched = records.map((r: any) => {
        const studentClass = answers.q1 + ' - ' + answers.q2;
        const student = students.find(s => 
          String(s.rollNumber) === String(r.rollNumber) && 
          s.className === studentClass
        );
        return {
          id: student ? student.id : (r.id || 'Unknown'),
          rollNumber: r.rollNumber,
          name: student ? student.name : (student ? student.name : (r.name !== 'Not Found' ? r.name : 'Not Found')),
          totalMarks: answers.q5,
          marksObtained: r.marksObtained,
          previousMarks: null
        };
      });
      res.json(enriched);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

// AI Jobs Workflow
  interface ExamJob {
    id: string;
    filename: string;
    className: string;
    section: string;
    subject: string;
    examType: string;
    maxMarks: string;
    status: 'processing' | 'pending_verification' | 'error';
    requestData?: any;
    errorMsg?: string;
    timestamp: string;
    records?: any[];
    loginId?: string;
  }
  let examJobs: ExamJob[] = [];
  try { examJobs = JSON.parse(fs.readFileSync('./examJobs.json', 'utf-8')); } catch(e) {}

  const runExamJob = async (job: ExamJob, userApiKey?: string) => {
    const rawData = job.requestData?.fileData || job.requestData?.image;
    const { cleanBase64, mimeType } = parseImageData(rawData, job.requestData?.mimeType);

    if (!cleanBase64) {
      const idx = examJobs.findIndex(j => j.id === job.id);
      if (idx !== -1) {
        examJobs[idx].status = 'error';
        examJobs[idx].errorMsg = "Original file data is missing. Please re-upload.";
        saveDb('examJobs.json', examJobs);
      }
      return;
    }

    try {
      const enriched = await extractMarksWithGemini(cleanBase64, mimeType, {
        className: job.className,
        section: job.section,
        subject: job.subject,
        examType: job.examType,
        maxMarks: job.maxMarks,
      }, userApiKey, job.loginId);

      const idx = examJobs.findIndex(j => j.id === job.id);
      if (idx !== -1) {
        examJobs[idx].status = 'pending_verification';
        examJobs[idx].records = enriched;
        examJobs[idx].errorMsg = undefined;
        saveDb('examJobs.json', examJobs);
      }
    } catch (err: any) {
      console.error("Job processing error:", err?.message || err);
      const idx = examJobs.findIndex(j => j.id === job.id);
      if (idx !== -1) {
        examJobs[idx].status = 'error';
        examJobs[idx].errorMsg = err?.message || "Failed to process document";
        saveDb('examJobs.json', examJobs);
      }
    }
  };

  // Recover any jobs left in 'processing' state from a server restart
  examJobs.forEach(job => {
    if (job.status === 'processing') {
      console.log(`[Startup] Resuming stalled job ${job.id} (${job.filename})...`);
      runExamJob(job);
    }
  });

  app.post("/api/exams/jobs/upload", (req, res) => {
    const rawImage = req.body.fileData || req.body.image;
    const { cleanBase64, mimeType } = parseImageData(rawImage, req.body.mimeType);

    const userLoginId = (req.body.loginId || req.headers['x-user-id'] || 'Demo').toString().trim();
    const userApiKey = (req.body.geminiApiKey || req.headers['x-gemini-api-key'] || '').toString().trim();
    const keyToUse = getUserGeminiApiKey(userLoginId, userApiKey);

    if (!keyToUse) {
      return res.status(400).json({
        error: `User "${userLoginId}" has no Gemini API key set. Please click the Gemini API Key button in the top navigation bar to configure your personal Gemini API key.`
      });
    }

    const job: ExamJob = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      filename: req.body.filename || (mimeType === 'application/pdf' ? 'document.pdf' : 'marksheet.jpg'),
      className: req.body.className,
      section: req.body.section,
      subject: req.body.subject,
      examType: req.body.examType,
      maxMarks: req.body.maxMarks || '100',
      status: 'processing',
      timestamp: new Date().toISOString(),
      requestData: { fileData: cleanBase64, mimeType },
      loginId: userLoginId
    };
    examJobs.push(job);
    saveDb('examJobs.json', examJobs);

    // AI processing asynchronously in the background with user key
    runExamJob(job, userApiKey);

    res.json({ success: true, job });
  });

  
  app.post("/api/exams/jobs/:id/retry", (req, res) => {
    const jobId = req.params.id;
    const jobIndex = examJobs.findIndex(j => j.id === jobId);
    
    if (jobIndex === -1) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    const job = examJobs[jobIndex];
    if (job.status === 'pending_verification') {
      return res.status(400).json({ error: 'Job has already been processed successfully' });
    }

    const rawData = req.body.fileData || req.body.image || job.requestData?.fileData || job.requestData?.image;
    const { cleanBase64, mimeType } = parseImageData(rawData, req.body.mimeType || job.requestData?.mimeType);

    if (!cleanBase64) {
      return res.status(400).json({ error: "Original file data is missing. Please re-upload the document." });
    }

    const userLoginId = (req.body.loginId || req.headers['x-user-id'] || job.loginId || 'Demo').toString().trim();
    const userApiKey = (req.body.geminiApiKey || req.headers['x-gemini-api-key'] || '').toString().trim();
    const keyToUse = getUserGeminiApiKey(userLoginId, userApiKey);

    if (!keyToUse) {
      return res.status(400).json({
        error: `User "${userLoginId}" has no Gemini API key set. Please configure your key in the topbar before retrying.`
      });
    }

    job.loginId = userLoginId;
    
    // Reset status to processing and ensure requestData has the clean data
    examJobs[jobIndex].status = 'processing';
    examJobs[jobIndex].errorMsg = undefined;
    examJobs[jobIndex].requestData = { fileData: cleanBase64, mimeType };
    saveDb('examJobs.json', examJobs);
    
    // Restart background processing
    runExamJob(examJobs[jobIndex], userApiKey);
    res.json({ success: true });
  });

  app.get("/api/exams/jobs", (req, res) => {
    res.json(examJobs);
  });

  app.post("/api/exams/jobs/:id/verify", (req, res) => {
    const jobId = req.params.id;
    const jobIndex = examJobs.findIndex(j => j.id === jobId);
    if (jobIndex !== -1) {
      const { answers, records } = req.body;
      
      let existingRecord = analysisRecords.find(ar => 
        ar.className === answers.q1 && 
        (ar as any).section === answers.q2 && 
        (ar as any).subject === answers.q3 && 
        (ar as any).examType === answers.q4
      );
      
      if (existingRecord) {
        records.forEach((newRec: any) => {
          const idx = (existingRecord as any).records.findIndex((r: any) => String(r.id) === String(newRec.id) || String(r.rollNumber) === String(newRec.rollNumber));
          if (idx !== -1) {
            (existingRecord as any).records[idx].marksObtained = newRec.marksObtained;
            (existingRecord as any).records[idx].totalMarks = newRec.totalMarks;
          } else {
            (existingRecord as any).records.push(newRec);
          }
        });
        (existingRecord as any).timestamp = new Date().toISOString();
      } else {
        analysisRecords.push({
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
          className: answers.q1,
          section: answers.q2,
          subject: answers.q3,
          examType: answers.q4,
          timestamp: new Date().toISOString(),
          records: records
        });
      }
      
      saveDb('analysis.json', analysisRecords);

      examJobs.splice(jobIndex, 1);
      saveDb('examJobs.json', examJobs);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Job not found' });
    }
  });

  app.delete("/api/exams/jobs/:id", (req, res) => {
    examJobs = examJobs.filter(j => j.id !== req.params.id);
    saveDb('examJobs.json', examJobs);
    res.json({ success: true });
  });

  app.post("/api/exams/save-grid", (req, res) => {
    const { examName, className, section, students, maxMarks } = req.body;
    
    const subjects = ["Maths", "Science", "Hindi", "English", "Social Science", "Computer"];
    
    subjects.forEach(subject => {
      // Find if we already have a record for this class/section/exam/subject
      let existingRecord = analysisRecords.find(ar => 
        ar.className === className && 
        (ar as any).section === section && 
        (ar as any).subject === subject && 
        (ar as any).examType === examName
      );
      
      const records = students.map((s: any) => {
        const objKey = subject === 'Social Science' ? 'socialScience' : subject.toLowerCase();
        const mark = s[objKey];
        if (!mark || mark === "" || mark === "0") return null;
        return {
          id: s.id,
          name: s.name,
          totalMarks: String(maxMarks || 100),
          marksObtained: String(mark)
        };
      }).filter(Boolean);
      
      if (records.length === 0) return;
      
      if (existingRecord) {
        // Update records within the existing analysis record
        records.forEach((newRec: any) => {
          const idx = (existingRecord as any).records.findIndex((r: any) => r.id === newRec.id);
          if (idx !== -1) {
            (existingRecord as any).records[idx].marksObtained = newRec.marksObtained;
            (existingRecord as any).records[idx].totalMarks = newRec.totalMarks;
          } else {
            (existingRecord as any).records.push(newRec);
          }
        });
        (existingRecord as any).timestamp = new Date().toISOString();
      } else {
        analysisRecords.push({
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
          className,
          section,
          subject,
          examType: examName,
          timestamp: new Date().toISOString(),
          records
        });
      }
    });
    
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });

  app.post("/api/exams/save", (req, res) => {
    const { answers, records } = req.body;
    let existingRecord = analysisRecords.find(ar => 
      ar.className === answers.q1 && 
      ar.section === answers.q2 && 
      ar.subject === answers.q3 && 
      ar.examType === answers.q4
    );
    
    if (existingRecord) {
      records.forEach((newRec: any) => {
        const idx = existingRecord.records.findIndex((r: any) => String(r.id) === String(newRec.id) || (r.rollNumber && String(r.rollNumber) === String(newRec.rollNumber)));
        if (idx !== -1) {
          existingRecord.records[idx].marksObtained = newRec.marksObtained;
          existingRecord.records[idx].totalMarks = newRec.totalMarks;
          if (newRec.name) existingRecord.records[idx].name = newRec.name;
        } else {
          existingRecord.records.push(newRec);
        }
      });
      existingRecord.timestamp = new Date().toISOString();
    } else {
      analysisRecords.push({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
        className: answers.q1,
        section: answers.q2,
        subject: answers.q3,
        examType: answers.q4,
        timestamp: new Date().toISOString(),
        records
      });
    }
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });

  app.get("/api/exams/previous", (req, res) => {
    const { className, section, subject, examType } = req.query;
    const cleanClass = ((className as string) || '').split(' - ')[0].trim();
    const cleanSection = ((section as string) || '').trim();
    const cleanSubject = ((subject as string) || '').trim();
    const cleanExam = ((examType as string) || '').trim();

    const matched = analysisRecords.find(ar => 
      ar.className.trim().toLowerCase() === cleanClass.toLowerCase() &&
      (ar.section || '').trim().toLowerCase() === cleanSection.toLowerCase() &&
      (ar.subject || '').trim().toLowerCase() === cleanSubject.toLowerCase() &&
      (ar.examType || '').trim().toLowerCase() === cleanExam.toLowerCase()
    );

    if (matched) {
      res.json({ exists: true, id: matched.id, timestamp: matched.timestamp, records: matched.records || [] });
    } else {
      res.json({ exists: false, records: [] });
    }
  });

  app.get("/api/exams/analysis", (req, res) => {
    // Send full array so frontend can have details
    const summary = analysisRecords.map(a => ({
      id: a.id || a.timestamp, // fallback for old records
      className: a.className,
      section: a.section,
      subject: a.subject,
      examType: a.examType,
      timestamp: a.timestamp,
      records: a.records
    }));
    res.json(summary);
  });

  app.put("/api/exams/analysis/:id", (req, res) => {
    const { answers, records } = req.body;
    const idx = analysisRecords.findIndex(a => (a.id || a.timestamp) === req.params.id);
    if (idx !== -1) {
      analysisRecords[idx] = {
        ...analysisRecords[idx],
        className: answers.q1,
        section: answers.q2,
        subject: answers.q3,
        examType: answers.q4,
        records
      };
      saveDb('analysis.json', analysisRecords);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });

  app.delete("/api/exams/analysis/:id", (req, res) => {
    analysisRecords = analysisRecords.filter(a => (a.id || a.timestamp) !== req.params.id);
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Polling mechanism
  let lastUpdateId = 0;
  
  async function pollTelegram() {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) return;

    try {
      const res = await fetch(`https://api.telegram.org/bot${botToken}/getUpdates?offset=${lastUpdateId + 1}&timeout=10`);
      const data = await res.json();
      
      if (data.ok && data.result.length > 0) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;
          
          if (update.message) {
            const chatId = update.message.chat.id;
            const body = { message: update.message }; // mock body
            
            // Log the message
            const incomingMsg = {
              id: Date.now().toString() + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5),
              date: new Date().toISOString(),
              chatId: chatId,
              username: body.message.from?.username || body.message.from?.first_name || 'Unknown',
              text: body.message.text || (body.message.contact ? '📱 Shared Contact: ' + body.message.contact.phone_number : 'Attachment/Other')
            };
            telegramMessages.unshift(incomingMsg);
            if (telegramMessages.length > 200) telegramMessages.length = 200;
            saveDb('telegramMessages.json', telegramMessages);

            // Handle Contact
            if (body.message.contact) {
              const phone = body.message.contact.phone_number;
              const cleanPhone = phone.replace(/[^0-9]/g, '');
              const last10 = cleanPhone.slice(-10);

              const matchedStudents = students.filter(s => {
                if (!s.parentPhone) return false;
                const sPhone = s.parentPhone.replace(/[^0-9]/g, '');
                return sPhone.includes(last10);
              });

              if (matchedStudents.length > 0) {
                matchedStudents.forEach(s => {
                  s.telegramChatId = String(chatId);
                });
                saveDb('students.json', students);
                const names = matchedStudents.map(s => s.name).join(', ');
                await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: chatId,
                    text: `✅ Successfully linked your Telegram to student(s): ${names}. You will now receive automated fee receipts and reports here.`,
                    reply_markup: { remove_keyboard: true }
                  })
                });
              } else {
                await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: chatId,
                    text: `❌ We couldn't find a student associated with the phone number ${phone}. Please update your phone number with the school administration.`,
                    reply_markup: { remove_keyboard: true }
                  })
                });
              }
            }
          }
        }
      }
    } catch (e: any) {
      if (!e.message?.includes('fetch failed') && e.code !== 'ETIMEDOUT' && e.code !== 'ENOTFOUND') {
        console.error("Polling error", e.message);
      }
    }
  }

  setInterval(pollTelegram, 3000); // Poll every 3 seconds

  app.listen(PORT, "0.0.0.0", () => {
    console.log("Server running on http://localhost:" + PORT);
  });
}

startServer();
