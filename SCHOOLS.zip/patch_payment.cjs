const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

content = content.replace(
  'rollNumber: selectedStudent.student.rollNumber,',
  'id: selectedStudent.student.id,'
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx with correct payment payload");
