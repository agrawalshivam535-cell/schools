const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/Staff.tsx', 'utf-8');

const detailAvatarLogic = `<div className="w-16 h-16 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-2xl font-bold border border-indigo-500/30">
                {viewDetails.name.charAt(0)}
              </div>`;
const detailAvatarPhotoLogic = `<div className="w-16 h-16 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-2xl font-bold border border-indigo-500/30 overflow-hidden">
                {viewDetails.photo ? (
                  <img src={viewDetails.photo} alt={viewDetails.name} className="w-full h-full object-cover" />
                ) : (
                  viewDetails.name.charAt(0)
                )}
              </div>`;

content = content.replace(detailAvatarLogic, detailAvatarPhotoLogic);
fs.writeFileSync('src/components/tabs/Staff.tsx', content);
console.log("Patched Staff view details");
