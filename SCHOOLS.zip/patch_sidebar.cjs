const fs = require('fs');
let content = fs.readFileSync('src/components/Sidebar.tsx', 'utf-8');

// Remove the integrations tab from the array
content = content.replace(
  "    { id: 'classsetup', label: 'Class Setup', icon: Settings },\n    { id: 'integrations', label: 'Integrations', icon: Link2 },",
  "    { id: 'classsetup', label: 'Class Setup', icon: Settings },"
);

// Also try to remove Link2 from imports if it's unused, but it's safer to just let it be if not causing an error, 
// though standard practice would be nice. I'll just remove the tab.
fs.writeFileSync('src/components/Sidebar.tsx', content);
console.log("Patched Sidebar.tsx");
