import fs from 'fs';
let code = fs.readFileSync('src/components/Sidebar.tsx', 'utf-8');
code = code.replace(", UploadCloud } from 'lucide-react';", " } from 'lucide-react';");
code = code.replace("    { id: 'upload', label: 'Upload', icon: UploadCloud },\n", "");
fs.writeFileSync('src/components/Sidebar.tsx', code);
