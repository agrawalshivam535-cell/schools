import fs from 'fs';
let students = JSON.parse(fs.readFileSync('students.json', 'utf-8'));
let classesMap = new Map();
let classId = 1;
students.forEach(s => {
  let key = s.className; // format is usually "Class 1 - A"
  // Let's parse className and section
  let className = "Unknown";
  let section = "A";
  
  if (s.className && s.className.includes(" - ")) {
     className = s.className.split(" - ")[0];
     section = s.className.split(" - ")[1];
  } else {
     className = s.className || "Class 1";
     section = s.section || "A";
  }

  let finalKey = className + " - " + section;
  if (!classesMap.has(finalKey)) {
    classesMap.set(finalKey, {
      id: 'CLS' + String(classId++).padStart(3, '0'),
      className: className,
      section: section,
      classTeacher: 'Unassigned',
    });
  }
});
fs.writeFileSync('classes.json', JSON.stringify(Array.from(classesMap.values()), null, 2));
console.log('Done');
