const fs = require('fs');
let content = fs.readFileSync('src/main.tsx', 'utf-8');

const silenceCode = `
// Silence transient network errors in AI Studio previews
const originalConsoleError = console.error;
console.error = (...args) => {
  if (args[0] && typeof args[0] === 'string' && args[0].includes('Failed to fetch')) return;
  if (args[0] && args[0] instanceof TypeError && args[0].message === 'Failed to fetch') return;
  originalConsoleError(...args);
};
`;

if (!content.includes('originalConsoleError')) {
  content = silenceCode + '\n' + content;
  fs.writeFileSync('src/main.tsx', content);
  console.log("Patched main.tsx");
}
