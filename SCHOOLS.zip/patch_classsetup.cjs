const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

// Add state for staffList
content = content.replace(
  'const [classes, setClasses] = useState<ClassData[]>([]);',
  'const [classes, setClasses] = useState<ClassData[]>([]);\n  const [staffList, setStaffList] = useState<any[]>([]);'
);

// Add fetchStaff logic inside useEffect
const oldUseEffect = `  useEffect(() => {
    fetchClasses();
  }, []);`;

const newUseEffect = `  useEffect(() => {
    fetchClasses();
    fetch('/api/staff').then(res => res.json()).then(data => setStaffList(data)).catch(console.error);
  }, []);`;

content = content.replace(oldUseEffect, newUseEffect);

// Replace class teacher input with select
const oldClassTeacherInput = `<input 
                  type="text" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors" 
                  value={classForm.classTeacher || ''} 
                  onChange={e => setClassForm({...classForm, classTeacher: e.target.value})} 
                />`;

const newClassTeacherInput = `<select 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none cursor-pointer" 
                  value={classForm.classTeacher || ''} 
                  onChange={e => setClassForm({...classForm, classTeacher: e.target.value})} 
                >
                  <option value="" className="bg-[#151515]">Select a Class Teacher</option>
                  {staffList
                    .filter(staff => {
                      if (classForm.classTeacher === staff.name) return true;
                      return !classes.some(c => c.classTeacher === staff.name && c.id !== classForm.id);
                    })
                    .map(staff => (
                      <option key={staff.id} value={staff.name} className="bg-[#151515]">{staff.name} ({staff.role})</option>
                  ))}
                </select>`;

content = content.replace(oldClassTeacherInput, newClassTeacherInput);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Patched ClassSetup.tsx");
