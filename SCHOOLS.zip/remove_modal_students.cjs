const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const rxModal = /\s*\{\/\* Telegram Modal \*\/\}[\s\S]*?<\/div>\s*<\/div>\s*\)\}\s*<\/>\s*\)\;\s*\}/m;
const replacementModal = `\n    </>\n  );\n}`;
if(rxModal.test(content)) {
  content = content.replace(rxModal, replacementModal);
  fs.writeFileSync('src/components/tabs/Students.tsx', content);
  console.log('Removed modal from Students.tsx');
} else {
  console.log('Could not find modal in Students.tsx');
}
