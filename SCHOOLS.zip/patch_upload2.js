import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const oldSaveButtons = `<div className="flex gap-4 items-center">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-bold px-6 py-3 rounded-lg transition-colors shadow-lg"
            >
              {isSaving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
              {isSaving ? 'Saving...' : 'Verify and Update'}
            </button>`;

const newSaveButtons = `<div className="flex flex-wrap gap-4 items-center">
            <button
              onClick={handleRemap}
              disabled={isRemapping}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold px-6 py-3 rounded-lg transition-colors shadow-lg"
            >
              {isRemapping ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
              {isRemapping ? 'Updating...' : 'Change Data'}
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-bold px-6 py-3 rounded-lg transition-colors shadow-lg"
            >
              {isSaving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
              {isSaving ? 'Saving...' : 'Verify and Update'}
            </button>`;

code = code.replace(oldSaveButtons, newSaveButtons);

// Make the upload area disappear when analyzedData is true:
code = code.replace(
  `<div className="mb-8 p-6 bg-[#0a0a0a] border border-white/10 rounded-xl">\n        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Upload Handwritten Marks Document</label>`,
  `{!analyzedData && (\n      <div className="mb-8 p-6 bg-[#0a0a0a] border border-white/10 rounded-xl">\n        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Upload Handwritten Marks Document</label>`
);

code = code.replace(
  `{isUploading ? 'Analyzing...' : 'Upload & Analyze with AI'}\n            </button>\n          </div>\n        )}\n      </div>`,
  `{isUploading ? 'Analyzing...' : 'Upload & Analyze with AI'}\n            </button>\n          </div>\n        )}\n      </div>\n      )}`
);

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
