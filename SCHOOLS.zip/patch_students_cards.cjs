const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const tableCode = `<div className="bg-[#151515] border border-white/5 rounded-2xl overflow-x-auto shadow-xl">
        {loading ? (
          <div className="p-12 text-center text-gray-500">Loading directory...</div>
        ) : (
          <table className="w-full text-left min-w-[800px]">
            <thead>
              <tr className="bg-black/20 border-b border-white/10">
                <th className="p-5 w-12 text-center">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                    checked={students.length > 0 && selectedIds.length === students.length}
                    onChange={(e) => {
                      if (e.target.checked) setSelectedIds(students.map(s => s.rollNumber));
                      else setSelectedIds([]);
                    }}
                  />
                </th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Roll No</th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Name</th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Class</th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Parent Phone</th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Telegram ID</th>
                <th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-gray-500">No students found matching your criteria.</td>
                </tr>
              ) : (
                students.map((student) => (
                  <tr key={student.id} className={\`border-b border-white/5 hover:bg-white/5 transition-colors \${selectedIds.includes(student.id) ? 'bg-indigo-500/5' : ''}\`}>
                    <td className="p-5 text-center">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                        checked={selectedIds.includes(student.id)}
                        onChange={() => toggleSelectStudent(student.id)}
                      />
                    </td>
                    <td className="p-5 text-gray-300 font-medium">{student.rollNumber}</td>
                    <td className="p-5 font-bold text-indigo-400 cursor-pointer hover:text-indigo-300" onClick={() => viewStudentDetails(student.id)}>{student.name}</td>
                    <td className="p-5">
                      <span className="px-3 py-1 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-full text-xs font-bold whitespace-nowrap">
                        {student.className}
                      </span>
                    </td>
                    <td className="p-5 text-gray-400">{student.parentPhone || '-'}</td>
                    <td className="p-5 text-gray-400">
                      <div className="flex items-center gap-2">
                        <span>{student.telegramChatId || '-'}</span>
                        {student.telegramChatId && (
                          <button 
                            onClick={() => window.open(\`https://t.me/\${student.telegramChatId}\`, '_blank')}
                            className="text-[#229ED9] hover:text-[#1CA0DE] transition-colors"
                            title="Open in Telegram"
                          >
                            <Send size={14} />
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="p-5 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => viewStudentDetails(student.id)} className="p-2 text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors">
                          <Eye size={18} />
                        </button>
                        <button onClick={() => { setEditForm(student); setCurrentView('enroll'); }} className="p-2 text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors">
                          <Edit size={18} />
                        </button>
                        <button onClick={() => setDeleteConfirmId(student.id)} className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>`;

const cardCode = `      <div>
        {loading ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">Loading directory...</div>
        ) : students.length === 0 ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No students found matching your criteria.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {students.map((student) => (
              <div 
                key={student.id} 
                className={\`bg-[#151515] border \${selectedIds.includes(student.id) ? 'border-indigo-500 shadow-lg shadow-indigo-500/10' : 'border-white/5 hover:border-white/10'} rounded-2xl overflow-hidden transition-all group flex flex-col\`}
              >
                {/* Card Header (Avatar & Name) */}
                <div 
                  className="p-5 cursor-pointer relative"
                  onClick={() => viewStudentDetails(student.id)}
                >
                  <div className="absolute top-4 left-4 z-10" onClick={(e) => e.stopPropagation()}>
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                      checked={selectedIds.includes(student.id)}
                      onChange={() => toggleSelectStudent(student.id)}
                    />
                  </div>
                  
                  <div className="flex flex-col items-center mt-2">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                      <span className="text-2xl font-bold text-indigo-300">
                        {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                      </span>
                    </div>
                    <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{student.name}</h3>
                    <div className="text-xs text-gray-400 mt-1 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                      Roll No: {student.rollNumber}
                    </div>
                  </div>
                </div>

                {/* Card Body (Details) */}
                <div 
                  className="px-5 pb-5 cursor-pointer flex-1 flex flex-col justify-center"
                  onClick={() => viewStudentDetails(student.id)}
                >
                  <div className="space-y-3 mt-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Class</span>
                      <span className="font-semibold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">{student.className}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Phone</span>
                      <span className="text-gray-300">{student.parentPhone || '-'}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Telegram</span>
                      <span className="text-gray-300 flex items-center gap-1.5">
                        {student.telegramChatId || '-'}
                        {student.telegramChatId && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); window.open(\`https://t.me/\${student.telegramChatId}\`, '_blank'); }}
                            className="text-[#229ED9] hover:text-[#1CA0DE] transition-colors"
                            title="Open in Telegram"
                          >
                            <Send size={12} />
                          </button>
                        )}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Footer (Actions) */}
                <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                  <button 
                    onClick={() => viewStudentDetails(student.id)} 
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                  >
                    <Eye size={14} /> View
                  </button>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => { setEditForm(student); setCurrentView('enroll'); }} 
                      className="p-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded transition-colors"
                      title="Edit Profile"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(student.id)} 
                      className="p-1.5 text-red-400 hover:bg-red-500/10 rounded transition-colors"
                      title="Delete Student"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>`;

content = content.replace(tableCode, cardCode);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx to use cards instead of table.");
