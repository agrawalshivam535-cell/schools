const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

const oldAppStart = `export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');`;

const newAppStart = `export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [tabAction, setTabAction] = useState<string | null>(null);

  const handleNavigate = (tab: string, action?: string) => {
    setActiveTab(tab);
    setTabAction(action || null);
  };`;

content = content.replace(oldAppStart, newAppStart);

content = content.replace(
  "case 'dashboard': return <Dashboard onNavigate={setActiveTab} />;",
  "case 'dashboard': return <Dashboard onNavigate={handleNavigate} />;"
);

content = content.replace(
  "case 'students': return <Students />;",
  "case 'students': return <Students initialAction={tabAction} onActionComplete={() => setTabAction(null)} />;"
);

content = content.replace(
  "default: return <Dashboard onNavigate={setActiveTab} />;",
  "default: return <Dashboard onNavigate={handleNavigate} />;"
);

fs.writeFileSync('src/App.tsx', content);
console.log("Patched App.tsx");
