const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

const targetHeader = '<th className="p-4 text-gray-400 font-medium">Paid Months</th>';
content = content.replace(targetHeader, '');

const targetCell = "<td className=\"p-4 text-indigo-300 text-sm\">{s.paidMonths?.join(', ') || '-'}</td>";
content = content.replace(targetCell, '');

fs.writeFileSync('src/components/tabs/Fees.tsx', content);
console.log("Patched Fees.tsx again");
