const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rxTh = /<th className="p-4 whitespace-nowrap text-right">Action<\/th>/g;
const newTh = '<th className="p-4 whitespace-nowrap text-right sticky right-0 bg-[#0a0a0a] z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.3)]">Action</th>';

const rxTd = /<td className="p-4 text-right whitespace-nowrap">/g;
const newTd = '<td className="p-4 text-right whitespace-nowrap sticky right-0 bg-[#0a0a0a] z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.3)]">';

content = content.replace(rxTh, newTh);
content = content.replace(rxTd, newTd);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched sticky columns');
