import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const remapFunc = `
  const [isRemapping, setIsRemapping] = useState(false);

  const handleRemap = async () => {
    if (!analyzedData) return;
    setIsRemapping(true);
    try {
      const response = await fetch('/api/exams/remap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          records: analyzedData,
          answers: {
            q1: uploadClass,
            q2: uploadSection,
            q3: uploadSubject,
            q4: uploadExamType,
            q5: uploadMaxMarks
          }
        })
      });
      const data = await response.json();
      if (response.ok && Array.isArray(data)) {
        setAnalyzedData(data);
      } else {
        alert(data.error || 'Failed to remap data');
      }
    } catch (err: any) {
      alert('Error remapping data: ' + err.message);
    } finally {
      setIsRemapping(false);
    }
  };
`;

code = code.replace("const handleMarkChange =", remapFunc + "\n  const handleMarkChange =");

// Also add RefreshCw to lucide imports
code = code.replace("import { UploadCloud, CheckCircle2, Loader2, Edit2, Check, LayoutGrid } from 'lucide-react';", "import { UploadCloud, CheckCircle2, Loader2, Edit2, Check, LayoutGrid, RefreshCw } from 'lucide-react';");

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
