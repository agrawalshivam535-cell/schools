const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const target = `  app.post("/api/exams/save", (req, res) => {
    const { answers, records } = req.body;
    analysisRecords.push({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      className: answers.q1,
      section: answers.q2,
      subject: answers.q3,
      examType: answers.q4,
      timestamp: new Date().toISOString(),
      records
    });
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });`;

const replacement = `  app.post("/api/exams/save", (req, res) => {
    const { answers, records } = req.body;
    let existingRecord = analysisRecords.find(ar => 
      ar.className === answers.q1 && 
      ar.section === answers.q2 && 
      ar.subject === answers.q3 && 
      ar.examType === answers.q4
    );
    
    if (existingRecord) {
      records.forEach((newRec: any) => {
        const idx = existingRecord.records.findIndex((r: any) => r.id === newRec.id);
        if (idx !== -1) {
          existingRecord.records[idx].marksObtained = newRec.marksObtained;
          existingRecord.records[idx].totalMarks = newRec.totalMarks;
        } else {
          existingRecord.records.push(newRec);
        }
      });
      existingRecord.timestamp = new Date().toISOString();
    } else {
      analysisRecords.push({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
        className: answers.q1,
        section: answers.q2,
        subject: answers.q3,
        examType: answers.q4,
        timestamp: new Date().toISOString(),
        records
      });
    }
    saveDb('analysis.json', analysisRecords);
    res.json({ success: true });
  });`;

if (!code.includes(target)) {
  console.error("Could not find target!");
  process.exit(1);
}
code = code.replace(target, replacement);
fs.writeFileSync('server.ts', code);
console.log("Patched server.ts");
