const fs = require('fs');
const file = 'analysis.json';
if(fs.existsSync(file)) {
  let data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  data.forEach(a => {
    if(!a.id || data.filter(r => r.id === a.id).length > 1) {
       a.id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
    }
  });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}
