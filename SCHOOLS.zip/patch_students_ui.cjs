const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const disconnectFunc = `
  const disconnectTelegram = async (id: string) => {
    if (!confirm('Are you sure you want to disconnect Telegram for this student?')) return;
    try {
      const res = await fetch(\`/api/students/\${id}/disconnect-telegram\`, { method: 'POST' });
      if (res.ok) {
        setStudentDetails((prev: any) => prev ? { ...prev, telegramChatId: '' } : prev);
        fetchStudents();
      } else {
        alert('Failed to disconnect telegram');
      }
    } catch (e) {
      if (String(e).includes("Failed to fetch")) return;
      console.error(e);
    }
  };

  const viewStudentDetails = async`;

content = content.replace('  const viewStudentDetails = async', disconnectFunc);

const oldUI = `<div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Telegram Chat ID:</span>
                    <span className="text-white text-sm">{student.telegramChatId || 'Not Provided'}</span>
                  </div>`;

const newUI = `<div className="flex justify-between items-center border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Telegram Chat ID:</span>
                    <div className="flex items-center gap-3">
                      <span className="text-white text-sm font-mono">{student.telegramChatId || 'Not Provided'}</span>
                      {student.telegramChatId && (
                        <button 
                          onClick={() => disconnectTelegram(student.id)}
                          className="px-3 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-bold transition-colors"
                        >
                          Disconnect
                        </button>
                      )}
                    </div>
                  </div>`;

content = content.replace(oldUI, newUI);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx");
