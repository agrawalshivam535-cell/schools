const fs = require('fs');

const rawCsv = fs.readFileSync('data.csv', 'utf-8');
const lines = rawCsv.trim().split('\n').map(l => l.trim()).filter(l => l);

const headers = lines[0].split(',');

// Existing students if any
let existingStudents = [];
try {
  existingStudents = JSON.parse(fs.readFileSync('students.json', 'utf-8'));
} catch (e) {
  existingStudents = [];
}
const existingMap = new Map();
existingStudents.forEach(s => existingMap.set(s.id, s));

const newStudents = [];
for (let i = 1; i < lines.length; i++) {
  const parts = lines[i].split(',');
  const id = parts[0];
  const existing = existingMap.get(id) || {};
  
  const student = {
    id: id,
    rollNumber: parts[1],
    name: parts[2],
    className: `Class ${parts[3]} - ${parts[4]}`,
    section: parts[4],
    gender: parts[5],
    parentPhone: parts[6],
    dob: existing.dob || "",
    address: existing.address || "",
    status: existing.status || "Active Student"
  };
  // copy over any other fields that were in existing but not updated?
  for (const key in existing) {
    if (student[key] === undefined) {
      student[key] = existing[key];
    }
  }
  newStudents.push(student);
}

fs.writeFileSync('students.json', JSON.stringify(newStudents, null, 2));
console.log('Database updated successfully with ' + newStudents.length + ' records.');
