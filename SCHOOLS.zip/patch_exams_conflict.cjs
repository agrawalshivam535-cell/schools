const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Add Conflict interfaces and state
const importLine = `import { Trophy, FileText, Download, TrendingUp, Check, Save, Lock, Loader2, Send } from 'lucide-react';`;
const newImportLine = `import { Trophy, FileText, Download, TrendingUp, Check, Save, Lock, Loader2, Send, History, AlertTriangle } from 'lucide-react';`;
content = content.replace(importLine, newImportLine);

const stateInsert = `  const [isGridLoaded, setIsGridLoaded] = useState(false);`;
const conflictStates = `  const [isGridLoaded, setIsGridLoaded] = useState(false);
  
  // Conflict Resolution State
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [conflicts, setConflicts] = useState<any[]>([]);
  const [resolvedConflicts, setResolvedConflicts] = useState<Record<string, 'old' | 'new'>>({});
`;
content = content.replace(stateInsert, conflictStates);

// 2. Modify handleSaveMarks to check for conflicts
const handleSaveMarksOld = `  const handleSaveMarks = async () => {
    setIsSaving(true);
    setIsSaved(false);
    
    try {
      await fetch('/api/exams/save-grid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examName: selectedExam,
          className: enterClass,
          section: enterSection,
          students,
          maxMarks
        })
      });
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };`;

const handleSaveMarksNew = `  const handleSaveMarks = async (skipConflictCheck = false) => {
    setIsSaving(true);
    setIsSaved(false);
    
    try {
      if (!skipConflictCheck) {
        // Fetch existing marks to check for conflicts
        const marksRes = await fetch(\`/api/marks/all?className=\${encodeURIComponent(enterClass)}&section=\${encodeURIComponent(enterSection)}\`);
        if (marksRes.ok) {
          const marksData = await marksRes.json();
          const newConflicts: any[] = [];
          
          students.forEach(student => {
            const existingStudentExams = marksData[student.id] || [];
            const existingExam = existingStudentExams.find((e: any) => e.examName === selectedExam);
            if (existingExam) {
              const checkSubject = (subjName: string, newValue: string) => {
                if (newValue !== '') {
                  const existingSubj = existingExam.subjects.find((s: any) => s.name === subjName);
                  if (existingSubj && existingSubj.obtained !== newValue) {
                    newConflicts.push({
                      id: \`\${student.id}-\${subjName}\`,
                      studentId: student.id,
                      studentName: student.name,
                      rollNumber: student.rollNumber,
                      subject: subjName,
                      oldMark: existingSubj.obtained,
                      newMark: newValue
                    });
                  }
                }
              };
              checkSubject('Maths', student.maths || '');
              checkSubject('Science', student.science || '');
              checkSubject('Hindi', student.hindi || '');
            }
          });

          if (newConflicts.length > 0) {
            setConflicts(newConflicts);
            setResolvedConflicts({});
            setShowConflictModal(true);
            setIsSaving(false);
            return;
          }
        }
      }

      await fetch('/api/exams/save-grid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examName: selectedExam,
          className: enterClass,
          section: enterSection,
          students,
          maxMarks
        })
      });
      setIsSaved(true);
      setShowConflictModal(false);
      setTimeout(() => setIsSaved(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleResolveConflict = (conflictId: string, choice: 'old' | 'new') => {
    setResolvedConflicts(prev => ({ ...prev, [conflictId]: choice }));
    
    // Update the students array if 'old' is chosen
    if (choice === 'old') {
      const conflict = conflicts.find(c => c.id === conflictId);
      if (conflict) {
        setStudents(prev => prev.map(s => {
          if (s.id === conflict.studentId) {
            return { ...s, [conflict.subject.toLowerCase()]: conflict.oldMark };
          }
          return s;
        }));
      }
    }
  };
  
  const handleResolveAll = (choice: 'old' | 'new') => {
    const newResolved: Record<string, 'old' | 'new'> = {};
    conflicts.forEach(c => {
      newResolved[c.id] = choice;
      if (choice === 'old') {
        setStudents(prev => prev.map(s => {
          if (s.id === c.studentId) {
            return { ...s, [c.subject.toLowerCase()]: c.oldMark };
          }
          return s;
        }));
      }
    });
    setResolvedConflicts(newResolved);
  };
`;
content = content.replace(handleSaveMarksOld, handleSaveMarksNew);

// 3. Add modal to the JSX
const modalJSX = `
      {/* Conflict Resolution Modal */}
      {showConflictModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-white/10 rounded-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-amber-500/5 rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/20 text-amber-500 rounded-lg">
                  <AlertTriangle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Duplicate Data Detected</h3>
                  <p className="text-sm text-amber-500/80 mt-1">Some entered marks conflict with existing database records.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleResolveAll('old')} className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-lg transition-colors border border-white/10">
                  <History size={16} /> Keep All Old
                </button>
                <button onClick={() => handleResolveAll('new')} className="flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-lg">
                  <Check size={16} /> Keep All New
                </button>
              </div>
            </div>
            
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/10 text-xs font-bold text-gray-500 uppercase tracking-wider bg-black/40">
                    <th className="p-4 whitespace-nowrap">Roll No</th>
                    <th className="p-4 whitespace-nowrap">Student Name</th>
                    <th className="p-4 whitespace-nowrap">Subject</th>
                    <th className="p-4 whitespace-nowrap text-center">Conflict</th>
                    <th className="p-4 whitespace-nowrap text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {conflicts.map(conflict => {
                    const isResolved = resolvedConflicts[conflict.id];
                    return (
                      <tr key={conflict.id} className={\`border-b border-white/5 transition-colors \${isResolved ? 'opacity-50 bg-white/5' : 'hover:bg-white/5'}\`}>
                        <td className="p-4 text-gray-400 font-medium">{conflict.rollNumber}</td>
                        <td className="p-4 text-gray-300 font-bold">{conflict.studentName}</td>
                        <td className="p-4 text-indigo-400 font-medium">{conflict.subject}</td>
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-4">
                            <div className="text-center">
                              <span className="text-[10px] text-gray-500 uppercase tracking-wider block mb-1">Old Data</span>
                              <span className="text-lg font-bold text-gray-300 bg-white/5 px-3 py-1 rounded">{conflict.oldMark}</span>
                            </div>
                            <div className="text-gray-600">vs</div>
                            <div className="text-center">
                              <span className="text-[10px] text-amber-500 uppercase tracking-wider block mb-1">New Data</span>
                              <span className="text-lg font-bold text-amber-500 bg-amber-500/10 px-3 py-1 rounded border border-amber-500/20">{conflict.newMark}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          {isResolved ? (
                            <div className="flex justify-end items-center gap-2 text-emerald-400 text-sm font-bold">
                              <CheckCircle2 size={16} />
                              Resolved: Kept {isResolved}
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <button onClick={() => handleResolveConflict(conflict.id, 'old')} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded transition-colors">
                                <History size={14} /> Keep Old
                              </button>
                              <button onClick={() => handleResolveConflict(conflict.id, 'new')} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded transition-colors shadow-lg">
                                <Check size={14} /> Keep New
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            
            <div className="p-6 border-t border-white/10 flex justify-end gap-4 bg-black/40 rounded-b-2xl">
              <button 
                onClick={() => setShowConflictModal(false)}
                className="px-6 py-2.5 bg-transparent hover:bg-white/5 text-gray-300 text-sm font-bold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => handleSaveMarks(true)}
                disabled={Object.keys(resolvedConflicts).length < conflicts.length || isSaving}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 text-white text-sm font-bold rounded-lg transition-colors shadow-lg"
              >
                {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                Confirm & Save Marks
              </button>
            </div>
          </div>
        </div>
      )}
`;

// Insert the modal just before the closing </div> of the main return
const finalDivIndex = content.lastIndexOf('</div>');
content = content.slice(0, finalDivIndex) + modalJSX + content.slice(finalDivIndex);

// Add CheckCircle2 to imports since it's used in the modal
content = content.replace(
  `import { Trophy, FileText, Download, TrendingUp, Check, Save, Lock, Loader2, Send, History, AlertTriangle } from 'lucide-react';`,
  `import { Trophy, FileText, Download, TrendingUp, Check, Save, Lock, Loader2, Send, History, AlertTriangle, CheckCircle2 } from 'lucide-react';`
);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log("Patched Exams.tsx successfully");
