const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `          if (res.ok) {
            const data = await res.json();
            alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students.\`);
            fetchStudents();
          }`;

const replacement = `          if (res.ok) {
            const data = await res.json();
            
            // Extract the first valid class/section from the upload to auto-navigate
            const firstValid = rows.find((r: any) => r.className);
            if (firstValid) {
              setClassName(firstValid.className);
              if (firstValid.section) setSection(firstValid.section);
            }

            alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students.\`);
            fetchStudents();
          }`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched auto-navigation after CSV upload");
