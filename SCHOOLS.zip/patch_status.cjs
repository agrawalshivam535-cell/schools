const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const targetContent = `<div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Status</div>
                  <div className="text-2xl font-black text-indigo-400">{fees.status}</div>
                </div>`;

const replacementContent = `<div className="bg-[#151515] border border-white/5 p-6 rounded-2xl shadow-lg">
                  <div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Paid Up To</div>
                  <div className="text-xl sm:text-2xl font-black text-indigo-400 truncate">
                    {(() => {
                      if (!fees.payments || fees.payments.length === 0) return 'Unpaid';
                      const monthWeights: Record<string, number> = {
                        'April': 1, 'May': 2, 'June': 3, 'July': 4, 'August': 5, 'September': 6,
                        'October': 7, 'November': 8, 'December': 9, 'January': 10, 'February': 11, 'March': 12
                      };
                      const sortedPayments = [...fees.payments]
                        .filter(p => p.forMonth)
                        .sort((a, b) => (monthWeights[b.forMonth] || 0) - (monthWeights[a.forMonth] || 0));
                      
                      if (sortedPayments.length === 0) return fees.status;
                      const latest = sortedPayments[0];
                      return \`\${latest.forMonth}\${latest.isPartial ? ' (Partial)' : ''}\`;
                    })()}
                  </div>
                </div>`;

content = content.replace(targetContent, replacementContent);
fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx");
