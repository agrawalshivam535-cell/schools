const fs = require('fs');

const createNewBlock = (mbClass) => `              <div className="flex flex-col items-center ${mbClass}">
                <div className="relative mb-3">
                  <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-dashed border-indigo-500/50 flex items-center justify-center relative overflow-hidden group">
                    {editForm.photo ? (
                      <img src={editForm.photo} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-3xl font-bold text-indigo-400">{editForm.name ? editForm.name.charAt(0) : '?'}</span>
                    )}
                    <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                      <span className="text-white text-xs font-bold">{editForm.photo ? 'Change' : 'Upload'}</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                  {editForm.photo && (
                    <button
                      type="button"
                      onClick={() => setEditForm({ ...editForm, photo: undefined })}
                      className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-colors z-10"
                      title="Remove Photo"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
                <div className="text-xs text-gray-500 text-center">Recommended: Square image, max 2MB</div>
              </div>`;

const processFile = (filePath, mbClassTarget) => {
  let content = fs.readFileSync(filePath, 'utf-8');
  
  const oldBlock = `              <div className="flex flex-col items-center ${mbClassTarget}">
                <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-dashed border-indigo-500/50 flex items-center justify-center mb-3 relative overflow-hidden group">
                  {editForm.photo ? (
                    <img src={editForm.photo} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-3xl font-bold text-indigo-400">{editForm.name ? editForm.name.charAt(0) : '?'}</span>
                  )}
                  <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                    <span className="text-white text-xs font-bold">Upload</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                  </label>
                </div>
                <div className="text-xs text-gray-500 text-center">Recommended: Square image, max 2MB</div>
              </div>`;
              
  content = content.replace(oldBlock, createNewBlock(mbClassTarget));
  fs.writeFileSync(filePath, content);
  console.log('Patched', filePath);
};

processFile('src/components/tabs/Students.tsx', 'mb-6');
processFile('src/components/tabs/Staff.tsx', 'mb-2');

