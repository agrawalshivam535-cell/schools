const http = require('http');

let students = [];
for (let i = 0; i < 600; i++) {
  students.push({
    name: "Test " + i,
    rollNumber: i,
    className: "Class 1 - A",
    section: "A"
  });
}

const data = JSON.stringify({ students });
console.log("Payload size:", data.length);

const req = http.request({
  hostname: 'localhost',
  port: 3000,
  path: '/api/students/bulk-csv',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
}, (res) => {
  let body = '';
  res.on('data', chunk => body += chunk);
  res.on('end', () => console.log('Response:', res.statusCode, body));
});

req.on('error', e => console.error(e));
req.write(data);
req.end();
