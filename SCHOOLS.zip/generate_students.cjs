const fs = require('fs');

const firstNamesMale = ["Vivaan", "Ishaan", "Vedant", "Sai", "Tanish", "Raj", "Gaurav", "Eshan", "Jatin", "Reyansh", "Sahil", "Chirag", "Ayaan", "Uday", "Abhinav", "Pranav", "Shaurya", "Yash", "Darsh", "Daksh", "Nikhil", "Vikram", "Advik", "Harshit", "Manav", "Siddharth", "Krishna", "Raj", "Arjun", "Zaid", "Atharv", "Akshat", "Om", "Rishabh", "Rudra", "Varun", "Kabir", "Parth", "Dev", "Devansh"];
const firstNamesFemale = ["Esha", "Ananya", "Meera", "Ira", "Kashvi", "Navya", "Ovi", "Pihu", "Radha", "Tara", "Simran", "Ojaswi", "Pari", "Falak", "Vidhi", "Tanvi", "Bhoomi", "Kavya", "Myra", "Disha", "Urvi", "Diya", "Manya", "Gauri", "Charvi", "Rhea", "Riya", "Bhavya", "Kiara", "Jiya", "Anika", "Hiya", "Juhi", "Ekta", "Isha", "Avni", "Sara", "Lavanya", "Pooja", "Gunjan", "Chhavi", "Devika", "Lakshmi"];
const lastNames = ["Reddy", "Mishra", "Tripathi", "Tiwari", "Bansal", "Jain", "Rathi", "Malhotra", "Rao", "Patel", "Yadav", "Ghosh", "Singh", "Nair", "Bhatt", "Khanna", "Saxena", "Kapoor", "Gupta", "Banerjee", "Dubey", "Kumar", "Sharma", "Pillai", "Iyer", "Verma", "Desai", "Menon", "Shah", "Mehta", "Chatterjee", "Trivedi", "Naidu", "Mukherjee", "Pandey", "Chauhan", "Agarwal"];

let students = [];
let stuId = 1;

for (let c = 1; c <= 8; c++) {
  for (let s of ['A', 'B', 'C', 'D']) {
    let numStudents = Math.floor(Math.random() * 6) + 50; // 50 to 55
    for (let r = 1; r <= numStudents; r++) {
      let isMale = Math.random() > 0.5;
      let fName = isMale ? firstNamesMale[Math.floor(Math.random() * firstNamesMale.length)] : firstNamesFemale[Math.floor(Math.random() * firstNamesFemale.length)];
      let lName = lastNames[Math.floor(Math.random() * lastNames.length)];
      let name = `${fName} ${lName}`;
      let parentPhone = "9" + Math.floor(Math.random() * 900000000 + 100000000).toString();
      
      students.push({
        id: `STU${String(stuId).padStart(5, '0')}`,
        rollNumber: String(r),
        name: name,
        className: `Class ${c} - ${s}`,
        section: s,
        parentPhone: parentPhone,
        gender: isMale ? "Male" : "Female",
        status: "Active Student"
      });
      stuId++;
    }
  }
}

fs.writeFileSync('students.json', JSON.stringify(students, null, 2));
console.log(`Generated ${students.length} students.`);
