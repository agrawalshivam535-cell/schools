import fs from 'fs';

let code = fs.readFileSync('src/components/Sidebar.tsx', 'utf-8');

// Add UploadCloud to imports
code = code.replace(
  "import { Home, Users, CheckSquare, DollarSign, FileText, Calendar, LogOut, Settings, Briefcase } from 'lucide-react';",
  "import { Home, Users, CheckSquare, DollarSign, FileText, Calendar, LogOut, Settings, Briefcase, UploadCloud } from 'lucide-react';"
);

// Add upload to navItems
const oldNavItems = `    { id: 'classsetup', label: 'Class Setup', icon: Settings },
  ];`;
const newNavItems = `    { id: 'classsetup', label: 'Class Setup', icon: Settings },
    { id: 'upload', label: 'Upload', icon: UploadCloud },
  ];`;

code = code.replace(oldNavItems, newNavItems);

fs.writeFileSync('src/components/Sidebar.tsx', code);
