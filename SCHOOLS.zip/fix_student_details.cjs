const fs = require('fs');

let serverContent = fs.readFileSync('server.ts', 'utf-8');

const detailsRx = /const groupedMarks = marks\.reduce\(\(acc: any, curr: any\) => \{[\s\S]*?res\.json\(\{ student, attendance: studentAttendance, fees, exams \}\);\s*\}\);/m;

const newDetails = `const subjectMap: any = {};
    marks.forEach(curr => {
      if (!subjectMap[curr.examName]) subjectMap[curr.examName] = { examName: curr.examName, subjects: {} };
      
      // Override duplicates
      subjectMap[curr.examName].subjects[curr.subject] = {
        name: curr.subject,
        obtained: Number(curr.marksObtained) || 0,
        totalMarks: Number(curr.totalMarks) || 0
      };
    });

    const exams = Object.values(subjectMap).map(examObj => {
      const subjectsObj = (examObj as any).subjects;
      const subjects = Object.values(subjectsObj);
      const total = subjects.reduce((acc: number, curr: any) => acc + curr.totalMarks, 0);
      const obtained = subjects.reduce((acc: number, curr: any) => acc + curr.obtained, 0);
      return {
        examName: (examObj as any).examName,
        total,
        obtained,
        subjects: subjects.map((s: any) => ({ name: s.name, obtained: s.obtained }))
      };
    });

    res.json({ student, attendance: studentAttendance, fees, exams });
  });`;

serverContent = serverContent.replace(detailsRx, newDetails);
fs.writeFileSync('server.ts', serverContent);
console.log('Fixed /api/students/:id/details duplicate subjects');
