import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const badHeaders = `<th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>`;
const goodHeaders = `<th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>`;

code = code.replace(badHeaders, goodHeaders);
fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Fixed headers');
