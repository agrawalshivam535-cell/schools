const http = require('http');

const data = JSON.stringify({
  answers: {
    q1: 'Class 6',
    q2: 'A',
    q3: 'English',
    q4: 'Unit Test 2',
    q5: '100'
  },
  records: [
    {
      id: 'STU-06A-001',
      marksObtained: '92',
      totalMarks: '100'
    }
  ]
});

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/exams/save',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => console.log('Response:', body));
});

req.write(data);
req.end();
