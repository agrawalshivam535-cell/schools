const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// The state:
// const [promoteModal, setPromoteModal] = useState<{ isOpen: boolean, toClass: string }>({ isOpen: false, toClass: 'Class 10 - A' });
// Change to include actionType:
content = content.replace(
  `const [promoteModal, setPromoteModal] = useState<{ isOpen: boolean, toClass: string }>({ isOpen: false, toClass: 'Class 10 - A' });`,
  `const [promoteModal, setPromoteModal] = useState<{ isOpen: boolean, toClass: string, actionType: 'promote' | 'demote' | 'reassign' }>({ isOpen: false, toClass: 'Class 10 - A', actionType: 'reassign' });`
);

// The button:
content = content.replace(
  `onClick={() => setPromoteModal({ isOpen: true, toClass: classes[2] || classes[1] })}`,
  `onClick={() => setPromoteModal({ isOpen: true, toClass: classes[2] || classes[1], actionType: 'reassign' })}`
);
content = content.replace(
  `Promote Selected ({selectedIds.length})`,
  `Reassign Selected ({selectedIds.length})`
);

// Modal titles:
content = content.replace(
  `<h3 className="text-xl font-bold text-white mb-6">Promote Selected Students</h3>`,
  `<h3 className="text-xl font-bold text-white mb-6">Reassign Selected Students</h3>`
);
content = content.replace(
  `<p className="text-sm text-gray-400 mb-6">You are about to promote {selectedIds.length} student(s).</p>`,
  `<p className="text-sm text-gray-400 mb-6">You are about to reassign {selectedIds.length} student(s) to a new class.</p>`
);
content = content.replace(
  `<label className="block text-sm font-medium text-gray-400 mb-2">Promote To Class</label>`,
  `<label className="block text-sm font-medium text-gray-400 mb-2">Reassign To Class</label>`
);
content = content.replace(
  `{isPromoting ? 'Promoting...' : 'Promote'}`,
  `{isPromoting ? 'Processing...' : 'Confirm Reassign'}`
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx");
