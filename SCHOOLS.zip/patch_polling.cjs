const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const webhookHandlerLogic = `// Polling mechanism
  let lastUpdateId = 0;
  
  async function pollTelegram() {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) return;

    try {
      const res = await fetch(\`https://api.telegram.org/bot\${botToken}/getUpdates?offset=\${lastUpdateId + 1}&timeout=10\`);
      const data = await res.json();
      
      if (data.ok && data.result.length > 0) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;
          
          if (update.message) {
            const chatId = update.message.chat.id;
            const body = { message: update.message }; // mock body
            
            // Log the message
            const incomingMsg = {
              id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
              date: new Date().toISOString(),
              chatId: chatId,
              username: body.message.from?.username || body.message.from?.first_name || 'Unknown',
              text: body.message.text || (body.message.contact ? '📱 Shared Contact: ' + body.message.contact.phone_number : 'Attachment/Other')
            };
            telegramMessages.unshift(incomingMsg);
            if (telegramMessages.length > 200) telegramMessages.length = 200;
            saveDb('telegramMessages.json', telegramMessages);

            // Handle Contact
            if (body.message.contact) {
              const phone = body.message.contact.phone_number;
              const cleanPhone = phone.replace(/[^0-9]/g, '');
              const last10 = cleanPhone.slice(-10);

              const matchedStudents = students.filter(s => {
                if (!s.parentPhone) return false;
                const sPhone = s.parentPhone.replace(/[^0-9]/g, '');
                return sPhone.includes(last10);
              });

              if (matchedStudents.length > 0) {
                matchedStudents.forEach(s => {
                  s.telegramChatId = String(chatId);
                });
                saveDb('students.json', students);
                const names = matchedStudents.map(s => s.name).join(', ');
                await fetch(\`https://api.telegram.org/bot\${botToken}/sendMessage\`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: chatId,
                    text: \`✅ Successfully linked your Telegram to student(s): \${names}. You will now receive automated fee receipts and reports here.\`,
                    reply_markup: { remove_keyboard: true }
                  })
                });
              } else {
                await fetch(\`https://api.telegram.org/bot\${botToken}/sendMessage\`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    chat_id: chatId,
                    text: \`❌ We couldn't find a student associated with the phone number \${phone}. Please update your phone number with the school administration.\`,
                    reply_markup: { remove_keyboard: true }
                  })
                });
              }
            }
          }
        }
      }
    } catch (e) {
      console.error("Polling error", e);
    }
  }

  setInterval(pollTelegram, 3000); // Poll every 3 seconds
`;

content = content.replace(
  'app.listen(PORT, "0.0.0.0", () => {',
  webhookHandlerLogic + '\n  app.listen(PORT, "0.0.0.0", () => {'
);
fs.writeFileSync('server.ts', content);
