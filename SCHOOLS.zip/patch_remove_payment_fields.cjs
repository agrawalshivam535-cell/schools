const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// 1. Remove state types
content = content.replace(
  `const [paymentForm, setPaymentForm] = useState<{ amount: string; method: string; remarks: string; forMonth: string; isPartial: boolean } | null>(null);`,
  `const [paymentForm, setPaymentForm] = useState<{ amount: string; method: string; remarks: string } | null>(null);`
);

// 2. Remove fields from initialization
content = content.replace(
  `onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '', forMonth: new Date().toLocaleString('default', { month: 'long' }), isPartial: false })}`,
  `onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '' })}`
);

// 3. Remove from fetch body
content = content.replace(
  `          amount: Number(paymentForm.amount),
          method: paymentForm.method,
          remarks: paymentForm.remarks,
          forMonth: paymentForm.forMonth,
          isPartial: paymentForm.isPartial`,
  `          amount: Number(paymentForm.amount),
          method: paymentForm.method,
          remarks: paymentForm.remarks`
);

// 4. Remove form fields for forMonth and isPartial
const formTarget = `              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">For Month *</label>
                <select 
                  required 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors appearance-none" 
                  value={paymentForm.forMonth} 
                  onChange={e => setPaymentForm({...paymentForm, forMonth: e.target.value})}
                >
                  {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                    <option key={m} value={m} className="bg-[#151515]">{m}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <input 
                  type="checkbox" 
                  id="isPartial"
                  checked={paymentForm.isPartial}
                  onChange={e => setPaymentForm({...paymentForm, isPartial: e.target.checked})}
                  className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="isPartial" className="text-sm font-medium text-gray-400 cursor-pointer">
                  This is a partial payment for the selected month
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Payment Method *</label>`;

content = content.replace(formTarget, `              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Payment Method *</label>`);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched Students.tsx");
