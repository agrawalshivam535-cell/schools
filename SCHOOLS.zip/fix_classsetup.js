import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

const stateVars = `
  const [promoteForm, setPromoteForm] = useState({ fromClass: '', toClass: '' });
  const [selectiveToClass, setSelectiveToClass] = useState('');
  const [search, setSearch] = useState('');
  const [promoteModal, setPromoteModal] = useState(false);
  const [isPromoting, setIsPromoting] = useState(false);
  const [selectedClassForPromotion, setSelectedClassForPromotion] = useState<any>(null);
  const [classStudents, setClassStudents] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [selectivePromoteModal, setSelectivePromoteModal] = useState(false);
`;

if (!code.includes('const [promoteForm')) {
  code = code.replace(
    "const [classes, setClasses] = useState<ClassData[]>([]);",
    "const [classes, setClasses] = useState<ClassData[]>([]);\n" + stateVars
  );
}

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', code);
console.log('Fixed ClassSetup.tsx');
