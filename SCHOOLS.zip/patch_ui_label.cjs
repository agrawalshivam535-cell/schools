const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// In Fee ledger cards
const oldCard = `<div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Status</div>
                  <div className="text-lg sm:text-xl font-black text-indigo-400 truncate" title={fees.status}>{fees.status}</div>`;

const newCard = `<div className="text-xs text-gray-500 font-bold tracking-wider mb-2 uppercase">Paid Month</div>
                  <div className="text-lg sm:text-xl font-black text-indigo-400 truncate" title={fees.status}>{fees.status}</div>`;

content = content.replace(oldCard, newCard);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
