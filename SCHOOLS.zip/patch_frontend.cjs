const fs = require('fs');

const classes = ['All Classes'];
for (let c = 1; c <= 8; c++) {
  for (let s of ['A', 'B', 'C', 'D']) {
    classes.push(`Class ${c} - ${s}`);
  }
}

const noAllClasses = classes.slice(1);

const files = [
  'src/components/tabs/Students.tsx',
  'src/components/tabs/Fees.tsx',
  'src/components/tabs/Timetable.tsx',
  'src/components/tabs/Attendance.tsx',
  'src/components/tabs/Exams.tsx'
];

for (let file of files) {
  if (!fs.existsSync(file)) continue;
  let content = fs.readFileSync(file, 'utf-8');
  
  if (file.includes('Students.tsx')) {
    content = content.replace(/const classes = \[.*?\];/, `const classes = ${JSON.stringify(classes)};`);
    content = content.replace(/const sections = \[.*?\];/, `const sections = ['All Sections', 'A', 'B', 'C', 'D'];`);
  } else {
    content = content.replace(/const classes = \[.*?\];/, `const classes = ${JSON.stringify(noAllClasses)};`);
  }
  
  fs.writeFileSync(file, content);
}
