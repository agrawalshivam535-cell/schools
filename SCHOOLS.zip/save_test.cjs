const http = require('http');

const data = JSON.stringify({
  examName: 'Unit Test 1',
  className: 'Class 6',
  section: 'A',
  maxMarks: 100,
  students: [
    {
      id: 'STU-06A-001',
      name: 'Komal Kapoor',
      maths: '95',
      science: '85',
      hindi: '75'
    }
  ]
});

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/exams/save-grid',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => console.log('Response:', body));
});

req.write(data);
req.end();
