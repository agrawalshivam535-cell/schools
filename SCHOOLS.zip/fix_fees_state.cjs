const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

content = content.replace(
  "  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);| 'collection'>('structure');",
  "  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);"
);

fs.writeFileSync('src/components/tabs/Fees.tsx', content);
