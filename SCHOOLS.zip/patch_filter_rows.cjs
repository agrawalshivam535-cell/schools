const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `          }
          return normalized;
        });

        const res = await fetch('/api/students/bulk-csv',`;

const replacement = `          }
          return normalized;
        });

        // Filter out empty or invalid rows before sending to avoid massive payloads
        rows = rows.filter((r: any) => r.name && r.rollNumber && r.className);

        const res = await fetch('/api/students/bulk-csv',`;

if (!code.includes(target)) {
    console.error("Could not find target!");
    process.exit(1);
}
code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched to filter empty rows before sending");
