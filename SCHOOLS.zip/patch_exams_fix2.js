import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const oldEnd = `
            )}
          </div>
        )}
        {activeTab === 'processed' && (
          <ProcessedDataList />
        )}
      </div>
    </div>
  );
}
`;
const newEnd = `
            )}
          </div>
        ) : null}
        {activeTab === 'processed' && (
          <ProcessedDataList />
        )}
      </div>
    </div>
  );
}
`;

code = code.replace(oldEnd.trim(), newEnd.trim());
fs.writeFileSync('src/components/tabs/Exams.tsx', code);
