const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Update handleMarkChange
const markRx = /const handleMarkChange = \(id: string, subject: keyof StudentMarks, value: string\) => \{\s*\/\/ Only allow empty or numbers\s*if \(value !== '' && !\/^\d\+\$\/\.test\(value\)\) return;\s*setStudents\(students\.map\(s => \{\s*if \(s\.id === id\) \{\s*return \{ \.\.\.s, \[subject\]: value \};\s*\}\s*return s;\s*\}\)\);\s*\};/m;

const newMark = `const handleMarkChange = (id: string, subject: keyof StudentMarks, value: string) => {
    // Only allow empty or numbers
    if (value !== '' && !/^\\d+$/.test(value)) return;
    
    if (value !== '') {
      const num = parseInt(value, 10);
      let maxMarks = 100;
      const lowerExam = selectedExam.toLowerCase();
      if (lowerExam.includes('unit test')) maxMarks = 25;
      else if (lowerExam.includes('mid-year') || lowerExam.includes('mid term')) maxMarks = 50;
      else if (lowerExam.includes('annual') || lowerExam.includes('final')) maxMarks = 100;
      
      if (num > maxMarks) {
        alert(\`Maximum marks for \${selectedExam} is \${maxMarks}\`);
        return;
      }
    }

    setStudents(students.map(s => {
      if (s.id === id) {
        return { ...s, [subject]: value };
      }
      return s;
    }));
  };`;

content = content.replace(markRx, newMark);

// 2. Update calculateTotal
const calcTotalRx = /const calculateTotal = \(student: StudentMarks\) => \{\s*const m = parseInt\(student\.maths\) \|\| 0;\s*const s = parseInt\(student\.science\) \|\| 0;\s*const h = parseInt\(student\.hindi\) \|\| 0;\s*return m \+ s \+ h;\s*\};/m;
const newCalcTotal = `const calculateTotal = (student: StudentMarks) => {
    const m = parseInt(student.maths) || 0;
    const s = parseInt(student.science) || 0;
    const h = parseInt(student.hindi) || 0;
    const e = parseInt(student.english) || 0;
    const ss = parseInt(student.socialScience) || 0;
    const c = parseInt(student.computer) || 0;
    return m + s + h + e + ss + c;
  };`;

content = content.replace(calcTotalRx, newCalcTotal);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Max Marks in Exams.tsx');
