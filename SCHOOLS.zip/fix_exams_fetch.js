import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

code = code.replace(
  "const res = await fetch(`/api/students?className=${encodeURIComponent(enterClass)}`);",
  "const res = await fetch(`/api/students?className=${encodeURIComponent(enterClass + ' - ' + enterSection)}`);"
);

code = code.replace(
  "const res = await fetch(`/api/students?className=${encodeURIComponent(resultClass)}`);",
  "const res = await fetch(`/api/students?className=${encodeURIComponent(resultClass + ' - ' + resultSection)}`);"
);

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Fixed fetches');
