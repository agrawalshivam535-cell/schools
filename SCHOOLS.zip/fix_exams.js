import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// Move import to the top
code = code.replace("  import { useEffect as UseEffectExams } from 'react';", "");
code = "import { useEffect as UseEffectExams } from 'react';\n" + code;

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Fixed import');
