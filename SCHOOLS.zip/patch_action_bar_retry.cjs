const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const replacement = `<div className="flex gap-3 flex-wrap items-center">
          <button
            onClick={() => {
              if (selectedIds.length === students.length && students.length > 0) {
                setSelectedIds([]);
              } else {
                setSelectedIds(students.map(s => s.id));
              }
            }}
            className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/20 px-4 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            {selectedIds.length === students.length && students.length > 0 ? 'Deselect All' : 'Select All'}
          </button>
`;

code = code.replace(/<div className="flex gap-3">/g, replacement);

fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched action bar retry");
