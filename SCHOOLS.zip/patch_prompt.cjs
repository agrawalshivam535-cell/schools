const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetPrompt = `const prompt = "Class: " + job.className + "\\nSection: " + job.section + "\\nSubject: " + job.subject + "\\nExam: " + job.examType + "\\nTotal: " + job.maxMarks + "\\nExtract rollNumber, name, totalMarks (" + job.maxMarks + "), marksObtained in JSON array. Ensure the properties in the JSON objects are exactly \\"rollNumber\\", \\"name\\", \\"totalMarks\\", \\"marksObtained\\".";`;

const newPrompt = `const prompt = \`You are an expert OCR and data extraction AI.
Context:
Class: \${job.className}
Section: \${job.section}
Subject: \${job.subject}
Exam: \${job.examType}
Total Marks: \${job.maxMarks}

Task:
Extract EVERY SINGLE student's mark record from the provided image. The image contains a list or table of student roll numbers, names, and their obtained marks.

CRITICAL INSTRUCTIONS:
1. Extract ALL rows present in the image. Do not stop after 1 row. There are often multiple rows (e.g., 10 to 50+).
2. Scan the entire document top-to-bottom and left-to-right.
3. Read carefully. Match the roll number and the obtained marks correctly.
4. Return ONLY a valid JSON array of objects.
5. Each object MUST have exactly these keys:
   - "rollNumber": (string) The student's roll number.
   - "name": (string) The student's name if present, otherwise "".
   - "totalMarks": (string) Always use "\${job.maxMarks}".
   - "marksObtained": (string) The marks obtained. If absent or illegible, use "".

Double-check that you did not miss any rows. Output as JSON array.\`;`;

let matches = code.split(targetPrompt).length - 1;
if (matches > 0) {
    code = code.split(targetPrompt).join(newPrompt);
    fs.writeFileSync('server.ts', code);
    console.log("Successfully updated prompt in " + matches + " places.");
} else {
    console.log("Target prompt not found. Dumping surrounding context:");
    // Find where the prompt is
    const lines = code.split('\n');
    for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes('const prompt =')) {
            console.log(`Line ${i}: ${lines[i]}`);
        }
    }
}
