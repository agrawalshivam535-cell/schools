const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');
content = content.replace(/analysisRecords\.push\({\s*className,/g, "analysisRecords.push({\n          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),\n          className,");
fs.writeFileSync('server.ts', content);
