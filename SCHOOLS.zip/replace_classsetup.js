import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

code = code.replace(/const mockClasses[\s\S]*?\];/m, '');
code = code.replace(/const availableClassesList[\s\S]*?\];/m, '');

code = code.replace(
  "const [classes, setClasses] = useState<ClassData[]>(mockClasses);",
  `const [classes, setClasses] = useState<ClassData[]>([]);
  
  const fetchClasses = async () => {
    try {
      const res = await fetch('/api/classes');
      if (res.ok) {
        const data = await res.json();
        // Sort classes
        data.sort((a: any, b: any) => a.className.localeCompare(b.className) || a.section.localeCompare(b.section));
        setClasses(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchClasses();
  }, []);

  const dynamicClassesList = classes.map(c => c.className + (c.section ? ' - ' + c.section : ''));
  `
);

// fix promoteForm defaults
code = code.replace(
  "const [promoteForm, setPromoteForm] = useState({ fromClass: availableClassesList[0], toClass: availableClassesList[2] });",
  "const [promoteForm, setPromoteForm] = useState({ fromClass: '', toClass: '' });"
);

// fix selectiveToClass default
code = code.replace(
  "const [selectiveToClass, setSelectiveToClass] = useState(availableClassesList[2]);",
  "const [selectiveToClass, setSelectiveToClass] = useState('');"
);

// ensure promoteForm and selectiveToClass have valid values when classes load
code = code.replace(
  "useEffect(() => {",
  `useEffect(() => {
    if (classes.length > 0) {
      if (!promoteForm.fromClass) {
        setPromoteForm({ fromClass: dynamicClassesList[0] || '', toClass: dynamicClassesList[1] || dynamicClassesList[0] || '' });
      }
      if (!selectiveToClass) {
        setSelectiveToClass(dynamicClassesList[0] || '');
      }
    }
  }, [classes, promoteForm.fromClass, selectiveToClass]);
  
  useEffect(() => {`
);

// replace availableClassesList.map with dynamicClassesList.map
code = code.replace(/availableClassesList\.map/g, 'dynamicClassesList.map');

// re-fetch classes on successful bulk promote
code = code.replace(
  "setPromoteModal(false);",
  "setPromoteModal(false);\n        fetchClasses();"
);

// re-fetch classes on successful selective promote
code = code.replace(
  "fetchClassStudents(selectedClassForPromotion);",
  "fetchClassStudents(selectedClassForPromotion);\n          fetchClasses();"
);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', code);
console.log('ClassSetup.tsx patched');
