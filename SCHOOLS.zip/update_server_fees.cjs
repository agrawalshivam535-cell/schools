const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

content = content.replace(
  `app.post("/api/fees/payment", (req, res) => {
    const { id, amount, method, remarks } = req.body;`,
  `app.post("/api/fees/payment", (req, res) => {
    const { id, amount, method, remarks, forMonth, isPartial } = req.body;`
);

content = content.replace(
  `studentData.payments.push({
      id: 'REC' + Date.now(),
      date: new Date().toISOString(),
      amount,
      method,
      remarks
    });`,
  `studentData.payments.push({
      id: 'REC' + Date.now(),
      date: new Date().toISOString(),
      amount,
      method,
      remarks,
      forMonth,
      isPartial
    });`
);

// We should also add a summary of Paid Months to the student's detail view payload in server.ts
// Wait, the front-end just iterates over `payments` to show the table. It has all the info now.
// So no need to modify the response `fees` object other than that `payments` array will include forMonth/isPartial which is handled automatically as `payments` is pushed as-is.

fs.writeFileSync('server.ts', content);
console.log("Patched server.ts");
