const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// Add sendReceiptViaTelegram
const downloadReceiptRx = /const downloadReceipt = \(payment: any, student: any\) => \{[\s\S]*?doc\.save\(`Receipt_\$\{student\.rollNumber\}_\$\{new Date\(payment\.date\)\.getTime\(\)\}\.pdf`\);\s*\};/m;

const sendTelegramFunc = `
  const sendReceiptViaTelegram = async (payment: any, student: any) => {
    setSendingTelegramId(payment.id || payment.date);
    try {
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text('EduAI SaaS', 105, 20, { align: 'center' });
      
      doc.setFontSize(16);
      doc.text('Fee Receipt', 105, 30, { align: 'center' });

      doc.setFontSize(12);
      doc.text("Receipt ID: " + (payment.id || Math.random().toString(36).substring(7).toUpperCase()), 20, 50);
      doc.text("Date: " + new Date(payment.date).toLocaleString(), 20, 60);
      
      doc.text("Student Name: " + student.name, 20, 80);
      doc.text("Roll Number: " + student.rollNumber, 20, 90);
      doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 100);
      
      doc.setLineWidth(0.5);
      doc.line(20, 110, 190, 110);
      
      doc.text('Amount Paid:', 20, 120);
      doc.text("Rs. " + payment.amount, 150, 120);
      
      doc.text('Payment Method:', 20, 130);
      doc.text(payment.method || 'Online', 150, 130);
      
      if (payment.remarks) {
        doc.text('Remarks:', 20, 140);
        doc.text(payment.remarks, 150, 140);
      }
      
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const message = \`*Fee Receipt*\nReceipt ID: \${payment.id || ''}\nDate: \${new Date(payment.date).toLocaleString()}\nAmount Paid: Rs. \${payment.amount}\nMethod: \${payment.method || 'Online'}\n\nThank you!\`;
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Receipt sent successfully to ' + student.name);
      } else {
        alert(\`Failed to send receipt: \${data.message}\`);
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while sending the receipt.');
    } finally {
      setSendingTelegramId(null);
    }
  };`;

content = content.replace(downloadReceiptRx, (match) => {
  return match + sendTelegramFunc;
});

// Update the UI buttons
const btnRx = /<td className="p-5 text-right">\s*<button \s*onClick=\{\(\) => downloadReceipt\(p, student\)\}\s*className="text-indigo-400 hover:text-indigo-300 text-sm font-bold flex items-center justify-end gap-1\.5 w-full"\s*>\s*<Download size=\{14\} \/> Download\s*<\/button>\s*<\/td>/m;

const newBtns = `<td className="p-5 text-right">
                            <div className="flex items-center justify-end gap-3">
                              <button 
                                onClick={() => downloadReceipt(p, student)}
                                className="text-indigo-400 hover:text-indigo-300 text-sm font-bold flex items-center gap-1.5 transition-colors"
                              >
                                <Download size={14} /> Download
                              </button>
                              <button 
                                onClick={() => sendReceiptViaTelegram(p, student)}
                                disabled={sendingTelegramId === (p.id || p.date)}
                                className="text-[#229ED9] hover:text-[#229ED9]/80 text-sm font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                              >
                                {sendingTelegramId === (p.id || p.date) ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />} Telegram
                              </button>
                            </div>
                          </td>`;

content = content.replace(btnRx, newBtns);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log('Patched Students.tsx');
