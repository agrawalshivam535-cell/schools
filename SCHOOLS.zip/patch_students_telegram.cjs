const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// 1. Add sendingTelegramId state
content = content.replace(
  /const \[telegramModal, setTelegramModal\] = useState[^;]+;/,
  `const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);`
);

// 2. Replace sendTelegramResult and confirmSendTelegram
const rxFuncs = /  const sendTelegramResult = async \(exam: any, student: any\) => \{[\s\S]*?  const confirmSendTelegram = async \(\) => \{[\s\S]*?    \} catch \(err\) \{[\s\S]*?    \}\n  \};/m;

const replacementFuncs = `  const sendTelegramResult = async (exam: any, student: any) => {
    setSendingTelegramId(exam.examName);
    try {
      let message = \`*Academic Report - \${student.name}*\\nRoll No: \${student.rollNumber}\\nClass: \${student.className} \${student.section ? '- ' + student.section : ''}\\n\\n\`;
      message += \`*\${exam.examName}*\\n\`;
      exam.subjects.forEach((subj: any) => {
        message += \`\${subj.name}: \${subj.obtained}\\n\`;
      });
      message += \`Total: \${exam.obtained}/\${exam.total}\\n\\n\`;
      
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }
      
      const doc = buildSinglePDF(exam, student);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Message sent successfully to ' + student.name);
      } else {
        alert(\`Failed to send message: \${data.message}\`);
      }
    } catch (err) {
      alert('An error occurred while sending the message.');
    } finally {
      setSendingTelegramId(null);
    }
  };`;

content = content.replace(rxFuncs, replacementFuncs);

// 3. Replace the Send button to show loading state
const rxBtn = /<button\s*onClick=\{\(\) => sendTelegramResult\(exam, selectedStudent\.student\)\}\s*className="p-1\.5 hover:bg-\[#229ED9\]\/20 text-\[#229ED9\] rounded-lg transition-colors"\s*title="Send via Telegram"\s*>\s*<Send size=\{18\} \/>\s*<\/button>/m;

const replacementBtn = `<button 
                                onClick={() => sendTelegramResult(exam, selectedStudent.student)}
                                disabled={sendingTelegramId === exam.examName}
                                className="p-1.5 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors disabled:opacity-50"
                                title="Send via Telegram"
                              >
                                {sendingTelegramId === exam.examName ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                              </button>`;

content = content.replace(rxBtn, replacementBtn);

// 4. Remove the telegram modal from render
const rxModal = /\s*\{\/\* Telegram Modal \*\/\}[\s\S]*?<\/div>\s*<\/div>\s*\)\}\s*<\/div>\s*\)\;\s*\}/m;
const replacementModal = `\n    </div>\n  );\n}`;
content = content.replace(rxModal, replacementModal);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log('Patched direct telegram send in Students.tsx');
