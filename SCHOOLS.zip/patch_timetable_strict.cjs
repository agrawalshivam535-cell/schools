const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Timetable.tsx', 'utf-8');

const strictValidation = `      // 1. Strict Validation: Same teacher, same subject on the same day across ALL classes
      // "he should not be assigned Hindi on any other period on Monday."
      for (const [clsName, clsData] of Object.entries(timetableData)) {
        const isAlreadyTeachingSameSubjectToday = Object.entries(clsData).some(([key, val]) => {
          return key.endsWith(daySuffix) && key !== slotKey && val.teacher === teacher && val.subject === subject;
        });

        if (isAlreadyTeachingSameSubjectToday) {
          alert(\`\${teacher} is already assigned to teach \${subject} on \${assignSlot.day} in another period (\${clsName === className ? 'this class' : clsName}). They cannot be assigned to the same subject again on the same day.\`);
          return;
        }
      }`;

// Replacing the validation section from previous patch
content = content.replace(
  `      // 1. Validation: Same teacher, same subject on the same day for this class
      const currentClassData = timetableData[className] || {};
      const isAlreadyTeachingSameSubjectToday = Object.entries(currentClassData).some(([key, val]) => {
        return key.endsWith(daySuffix) && key !== slotKey && val.teacher === teacher && val.subject === subject;
      });

      if (isAlreadyTeachingSameSubjectToday) {
        alert(\`\${teacher} is already assigned to teach \${subject} on \${assignSlot.day} for this class.\`);
        return;
      }`,
  strictValidation
);

fs.writeFileSync('src/components/tabs/Timetable.tsx', content);
console.log("Patched Timetable.tsx with strict validation");
