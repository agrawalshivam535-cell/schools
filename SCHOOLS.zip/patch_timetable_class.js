import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Timetable.tsx', 'utf-8');

code = code.replace(
  "const [className, setClassName] = useState('Class 10 - B');",
  `const [className, setClassName] = useState('');
  
  import { useEffect as UseEffectTimetable } from 'react';
  UseEffectTimetable(() => {
    if (classes.length > 0 && !className) {
      setClassName(classes[0]);
    }
  }, [classes, className]);
`
);

fs.writeFileSync('src/components/tabs/Timetable.tsx', code);
console.log('Patched timetable');
