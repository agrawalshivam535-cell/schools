const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');
content = content.replace(/catch \(e: any\) {\n      if \(e\.message !== 'fetch failed' && e\.code !== 'ETIMEDOUT'\) {\n        console\.error\("Polling error", e\);\n      }\n    }/, `catch (e: any) {
      if (!e.message?.includes('fetch failed') && e.code !== 'ETIMEDOUT' && e.code !== 'ENOTFOUND') {
        console.error("Polling error", e.message);
      }
    }`);
fs.writeFileSync('server.ts', content);
