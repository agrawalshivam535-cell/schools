const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

// Replace Header
content = content.replace(
  `<th className="p-4 text-gray-400 font-medium">Paid Months</th>\\n`,
  ``
);

// Replace Table Data cell
content = content.replace(
  `<td className="p-4 text-indigo-300 text-sm">{s.paidMonths?.join(', ') || '-'}</td>\\n`,
  ``
);

fs.writeFileSync('src/components/tabs/Fees.tsx', content);
console.log("Patched Fees.tsx");
