const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Add maxMarks state
content = content.replace(
  "const [selectedExam, setSelectedExam] = useState('Unit Test 1');",
  "const [selectedExam, setSelectedExam] = useState('Unit Test 1');\n  const [maxMarks, setMaxMarks] = useState<number>(100);"
);

// 2. Update handleMarkChange
const markRx = /const handleMarkChange = \(id: string, subject: keyof StudentMarks, value: string\) => \{\s*\/\/ Only allow empty or numbers\s*if \(value !== '' && !\/^\d\+\$\/\.test\(value\)\) return;\s*setStudents\(students\.map\(s => \{\s*if \(s\.id === id\) \{\s*return \{ \.\.\.s, \[subject\]: value \};\s*\}\s*return s;\s*\}\)\);\s*\};/m;
const newMark = `const handleMarkChange = (id: string, subject: keyof StudentMarks, value: string) => {
    // Only allow empty or numbers
    if (value !== '' && !/^\\d+$/.test(value)) return;
    
    if (value !== '') {
      const num = parseInt(value, 10);
      if (num > maxMarks) {
        alert(\`Maximum marks allowed is \${maxMarks}\`);
        return;
      }
    }

    setStudents(students.map(s => {
      if (s.id === id) {
        return { ...s, [subject]: value };
      }
      return s;
    }));
  };`;
content = content.replace(markRx, newMark);

// 3. Add maxMarks dropdown in UI
const uiRx = /<div className="flex-1 max-w-xs">\s*<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section<\/label>/m;
const newUi = `<div className="w-32">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Max Marks</label>
                <div className="relative">
                  <select
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                    value={maxMarks}
                    onChange={(e) => {
                      setMaxMarks(Number(e.target.value));
                    }}
                  >
                    {[10, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100].map(m => (
                      <option key={m} value={m} className="bg-[#151515]">{m}</option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 max-w-xs">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>`;

content = content.replace(uiRx, newUi);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Max Marks Dropdown');
