const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

const tableStart = `<div className="bg-[#151515] border border-white/5 rounded-2xl overflow-x-auto shadow-xl">
          <table className="w-full text-left min-w-[800px]">`;

const tableEnd = `          </table>
        </div>`;

const startIndex = content.indexOf(tableStart);
if (startIndex !== -1) {
  const endIndex = content.indexOf(tableEnd, startIndex) + tableEnd.length;
  
  const cardCode = `        <div>
          {classStudents.length === 0 ? (
            <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No students found in this class.</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {classStudents.map((student) => (
                <div 
                  key={student.id} 
                  className={\`bg-[#151515] border \${selectedIds.includes(student.id) ? 'border-indigo-500 shadow-lg shadow-indigo-500/10' : 'border-white/5 hover:border-white/10'} rounded-2xl overflow-hidden transition-all group flex flex-col\`}
                >
                  <div className="p-5 relative flex-1">
                    {isBulkMode && (
                      <div className="absolute top-4 left-4 z-10">
                        <input 
                          type="checkbox" 
                          className="w-4 h-4 rounded border-gray-600 bg-black/40 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-gray-900 cursor-pointer"
                          checked={selectedIds.includes(student.id)}
                          onChange={() => toggleSelectStudent(student.id)}
                        />
                      </div>
                    )}
                    
                    <div className="flex flex-col items-center mt-2">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                        <span className="text-2xl font-bold text-indigo-300">
                          {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                        </span>
                      </div>
                      <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{student.name}</h3>
                      <div className="text-xs text-gray-400 mt-1 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                        Roll No: {student.rollNumber}
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                    <span className="text-xs text-gray-400 font-medium px-2">{student.gender || '-'}</span>
                    {!isBulkMode && (
                      <button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
                      >
                        Promote
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>`;
      
  const newContent = content.substring(0, startIndex) + cardCode + content.substring(endIndex);
  fs.writeFileSync('src/components/tabs/ClassSetup.tsx', newContent);
  console.log("Patched ClassSetup.tsx (Students view to Cards)");
} else {
  console.log("Could not find table code block in ClassSetup.tsx");
}
