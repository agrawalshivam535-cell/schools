const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const targetUI = `          if (res.ok) {
            const data = await res.json();
            alert(\`Successfully enrolled \${data.added} students.\`);
            fetchStudents();
          } else {`;
          
const replacementUI = `          if (res.ok) {
            const data = await res.json();
            alert(\`Successfully enrolled \${data.added} new students and updated \${data.updated || 0} existing students.\`);
            fetchStudents();
          } else {`;
          
code = code.replace(targetUI, replacementUI);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched Students.tsx with CSV UI message");
