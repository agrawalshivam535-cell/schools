const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Remove it from Student Results
const resultsRx = /<div className="w-32">\s*<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Max Marks<\/label>[\s\S]*?<\/div>\s*<\/div>\s*<\/div>\s*<div className="flex-1 max-w-xs">\s*<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section<\/label>/m;
content = content.replace(resultsRx, '<div className="flex-1 max-w-xs">\n                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>');

// 2. Add it to Enter Marks
const enterMarksRx = /<div className="flex-1 max-w-xs">\s*<label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section<\/label>\s*<div className="flex gap-2">\s*<div className="relative flex-1">\s*<select\s*className="w-full bg-black\/40 border border-white\/10 rounded-lg px-4 py-2\.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"\s*value=\{enterClass\}/m;

const newEnterMarksUI = `<div className="w-32">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Max Marks</label>
                <div className="relative">
                  <select
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                    value={maxMarks}
                    onChange={(e) => {
                      setMaxMarks(Number(e.target.value));
                    }}
                  >
                    {[10, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100].map(m => (
                      <option key={m} value={m} className="bg-[#151515]">{m}</option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                  </div>
                </div>
              </div>

              <div className="flex-1 max-w-xs">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Select Class & Section</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <select
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                      value={enterClass}`;

content = content.replace(enterMarksRx, newEnterMarksUI);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Fixed Max Marks Dropdown position');
