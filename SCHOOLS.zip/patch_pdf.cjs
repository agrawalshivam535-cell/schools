const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const targetSingle = `  const downloadMarksResult = (exam: any, student: any, action: 'download' | 'preview' = 'download') => {
    if (action === "preview") {
      setPreviewData({ type: 'single', data: exam, student });
      return;
    }
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Examination Result', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, 50);
    
    doc.text("Student Name: " + student.name, 20, 70);
    doc.text("Roll Number: " + student.rollNumber, 20, 80);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 90);
    doc.text("Exam: " + exam.examName, 20, 100);
    
    doc.setLineWidth(0.5);
    doc.line(20, 110, 190, 110);
    
    doc.setFontSize(14);
    doc.text('Subjects', 20, 120);
    doc.text('Marks Obtained', 130, 120);
    
    doc.line(20, 125, 190, 125);
    
    doc.setFontSize(12);
    let y = 135;
    exam.subjects.forEach((subj: any) => {
      doc.text(subj.name, 20, y);
      doc.text(String(subj.obtained), 130, y);
      y += 10;
    });
    
    doc.line(20, y, 190, y);
    y += 10;
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Total", 20, y);
    doc.text(String(exam.obtained) + " / " + String(exam.total), 130, y);

    const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
    let grade = 'F';
    if (Number(percentage) >= 90) grade = 'A+';
    else if (Number(percentage) >= 80) grade = 'A';
    else if (Number(percentage) >= 70) grade = 'B';
    else if (Number(percentage) >= 60) grade = 'C';
    else if (Number(percentage) >= 50) grade = 'D';
    
    y += 10;
    doc.text(\`Percentage: \${percentage}% | Grade: \${grade}\`, 20, y);
    doc.save(\`Result_\${student.rollNumber}_\${exam.examName.replace(/\\s+/g, "_")}.pdf\`);
  };`;

const replacementSingle = `  const buildSinglePDF = (exam: any, student: any) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('SchoolWise', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Examination Result', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, 50);
    
    doc.text("Student Name: " + student.name, 20, 70);
    doc.text("Roll Number: " + student.rollNumber, 20, 80);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 90);
    doc.text("Exam: " + exam.examName, 20, 100);
    
    doc.setLineWidth(0.5);
    doc.line(20, 110, 190, 110);
    
    doc.setFontSize(14);
    doc.text('Subjects', 20, 120);
    doc.text('Marks Obtained', 130, 120);
    
    doc.line(20, 125, 190, 125);
    
    doc.setFontSize(12);
    let y = 135;
    exam.subjects.forEach((subj: any) => {
      doc.text(subj.name, 20, y);
      doc.text(String(subj.obtained), 130, y);
      y += 10;
    });
    
    doc.line(20, y, 190, y);
    y += 10;
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Total", 20, y);
    doc.text(String(exam.obtained) + " / " + String(exam.total), 130, y);

    const percentage = exam.total > 0 ? ((exam.obtained / exam.total) * 100).toFixed(0) : '0';
    let grade = 'F';
    if (Number(percentage) >= 90) grade = 'A+';
    else if (Number(percentage) >= 80) grade = 'A';
    else if (Number(percentage) >= 70) grade = 'B';
    else if (Number(percentage) >= 60) grade = 'C';
    else if (Number(percentage) >= 50) grade = 'D';
    
    y += 10;
    doc.text(\`Percentage: \${percentage}% | Grade: \${grade}\`, 20, y);
    return doc;
  };

  const downloadMarksResult = (exam: any, student: any, action: 'download' | 'preview' = 'download') => {
    if (action === "preview") {
      setPreviewData({ type: 'single', data: exam, student });
      return;
    }
    const doc = buildSinglePDF(exam, student);
    doc.save(\`Result_\${student.rollNumber}_\${exam.examName.replace(/\\s+/g, "_")}.pdf\`);
  };`;

if(content.includes(targetSingle)) {
  content = content.replace(targetSingle, replacementSingle);
  fs.writeFileSync('src/components/tabs/Students.tsx', content);
  console.log("Patched successfully!");
} else {
  console.log("Could not find the target block.");
}
