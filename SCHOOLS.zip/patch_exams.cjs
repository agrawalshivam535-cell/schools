const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf8');

const targetStr = `<PendingVerificationList />`;
const replaceStr = `<PendingVerificationList onVerifySuccess={() => setActiveTab('processed')} />`;

if (code.includes(targetStr)) {
    code = code.replace(targetStr, replaceStr);
    fs.writeFileSync('src/components/tabs/Exams.tsx', code);
    console.log("Patched Exams.tsx");
} else {
    console.log("Not found in Exams.tsx");
}
