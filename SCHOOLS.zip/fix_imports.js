import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

if (!code.includes("ProcessingJobsList")) {
  code = code.replace("import { ProcessedDataList } from './ProcessedDataList';", "import { ProcessedDataList } from './ProcessedDataList';\nimport { ProcessingJobsList } from './ProcessingJobsList';\nimport { PendingVerificationList } from './PendingVerificationList';");
}

code = code.replace("useState<'results' | 'enter' | 'upload' | 'processed'>", "useState<'results' | 'enter' | 'upload' | 'processing' | 'pending' | 'processed'>");

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
