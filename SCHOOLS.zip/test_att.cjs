const fs = require('fs');
let data = JSON.parse(fs.readFileSync('attendance.json', 'utf8'));
let set = new Set(data.map(s => s.id));
if (set.size !== data.length) {
  console.log("Duplicate attendance ID!");
} else {
  console.log("No duplicate attendance ID.");
}
