const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf8');

const targetStr = `<ProcessingJobsList />`;
const replaceStr = `<ProcessingJobsList onJobComplete={() => setActiveTab('pending')} />`;

if (code.includes(targetStr)) {
    code = code.replace(targetStr, replaceStr);
    fs.writeFileSync('src/components/tabs/Exams.tsx', code);
    console.log("Patched Exams.tsx again");
} else {
    console.log("Not found in Exams.tsx");
}
