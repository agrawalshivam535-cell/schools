const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const rxLoadResults = /const loadResults = async \(\) => \{[\s\S]*?    \} catch \(err\) \{[\s\S]*?    \}\n  \};/m;

const newLoadResults = `const loadResults = async () => {
    setIsResultLoaded(false);
    try {
      let res;
      let data;
      
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        let fullClassName = resultClass;
        res = await fetch(\`/api/students?className=\${encodeURIComponent(fullClassName)}\`);
        data = await res.json();
      }
      
      // Process in batches of 10 to avoid overwhelming the server
      const batchSize = 10;
      const studentsWithMarks = [];
      
      for (let i = 0; i < data.length; i += batchSize) {
        const batch = data.slice(i, i + batchSize);
        const batchResults = await Promise.all(batch.map(async (student: any) => {
          const marks = await getStudentMarks(student.id);
          return { ...student, examMarks: marks };
        }));
        studentsWithMarks.push(...batchResults);
      }
      
      setResultStudents(studentsWithMarks);
      setSelectedResults([]);
      setIsResultLoaded(true);
    } catch (err) {
      console.error(err);
    }
  };`;

content = content.replace(rxLoadResults, newLoadResults);
fs.writeFileSync('src/components/tabs/Exams.tsx', content);
