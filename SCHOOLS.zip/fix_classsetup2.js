import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

// Move dynamicClassesList definition to above the useEffect
code = code.replace("  const dynamicClassesList = classes.map(c => c.className + (c.section ? ' - ' + c.section : ''));", "");

code = code.replace(
  "  useEffect(() => {\n    if (classes.length > 0) {",
  "  const dynamicClassesList = classes.map(c => c.className + (c.section ? ' - ' + c.section : ''));\n\n  useEffect(() => {\n    if (classes.length > 0) {"
);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', code);
console.log('Fixed dynamicClassesList order');
