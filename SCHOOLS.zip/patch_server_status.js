import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf-8');

// Update ExamJob interface status type to include 'error' and save job request data
const interfaceRegex = /status: 'processing' \| 'pending_verification';/g;
code = code.replace(interfaceRegex, "status: 'processing' | 'pending_verification' | 'error';\n    requestData?: any;\n    errorMsg?: string;");

// Update /api/exams/jobs/upload to save requestData
const createRegex = /timestamp: new Date\(\)\.toISOString\(\)\s*\};\s*examJobs\.push\(job\);/m;
code = code.replace(createRegex, `timestamp: new Date().toISOString(),\n      requestData: { fileData: req.body.fileData, mimeType: req.body.mimeType }\n    };\n    examJobs.push(job);`);

// Update processAI to handle error and update status
const catchRegex = /\} catch \(err\) \{\s*console\.error\("Background processing error:", err\);\s*\/\* Could set a failed status here, but for now just log it \*\//g;
code = code.replace(catchRegex, `} catch (err: any) {
        console.error("Background processing error:", err);
        const idx = examJobs.findIndex(j => j.id === job.id);
        if (idx !== -1) {
          examJobs[idx].status = 'error';
          examJobs[idx].errorMsg = err.message || "Failed to process document";
          saveDb('examJobs.json', examJobs);
        }`);

// Add a retry endpoint
const retryEndpoint = `
  app.post("/api/exams/jobs/:id/retry", (req, res) => {
    const jobId = req.params.id;
    const jobIndex = examJobs.findIndex(j => j.id === jobId);
    
    if (jobIndex === -1) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    const job = examJobs[jobIndex];
    if (job.status !== 'error') {
      return res.status(400).json({ error: 'Only failed jobs can be retried' });
    }
    
    // Reset status to processing
    examJobs[jobIndex].status = 'processing';
    examJobs[jobIndex].errorMsg = undefined;
    saveDb('examJobs.json', examJobs);
    
    // Restart background processing
    const processAI = async () => {
      try {
        const { fileData, mimeType } = job.requestData || {};
        if (!fileData) throw new Error("Original file data is missing. Cannot retry.");
        
        const prompt = "Class: " + job.className + "\\nSection: " + job.section + "\\nSubject: " + job.subject + "\\nExam: " + job.examType + "\\nTotal: " + job.maxMarks + "\\nExtract rollNumber, name, totalMarks (" + job.maxMarks + "), marksObtained in JSON array. Ensure the properties in the JSON objects are exactly \\"rollNumber\\", \\"name\\", \\"totalMarks\\", \\"marksObtained\\".";
        
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) throw new Error("GEMINI_API_KEY is not set on the server.");

        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [
            { role: 'user', parts: [
              { inlineData: { mimeType: mimeType || 'image/jpeg', data: fileData } },
              { text: prompt }
            ]}
          ],
          config: { responseMimeType: 'application/json' }
        });

        if (!response.text) throw new Error("No response from Gemini");
        const records = JSON.parse(response.text);
        
        const enriched = records.map((r: any) => {
          const studentClass = job.className + ' - ' + job.section;
          const student = students.find(s => 
            String(s.rollNumber) === String(r.rollNumber) && 
            s.className === studentClass
          );
          return {
            id: student ? student.id : (r.id || 'Unknown'),
            rollNumber: r.rollNumber,
            name: student ? student.name : r.name || 'Not Found',
            totalMarks: r.totalMarks || job.maxMarks,
            marksObtained: r.marksObtained,
            previousMarks: null
          };
        });

        const idx = examJobs.findIndex(j => j.id === job.id);
        if (idx !== -1) {
          examJobs[idx].status = 'pending_verification';
          examJobs[idx].records = enriched;
          saveDb('examJobs.json', examJobs);
        }
      } catch (err: any) {
        console.error("Retry background processing error:", err);
        const idx = examJobs.findIndex(j => j.id === job.id);
        if (idx !== -1) {
          examJobs[idx].status = 'error';
          examJobs[idx].errorMsg = err.message || "Failed to process document";
          saveDb('examJobs.json', examJobs);
        }
      }
    };
    
    processAI();
    res.json({ success: true });
  });
`;

code = code.replace(/app\.get\("\/api\/exams\/jobs", \(req, res\) => \{/, retryEndpoint + "\n  app.get(\"/api/exams/jobs\", (req, res) => {");

fs.writeFileSync('server.ts', code);
