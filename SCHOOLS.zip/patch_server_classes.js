import fs from 'fs';
let serverCode = fs.readFileSync('server.ts', 'utf-8');

const classesApiExtra = `
  app.post("/api/classes", (req, res) => {
    classes.push(req.body);
    res.json({ success: true, classes });
  });
  app.put("/api/classes/:id", (req, res) => {
    const idx = classes.findIndex(c => c.id === req.params.id);
    if (idx !== -1) {
      classes[idx] = { ...classes[idx], ...req.body };
      res.json({ success: true, class: classes[idx] });
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });
  app.delete("/api/classes/:id", (req, res) => {
    classes = classes.filter(c => c.id !== req.params.id);
    res.json({ success: true });
  });
`;

serverCode = serverCode.replace('  app.get("/api/students", (req, res) => {', classesApiExtra + '\n  app.get("/api/students", (req, res) => {');

fs.writeFileSync('server.ts', serverCode);
console.log('patched server.ts with extra classes endpoints');
