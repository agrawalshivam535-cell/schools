const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

content = content.replace(
  /\$\{resultClass\.replace\(\/\\s\+\/g\, \'\'\)\}\$\{resultSection\}\.pdf/,
  `\${resultClass.replace(/\\s+/g, '')}\${resultClass === 'All' ? '' : resultSection}.pdf`
);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
