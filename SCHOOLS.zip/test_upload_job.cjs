const fetch = require('node-fetch');

async function run() {
  const fileData = "base64data-would-be-here";
  const res = await fetch('http://localhost:3000/api/exams/jobs/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      filename: 'test.jpg',
      fileData: fileData,
      mimeType: 'image/jpeg',
      className: 'Class 1',
      section: 'A',
      subject: 'Maths',
      examType: 'Unit Test 1',
      maxMarks: '100'
    })
  });
  
  const data = await res.json();
  console.log("Upload response:", data);
  
  if (data.job) {
    let job = data.job;
    while(job.status === 'processing') {
       await new Promise(r => setTimeout(r, 1000));
       const jRes = await fetch('http://localhost:3000/api/exams/jobs');
       const jobs = await jRes.json();
       job = jobs.find(j => j.id === data.job.id);
       console.log("Status:", job.status);
    }
    console.log("Final job:", job);
  }
}
run();
