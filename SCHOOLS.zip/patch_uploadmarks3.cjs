const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

// 1. Add previousMarks to AnalyzedRecord
content = content.replace(
  `  marksObtained: string;`,
  `  marksObtained: string;\n  previousMarks?: string;`
);

// 2. Replace the fetchClassStudents function inside useEffect
const oldFetchClassStudents = `      const fetchClassStudents = async () => {
        try {
          const classNameStr = (recordSource.className || uploadClass) + ' - ' + (recordSource.section || uploadSection);
          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          if (!res.ok) throw new Error('Failed to fetch students');
          const students = await res.json();
          
          const mergedData = students.map((student: any) => {
            const matchedRecord = recordSource.records.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            return {
              id: student.id, // Ensure we use student.id for consistent saving
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (recordSource.maxMarks || uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : ''
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });

          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to fetch students for merging:", err);
          setAnalyzedData(recordSource.records);
        }
      };`;

const newFetchClassStudents = `      const fetchClassStudents = async () => {
        try {
          const classNameOnly = recordSource.className || uploadClass;
          const sectionOnly = recordSource.section || uploadSection;
          const classNameStr = classNameOnly + ' - ' + sectionOnly;
          const subjectStr = recordSource.subject || uploadSubject;
          const examTypeStr = recordSource.examType || uploadExamType;

          const res = await fetch(\`/api/students?className=\${encodeURIComponent(classNameStr)}\`);
          if (!res.ok) throw new Error('Failed to fetch students');
          const students = await res.json();
          
          // Fetch existing marks
          const marksRes = await fetch(\`/api/marks/all?className=\${encodeURIComponent(classNameOnly)}&section=\${encodeURIComponent(sectionOnly)}\`);
          let existingMarks = {};
          if (marksRes.ok) {
             existingMarks = await marksRes.json();
          }

          const mergedData = students.map((student: any) => {
            const matchedRecord = recordSource.records.find((r: any) => String(r.rollNumber) === String(student.rollNumber));
            let prevMarks = '';
            if (existingMarks[student.id]) {
               const studentExams = existingMarks[student.id];
               const specificExam = studentExams.find((e: any) => e.examName === examTypeStr);
               if (specificExam) {
                  const specificSubj = specificExam.subjects.find((s: any) => s.name === subjectStr);
                  if (specificSubj) {
                     prevMarks = specificSubj.obtained;
                  }
               }
            }
            return {
              id: student.id,
              rollNumber: student.rollNumber,
              name: student.name,
              totalMarks: matchedRecord ? matchedRecord.totalMarks : (recordSource.maxMarks || uploadMaxMarks || '100'),
              marksObtained: matchedRecord ? matchedRecord.marksObtained : '',
              previousMarks: prevMarks
            };
          });
          
          mergedData.sort((a: any, b: any) => {
            const numA = parseInt(a.rollNumber, 10);
            const numB = parseInt(b.rollNumber, 10);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return a.rollNumber.localeCompare(b.rollNumber);
          });

          setAnalyzedData(mergedData);
        } catch (err) {
          console.error("Failed to fetch students for merging:", err);
          setAnalyzedData(recordSource.records);
        }
      };`;

content = content.replace(oldFetchClassStudents, newFetchClassStudents);


// 3. Update Table Head
const oldTh = `<th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                  <th className="p-4 whitespace-nowrap">Obtained</th>`;
const newTh = `<th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                  <th className="p-4 whitespace-nowrap">Previous Marks</th>
                  <th className="p-4 whitespace-nowrap">Current Marks</th>`;

content = content.replace(oldTh, newTh);


// 4. Update Table Body
const oldTd = `<td className="p-4 text-gray-300 text-sm">{row.name}</td>
                    <td className="p-4">
                      {isBulkEdit || editingRow === row.id ? (
                        <input
                          type="text"
                          inputMode="numeric"
                          className="w-20 bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm outline-none focus:border-blue-500 transition-colors text-center"
                          value={row.marksObtained}
                          onChange={(e) => handleMarkChange(row.id, e.target.value)}
                        />
                      ) : (
                        <span className="text-white font-bold">{row.marksObtained}</span>
                      )}
                    </td>`;
const newTd = `<td className="p-4 text-gray-300 text-sm">{row.name}</td>
                    <td className="p-4">
                      {row.previousMarks ? (
                         <span className="text-gray-400 font-medium px-2 py-1 bg-white/5 rounded-md border border-white/5">{row.previousMarks}</span>
                      ) : (
                         <span className="text-gray-600 font-medium">-</span>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        {isBulkEdit || editingRow === row.id ? (
                          <input
                            type="text"
                            inputMode="numeric"
                            className={\`w-20 bg-black/40 border rounded-lg px-3 py-1.5 text-sm outline-none focus:border-blue-500 transition-colors text-center \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' ? 'border-amber-500/50 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.2)]' : 'border-white/10 text-white'}\`}
                            value={row.marksObtained}
                            onChange={(e) => handleMarkChange(row.id, e.target.value)}
                          />
                        ) : (
                          <span className={\`font-bold \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' ? 'text-amber-400' : 'text-white'}\`}>{row.marksObtained}</span>
                        )}
                        {row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && (
                           <span className="text-xs text-amber-500 font-medium bg-amber-500/10 px-2 py-1 rounded-md border border-amber-500/20" title="Differs from previous entry">Mismatch</span>
                        )}
                      </div>
                    </td>`;
                    
content = content.replace(oldTd, newTd);

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log("Patched UI and fetch");
