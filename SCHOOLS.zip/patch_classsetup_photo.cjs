const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

const avatarLogic = `<div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                        <span className="text-2xl font-bold text-indigo-300">
                          {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                        </span>
                      </div>`;
const photoLogic = `<div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner overflow-hidden">
                        {student.photo ? (
                          <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-2xl font-bold text-indigo-300">
                            {student.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                          </span>
                        )}
                      </div>`;

content = content.replace(avatarLogic, photoLogic);
fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Patched ClassSetup");
