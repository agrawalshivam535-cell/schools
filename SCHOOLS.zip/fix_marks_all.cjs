const fs = require('fs');

let serverContent = fs.readFileSync('server.ts', 'utf-8');

// 1. Fix /api/marks/all
const marksAllRx = /app\.get\("\/api\/marks\/all", \(req, res\) => \{[\s\S]*?res\.json\(result\);\s*\}\);/m;
const newMarksAll = `app.get("/api/marks/all", (req, res) => {
    const { className, section } = req.query;
    const studentMarksMap: Record<string, any> = {};

    let filteredAnalysis = analysisRecords;
    if (className && className !== 'All Classes' && className !== 'All') {
      const cls = (className as string).split(' - ')[0];
      filteredAnalysis = filteredAnalysis.filter(ar => ar.className === cls);
    }
    if (section && section !== 'All Sections') {
      filteredAnalysis = filteredAnalysis.filter(ar => (ar as any).section === section);
    }

    filteredAnalysis.forEach(ar => {
      (ar as any).records.forEach((rec: any) => {
        const sid = rec.id;
        if (!studentMarksMap[sid]) {
          studentMarksMap[sid] = {};
        }
        const examType = (ar as any).examType;
        if (!studentMarksMap[sid][examType]) {
          studentMarksMap[sid][examType] = { examName: examType, subjectMap: {} };
        }
        
        // This overrides previous entries for the same subject
        studentMarksMap[sid][examType].subjectMap[(ar as any).subject] = {
          obtained: Number(rec.marksObtained) || 0,
          total: Number(rec.totalMarks) || 0
        };
      });
    });

    const result: Record<string, any[]> = {};
    for (const sid in studentMarksMap) {
      result[sid] = Object.values(studentMarksMap[sid]).map(examObj => {
        const subMap = (examObj as any).subjectMap;
        const subjects = Object.keys(subMap).map(name => ({
          name,
          obtained: subMap[name].obtained
        }));
        
        const total = Object.values(subMap).reduce((acc: number, curr: any) => acc + curr.total, 0);
        const obtained = Object.values(subMap).reduce((acc: number, curr: any) => acc + curr.obtained, 0);
        
        return {
          examName: (examObj as any).examName,
          total,
          obtained,
          subjects
        };
      });
    }
    res.json(result);
  });`;
serverContent = serverContent.replace(marksAllRx, newMarksAll);

// 2. Fix /api/students/:id/details to also deduplicate subjects
const studentDetailsRx = /filteredAnalysis\.forEach\(ar => \{[\s\S]*?\}\);/m;
// Let's just find the loop inside /api/students/:id/details
// Actually I need to check how it's implemented. Let me skip details for a second or fix it.
