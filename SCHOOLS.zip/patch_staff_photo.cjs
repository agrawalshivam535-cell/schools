const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/Staff.tsx', 'utf-8');

// 1. Add photo to interface
content = content.replace(
  `status: 'Active' | 'On Leave' | 'Inactive';`,
  `status: 'Active' | 'On Leave' | 'Inactive';\n  photo?: string;`
);

// 2. Add handlePhotoUpload
const saveStaffLogic = `  const handleSaveStaff = async (e: import("react").FormEvent) => {`;
const handlePhotoUploadLogic = `  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image must be smaller than 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (editForm) {
          setEditForm({ ...editForm, photo: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveStaff = async (e: import("react").FormEvent) => {`;
content = content.replace(saveStaffLogic, handlePhotoUploadLogic);

// 3. Form UI
const formTopLogic = `<div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Full Name *</label>`;

const formTopPhotoLogic = `<div className="space-y-6">
              <div className="flex flex-col items-center mb-2">
                <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-dashed border-indigo-500/50 flex items-center justify-center mb-3 relative overflow-hidden group">
                  {editForm.photo ? (
                    <img src={editForm.photo} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-3xl font-bold text-indigo-400">{editForm.name ? editForm.name.charAt(0) : '?'}</span>
                  )}
                  <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                    <span className="text-white text-xs font-bold">Upload</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                  </label>
                </div>
                <div className="text-xs text-gray-500 text-center">Recommended: Square image, max 2MB</div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Full Name *</label>`;
content = content.replace(formTopLogic, formTopPhotoLogic);

// 4. List view avatar
const cardAvatarLogic = `<div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                      <span className="text-2xl font-bold text-indigo-300">
                        {staff.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                      </span>
                    </div>`;
const cardAvatarPhotoLogic = `<div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner overflow-hidden">
                      {staff.photo ? (
                        <img src={staff.photo} alt={staff.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl font-bold text-indigo-300">
                          {staff.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                        </span>
                      )}
                    </div>`;
content = content.replace(cardAvatarLogic, cardAvatarPhotoLogic);

// 5. View Details avatar
const detailAvatarLogic = `<div className="w-24 h-24 bg-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center text-4xl font-extrabold border border-indigo-500/30">
              {viewDetails.name.charAt(0)}
            </div>`;
const detailAvatarPhotoLogic = `<div className="w-24 h-24 bg-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center text-4xl font-extrabold border border-indigo-500/30 overflow-hidden">
              {viewDetails.photo ? (
                <img src={viewDetails.photo} alt={viewDetails.name} className="w-full h-full object-cover" />
              ) : (
                viewDetails.name.charAt(0)
              )}
            </div>`;
content = content.replace(detailAvatarLogic, detailAvatarPhotoLogic);

fs.writeFileSync('src/components/tabs/Staff.tsx', content);
console.log("Patched Staff");
