import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const interfaceAdd = `
export interface ProcessedRecord {
  id: string;
  className: string;
  section: string;
  subject: string;
  examType: string;
  timestamp: string;
  records: AnalyzedRecord[];
}

interface UploadMarksProps {
  initialRecord?: ProcessedRecord;
  onBack?: () => void;
}
`;

code = code.replace("export function UploadMarks() {", interfaceAdd + "\nexport function UploadMarks({ initialRecord, onBack }: UploadMarksProps = {}) {");

const stateInit = `
  const [uploadClass, setUploadClass] = useState(initialRecord?.className || '');
  const [uploadSection, setUploadSection] = useState(initialRecord?.section || '');
  const [uploadSubject, setUploadSubject] = useState(initialRecord?.subject || 'Maths');
  const [uploadExamType, setUploadExamType] = useState(initialRecord?.examType || 'Unit Test 1');
  const [uploadMaxMarks, setUploadMaxMarks] = useState(initialRecord?.records?.[0]?.totalMarks || '100');
  
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [analyzedData, setAnalyzedData] = useState<AnalyzedRecord[] | null>(initialRecord?.records || null);
`;

code = code.replace(/const \[uploadClass[\s\S]*?const \[analyzedData, setAnalyzedData\] = useState<AnalyzedRecord\[\] \| null>\(null\);/m, stateInit.trim());

const updateSave = `
    try {
      if (initialRecord) {
        await fetch('/api/exams/analysis/' + initialRecord.id, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData
          })
        });
      } else {
        await fetch('/api/exams/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: {
              q1: uploadClass,
              q2: uploadSection,
              q3: uploadSubject,
              q4: uploadExamType,
              q5: uploadMaxMarks
            },
            records: analyzedData
          })
        });
      }
      setIsSaving(false);
      setIsSaved(true);
      setTimeout(() => {
        setIsSaved(false);
        if (onBack) onBack();
      }, 1500);
    }
`;

code = code.replace(/try \{\s*await fetch\('\/api\/exams\/save'[\s\S]*?setTimeout\(\(\) => setIsSaved\(false\), 3000\);\s*\}/m, updateSave.trim());

// Add back button support if initialRecord exists
const backBtn = `
      <div className="flex flex-col xl:flex-row gap-6 mb-8">
        {onBack && (
          <div className="w-full mb-2">
             <button onClick={onBack} className="text-gray-400 hover:text-white flex items-center gap-2 mb-2 transition-colors">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
               Back to Processed Data
             </button>
          </div>
        )}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
`;
code = code.replace('<div className="flex flex-col xl:flex-row gap-6 mb-8">\n        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">', backBtn.trim());

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
