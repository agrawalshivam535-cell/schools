const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

// Add actionType state
content = content.replace(
  `const [selectivePromoteModal, setSelectivePromoteModal] = useState(false);`,
  `const [selectivePromoteModal, setSelectivePromoteModal] = useState(false);\n  const [actionType, setActionType] = useState<'promote' | 'demote' | 'reassign'>('promote');`
);

// Update single promote click
content = content.replace(
  `const handleSinglePromoteClick = (studentId: string, e: any) => {
    e.stopPropagation();
    setSelectedIds([studentId]);
    setSelectivePromoteModal(true);
  };`,
  `const handleSinglePromoteClick = (studentId: string, e: any, type: 'promote' | 'demote' = 'promote') => {
    e.stopPropagation();
    setSelectedIds([studentId]);
    setActionType(type);
    setSelectivePromoteModal(true);
  };`
);

// Add Demote button next to Promote
content = content.replace(
  `<button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
                      >
                        Promote
                      </button>`,
  `<button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e, 'promote')}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
                      >
                        Promote
                      </button>
                      <button 
                        onClick={(e) => handleSinglePromoteClick(student.id, e, 'demote')}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        Demote
                      </button>`
);

// Update bulk promote button
content = content.replace(
  `<ArrowUpRight size={18} /> Promote Selected ({selectedIds.length})`,
  `<ArrowUpRight size={18} /> Reassign Selected ({selectedIds.length})`
);

// Update bulk promote click to set actionType to reassign
content = content.replace(
  `onClick={() => setSelectivePromoteModal(true)}`,
  `onClick={() => { setActionType('reassign'); setSelectivePromoteModal(true); }}`
);

// Update modal title and descriptions for selective
content = content.replace(
  `<h3 className="text-xl font-bold text-white mb-6">Promote Selected Students</h3>
              <p className="text-sm text-gray-400 mb-6">You are about to promote {selectedIds.length} student(s) to a new class.</p>`,
  `<h3 className="text-xl font-bold text-white mb-6">
                {actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign'} Selected Students
              </h3>
              <p className="text-sm text-gray-400 mb-6">
                You are about to {actionType === 'promote' ? 'promote' : actionType === 'demote' ? 'demote' : 'reassign'} {selectedIds.length} student(s) to a new class.
              </p>`
);

content = content.replace(
  `<label className="block text-sm font-medium text-gray-400 mb-2">Promote To Class</label>`,
  `<label className="block text-sm font-medium text-gray-400 mb-2">
                    {actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign'} To Class
                  </label>`
);

content = content.replace(
  `{isPromoting ? 'Promoting...' : 'Promote'}`,
  `{isPromoting ? 'Processing...' : (actionType === 'promote' ? 'Promote' : actionType === 'demote' ? 'Demote' : 'Reassign')}`
);

// Update main Bulk Promote button (for whole classes)
content = content.replace(
  `<ArrowUpRight size={18} /> Bulk Promote`,
  `<ArrowUpRight size={18} /> Bulk Reassign`
);

content = content.replace(
  `<h3 className="text-xl font-bold text-white mb-6">Bulk Promote Students</h3>`,
  `<h3 className="text-xl font-bold text-white mb-6">Bulk Reassign Students</h3>`
);

content = content.replace(
  `<label className="block text-sm font-medium text-gray-400 mb-2">Promote To</label>`,
  `<label className="block text-sm font-medium text-gray-400 mb-2">Reassign To</label>`
);

// There might be a second Promoting... : Promote check
content = content.replace(
  `{isPromoting ? 'Promoting...' : 'Promote'}`,
  `{isPromoting ? 'Processing...' : 'Confirm Reassign'}`
);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Patched ClassSetup.tsx");
