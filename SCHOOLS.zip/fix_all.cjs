const fs = require('fs');

function fixFile(file, idField = 'id') {
  if (!fs.existsSync(file)) return;
  let data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  let seen = new Set();
  let newData = [];
  let fixed = false;
  
  for (let s of data) {
    let key = s[idField];
    if (!key) {
       key = 'gen_' + Date.now() + Math.floor(Math.random()*1000);
       s[idField] = key;
       fixed = true;
    }
    if (!seen.has(key)) {
      seen.add(key);
      newData.push(s);
    } else {
      let newKey = 'dup_' + Date.now() + Math.floor(Math.random()*1000);
      s[idField] = newKey;
      seen.add(newKey);
      newData.push(s);
      fixed = true;
    }
  }
  
  if (fixed) {
    fs.writeFileSync(file, JSON.stringify(newData, null, 2));
    console.log(`Fixed duplicates in ${file}`);
  } else {
    console.log(`No duplicates in ${file}`);
  }
}

fixFile('classes.json');
fixFile('staff.json');
fixFile('feePayments.json');
fixFile('analysis.json'); // Might use something else as ID? Let's check
