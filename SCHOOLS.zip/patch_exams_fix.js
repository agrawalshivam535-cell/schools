import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

code = code.replace(
  "              </div>\n            )}\n          </div>\n        ) : (\n          <div>\n            <h2 className=\"text-xl font-medium text-white mb-6\">Enter Marks</h2>",
  "              </div>\n            )}\n          </div>\n        ) : activeTab === 'enter' ? (\n          <div>\n            <h2 className=\"text-xl font-medium text-white mb-6\">Enter Marks</h2>"
);

// We also need to close the `) : null` at the end of Enter Marks.
// Currently it is:
//             )}
//           </div>
//         )}
//         {activeTab === 'processed' && (
//           <ProcessedDataList />
//         )}
//       </div>
//     </div>
//   );
// }

code = code.replace(
  "            )}\n          </div>\n        )}\n        {activeTab === 'processed' && (\n          <ProcessedDataList />\n        )}",
  "            )}\n          </div>\n        ) : null}\n        {activeTab === 'processed' && (\n          <ProcessedDataList />\n        )}"
);

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
