const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Add state
const rxState = /const \[sendingTelegramId, setSendingTelegramId\] = useState<string \| null>\(null\);/m;
const newState = `const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);
  const [isSendingBulk, setIsSendingBulk] = useState(false);`;
content = content.replace(rxState, newState);

// 2. Add bulk send function
const rxBulkDown = /const downloadBulkResults = async \(\) => \{/m;
const bulkTelegramFunc = `const sendBulkTelegramResults = async () => {
    if (selectedResults.length === 0) return;
    setIsSendingBulk(true);
    let successCount = 0;
    let failCount = 0;

    for (const id of selectedResults) {
      const student = resultStudents.find(s => s.id === id);
      if (!student) continue;

      try {
        let marks = student.examMarks || await getStudentMarks(id);
        if (resultExamType !== 'Full Result') {
          marks = marks.filter((m: any) => m.examName === resultExamType);
        }

        let message = \`*Academic Report - \${student.name}*\\nRoll No: \${student.rollNumber}\\nClass: \${student.className} \${student.section ? '- ' + student.section : ''}\\n\\n\`;
        
        marks.forEach((exam: any) => {
          if (exam.isBlank) return;
          message += \`*\${exam.examName}*\\n\`;
          exam.subjects.forEach((subj: any) => {
            message += \`\${subj.name}: \${subj.obtained}\\n\`;
          });
          message += \`Total: \${exam.obtained}/\${exam.total}\\n\\n\`;
        });

        const phone = student.parentPhone || '';
        const cleanPhone = phone.replace(/[^0-9+]/g, '');
        const defaultChatId = student.telegramChatId || cleanPhone;
        
        if (!defaultChatId) {
          failCount++;
          continue;
        }

        const doc = buildPDF(marks, student, resultExamType);
        const pdfBase64 = doc.output('datauristring').split(',')[1];
        
        const res = await fetch('/api/telegram/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chatId: defaultChatId,
            message,
            pdfBase64
          })
        });

        const data = await res.json();
        if (data.success) {
          successCount++;
        } else {
          failCount++;
        }
      } catch (err) {
        failCount++;
      }
    }

    setIsSendingBulk(false);
    alert(\`Bulk Telegram Send Complete.\\nSuccessfully sent: \${successCount}\\nFailed or missing Contact: \${failCount}\`);
  };

  const downloadBulkResults = async () => {`;
content = content.replace(rxBulkDown, bulkTelegramFunc);

// 3. Add UI button
const rxUIBtn = /\{isResultLoaded && resultStudents\.length > 0 && \(\s*<button\s*onClick=\{downloadBulkResults\}/m;
const newUIBtn = `{isResultLoaded && resultStudents.length > 0 && (
                <div className="flex items-center gap-3">
                  <button
                    onClick={sendBulkTelegramResults}
                    disabled={selectedResults.length === 0 || isSendingBulk || isDownloading}
                    className="bg-[#229ED9] hover:bg-[#1CA0DE] disabled:opacity-50 text-white text-sm font-bold px-6 py-2.5 rounded-lg transition-colors shadow-lg flex items-center gap-2"
                  >
                    {isSendingBulk ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                    {isSendingBulk ? 'Sending...' : \`Send Telegram (\${selectedResults.length})\`}
                  </button>
                  <button
                    onClick={downloadBulkResults}`;
content = content.replace(rxUIBtn, newUIBtn);

const rxUIBtnEnd = /\{isDownloading \? 'Downloading\.\.\.' : \`Download Selected \(\$\{selectedResults\.length\}\)\`\}\s*<\/button>\s*\)\}/m;
const newUIBtnEnd = `{isDownloading ? 'Downloading...' : \`Download Selected (\${selectedResults.length})\`}
                  </button>
                </div>
              )}`;
content = content.replace(rxUIBtnEnd, newUIBtnEnd);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Exams.tsx with sendBulkTelegramResults');
