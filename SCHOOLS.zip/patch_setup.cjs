const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const oldSetup = `      const host = req.headers.host;
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
      const webhookUrl = \`\${protocol}://\${host}/api/telegram/webhook\`;`;

const newSetup = `      const host = req.headers['x-forwarded-host'] || req.headers.host;
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
      
      // Force HTTPS if not localhost
      const finalProtocol = host.includes('localhost') ? protocol : 'https';
      const webhookUrl = \`\${finalProtocol}://\${host}/api/telegram/webhook\`;`;

content = content.replace(oldSetup, newSetup);
fs.writeFileSync('server.ts', content);
console.log("Patched setup");
