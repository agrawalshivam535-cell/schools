const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/PendingVerificationList.tsx', 'utf8');

const targetStr = `export function PendingVerificationList() {`;
const replaceStr = `interface PendingVerificationListProps {
  onVerifySuccess?: () => void;
}
export function PendingVerificationList({ onVerifySuccess }: PendingVerificationListProps = {}) {`;

code = code.replace(targetStr, replaceStr);

const targetStr2 = `    return <UploadMarks pendingJob={selectedJob} onBack={() => { setSelectedJob(null); fetchJobs(); }} />`;
const replaceStr2 = `    return <UploadMarks pendingJob={selectedJob} onBack={() => { 
      setSelectedJob(null); 
      fetchJobs(); 
      if (onVerifySuccess) onVerifySuccess(); 
    }} />`;

code = code.replace(targetStr2, replaceStr2);

fs.writeFileSync('src/components/tabs/PendingVerificationList.tsx', code);
console.log("Patched PendingVerificationList.tsx");
