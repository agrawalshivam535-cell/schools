const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

content = content.replace(
  `{!isBulkMode && (
                      <button`,
  `{!isBulkMode && (
                      <>
                      <button`
);

content = content.replace(
  `Demote
                      </button>
                    )}`,
  `Demote
                      </button>
                      </>
                    )}`
);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Fixed JSX syntax in ClassSetup.tsx");
