const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

content = content.replace(
  "Status: ${fees.status}\\nTotal Fee",
  "Paid Month: ${fees.status}\\nTotal Fee"
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
