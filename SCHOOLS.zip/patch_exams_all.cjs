const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

// 1. Initial effect - we remove resultSection setting or keep it as is, but we will initialize resultClass to "All"
content = content.replace(
  /if \(\!resultClass\) setResultClass\(cls\);\n\s*if \(\!resultSection\) setResultSection\(sec\);/m,
  `if (!resultClass) setResultClass('All');\n      if (!resultSection) setResultSection(sec);`
);

// 2. Dropdown UI - add "All" option
const rxDropdown = /<select\s+className="w-full bg-black\/40 border border-white\/10 rounded-lg px-4 py-2\.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"\s+value=\{resultClass\}\s+onChange=\{\(e\) => \{\s+setResultClass\(e\.target\.value\);\s+setIsResultLoaded\(false\);\s+\}\}\s+>\s*\{classes\.map\(c => \(\s*<option key=\{c\} value=\{c\} className="bg-\[#151515\]">\{c\}<\/option>\s*\)\)\}\s*<\/select>/m;

const newDropdown = `<select
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer"
                        value={resultClass}
                        onChange={(e) => {
                          setResultClass(e.target.value);
                          setIsResultLoaded(false);
                        }}
                      >
                        <option value="All" className="bg-[#151515]">All Classes</option>
                        {classes.map(c => (
                          <option key={c} value={c} className="bg-[#151515]">{c}</option>
                        ))}
                      </select>`;

content = content.replace(rxDropdown, newDropdown);

// 3. update loadResults logic
const rxLoadResults = /const loadResults = async \(\) => \{[\s\S]*?    \} catch \(err\) \{[\s\S]*?    \}\n  \};/m;

const newLoadResults = `const loadResults = async () => {
    setIsResultLoaded(false);
    try {
      let res;
      let data;
      
      if (resultClass === 'All' || !resultClass) {
        res = await fetch('/api/students');
        data = await res.json();
      } else {
        // resultClass is something like "Class 1 - A"
        let fullClassName = resultClass;
        // In the backend, className is stored as "Class 1 - A"
        res = await fetch(\`/api/students?className=\${encodeURIComponent(fullClassName)}\`);
        data = await res.json();
        
        // Ensure filtering by section if needed, but backend handles it via className anyway
        // Wait, backend matches exactly if passed as className query
      }
      
      const studentsWithMarks = await Promise.all(data.map(async (student: any) => {
        const marks = await getStudentMarks(student.id);
        return { ...student, examMarks: marks };
      }));
      
      setResultStudents(studentsWithMarks);
      setSelectedResults([]);
      setIsResultLoaded(true);
    } catch (err) {
      console.error(err);
    }
  };`;

content = content.replace(rxLoadResults, newLoadResults);

fs.writeFileSync('src/components/tabs/Exams.tsx', content);
console.log('Patched Exams.tsx for "All Classes" results fetching');
