import fs from 'fs';
let serverCode = fs.readFileSync('server.ts', 'utf-8');

serverCode = serverCode.replace(
  `feesCollected: "$12,400",
      feesPending: "$1,200"`,
  `// compute fees
      feesCollected: "$" + feePayments.reduce((acc, curr) => acc + curr.payments.reduce((a, p) => a + Number(p.amount), 0), 0).toLocaleString(),
      feesPending: "$" + students.reduce((acc, s) => {
         const struct = feeStructures.find(f => f.className === s.className && f.section === s.section);
         const totalFee = struct?.items?.reduce((a, c) => a + Number(c.amount), 0) || 2200;
         const paid = feePayments.find(p => p.id === s.id)?.payments.reduce((a, c) => a + Number(c.amount), 0) || 0;
         return acc + Math.max(0, totalFee - paid);
      }, 0).toLocaleString()`
);

fs.writeFileSync('server.ts', serverCode);
console.log('patched dashboard fees');
