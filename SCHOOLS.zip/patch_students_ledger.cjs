const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// 1. Add the functions above sendTelegramResult
const functionsRx = /const sendTelegramResult = async \(exam: any, student: any\) => \{/m;

const ledgerFunctions = `
  const buildFeeLedgerPDF = (student: any, fees: any) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('EduAI SaaS', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Comprehensive Fee Ledger', 105, 30, { align: 'center' });

    doc.setFontSize(12);
    doc.text("Date: " + new Date().toLocaleDateString(), 20, 50);
    doc.text("Student Name: " + student.name, 20, 60);
    doc.text("Roll Number: " + student.rollNumber, 20, 70);
    doc.text("Class: " + student.className + (student.section ? " - " + student.section : ""), 20, 80);
    
    doc.setLineWidth(0.5);
    doc.line(20, 90, 190, 90);
    
    // Summary
    doc.setFontSize(14);
    doc.text("Summary:", 20, 100);
    doc.setFontSize(12);
    doc.text("Total Fee: Rs. " + fees.totalFee.toFixed(2), 30, 110);
    doc.text("Total Paid: Rs. " + fees.paidAmount.toFixed(2), 30, 120);
    doc.text("Balance Due: Rs. " + fees.balance.toFixed(2), 30, 130);
    
    doc.line(20, 140, 190, 140);
    
    // Payments Table
    doc.setFontSize(14);
    doc.text("Payment History:", 20, 150);
    doc.setFontSize(12);
    
    let y = 160;
    if (!fees.payments || fees.payments.length === 0) {
      doc.text("No payments recorded.", 30, y);
    } else {
      doc.setFont(undefined, 'bold');
      doc.text("Date", 20, y);
      doc.text("Amount", 70, y);
      doc.text("Method", 120, y);
      doc.setFont(undefined, 'normal');
      y += 10;
      
      fees.payments.forEach((p: any) => {
        doc.text(new Date(p.date).toLocaleDateString(), 20, y);
        doc.text("Rs. " + p.amount, 70, y);
        doc.text(p.method || 'Online', 120, y);
        y += 10;
        if (y > 270) {
          doc.addPage();
          y = 20;
        }
      });
    }
    
    return doc;
  };

  const downloadFeeLedger = (student: any, fees: any) => {
    const doc = buildFeeLedgerPDF(student, fees);
    doc.save(\`FeeLedger_\${student.rollNumber}_\${new Date().getTime()}.pdf\`);
  };

  const sendFeeLedgerTelegram = async (student: any, fees: any) => {
    setSendingTelegramId('ledger');
    try {
      const phone = student.parentPhone || '';
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      const defaultChatId = student.telegramChatId || cleanPhone;
      
      if (!defaultChatId) {
        alert('No Telegram Chat ID or phone number available for this student.');
        setSendingTelegramId(null);
        return;
      }

      const doc = buildFeeLedgerPDF(student, fees);
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      
      const message = \`*Comprehensive Fee Ledger*\\nStudent: \${student.name}\\nRoll No: \${student.rollNumber}\\n\\nTotal Fee: Rs. \${fees.totalFee}\\nPaid: Rs. \${fees.paidAmount}\\nBalance: Rs. \${fees.balance}\\n\\nPlease find the attached detailed ledger.\`;
      
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: defaultChatId,
          message,
          pdfBase64
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Fee Ledger sent successfully to ' + student.name);
      } else {
        alert(\`Failed to send fee ledger: \${data.message}\`);
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while sending the fee ledger.');
    } finally {
      setSendingTelegramId(null);
    }
  };

  const sendTelegramResult = async (exam: any, student: any) => {`;

content = content.replace(functionsRx, ledgerFunctions);

// 2. Replace the UI
const uiRx = /<div className="flex justify-between items-center">\s*<h3 className="text-lg font-bold text-white">Fee Ledger & Summary<\/h3>\s*<button \s*onClick=\{\(\) => setPaymentForm\(\{ amount: '', method: 'Online', remarks: '' \}\)\}\s*className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors"\s*>\s*<Plus size=\{16\} \/> Record Payment\s*<\/button>\s*<\/div>/m;

const newUI = `<div className="flex justify-between items-center flex-wrap gap-4">
                <h3 className="text-lg font-bold text-white">Fee Ledger & Summary</h3>
                <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                  <button 
                    onClick={() => downloadFeeLedger(selectedStudent, fees)}
                    className="bg-white/10 hover:bg-white/20 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors"
                  >
                    <Download size={16} /> <span className="hidden sm:inline">Download Ledger</span><span className="sm:hidden">Download</span>
                  </button>
                  <button 
                    onClick={() => sendFeeLedgerTelegram(selectedStudent, fees)}
                    disabled={sendingTelegramId === 'ledger'}
                    className="bg-[#229ED9]/10 hover:bg-[#229ED9]/20 border border-[#229ED9]/30 text-[#229ED9] px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    {sendingTelegramId === 'ledger' ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} <span className="hidden sm:inline">Send Ledger</span><span className="sm:hidden">Send</span>
                  </button>
                  <button 
                    onClick={() => setPaymentForm({ amount: '', method: 'Online', remarks: '' })}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors"
                  >
                    <Plus size={16} /> Record Payment
                  </button>
                </div>
              </div>`;

content = content.replace(uiRx, newUI);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log('Patched ledger buttons');
