const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

// 1. Add resolvedMismatch to interface
content = content.replace(
  `previousMarks?: string;`,
  `previousMarks?: string;\n  resolvedMismatch?: boolean;`
);

// 2. Add helper functions
const funcs = `
  const handleKeepOld = (id?: string) => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if ((id === undefined || row.id === id) && row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '') {
        return { ...row, marksObtained: row.previousMarks, resolvedMismatch: true };
      }
      return row;
    }));
  };

  const handleKeepNew = (id?: string) => {
    if (!analyzedData) return;
    setAnalyzedData(analyzedData.map(row => {
      if ((id === undefined || row.id === id) && row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '') {
        return { ...row, resolvedMismatch: true };
      }
      return row;
    }));
  };

  const conflictsCount = analyzedData?.filter(row => row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && !row.resolvedMismatch).length || 0;
`;

// Insert the functions right before handleRemap
content = content.replace(
  `  const handleRemap = async () => {`,
  funcs + `\n  const handleRemap = async () => {`
);

// 3. Add global banner above the table
const globalBanner = `
          {conflictsCount > 0 && (
            <div className="mb-4 bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3 text-amber-400">
                <span className="text-xl">⚠️</span>
                <div>
                  <p className="font-bold">Found {conflictsCount} Mismatch{conflictsCount !== 1 ? 'es' : ''}</p>
                  <p className="text-sm opacity-80">Some uploaded marks differ from previously saved data.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleKeepOld()} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-lg transition-colors border border-white/10">Keep All Old</button>
                <button onClick={() => handleKeepNew()} className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-lg">Keep All New</button>
              </div>
            </div>
          )}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0a0a] mb-6">`;

content = content.replace(
  `<div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0a0a] mb-6">`,
  globalBanner
);


// 4. Update the row rendering
const oldRowRendering = `{row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && (
                           <span className="text-xs text-amber-500 font-medium bg-amber-500/10 px-2 py-1 rounded-md border border-amber-500/20" title="Differs from previous entry">Mismatch</span>
                        )}`;
const newRowRendering = `{row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && !row.resolvedMismatch && (
                           <div className="flex flex-col gap-1 ml-2">
                             <span className="text-[10px] text-amber-500 font-bold uppercase tracking-wider bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20 w-max" title="Differs from previous entry">Mismatch</span>
                             <div className="flex gap-1">
                               <button onClick={() => handleKeepOld(row.id)} className="text-[10px] bg-white/10 hover:bg-white/20 text-white px-1.5 py-0.5 rounded transition-colors whitespace-nowrap">Keep Old</button>
                               <button onClick={() => handleKeepNew(row.id)} className="text-[10px] bg-amber-600/50 hover:bg-amber-600 text-white px-1.5 py-0.5 rounded transition-colors whitespace-nowrap">Keep New</button>
                             </div>
                           </div>
                        )}`;
content = content.replace(oldRowRendering, newRowRendering);


// Update border styling to check resolvedMismatch
const oldBorder1 = `className={\`w-20 bg-black/40 border rounded-lg px-3 py-1.5 text-sm outline-none focus:border-blue-500 transition-colors text-center \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' ? 'border-amber-500/50 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.2)]' : 'border-white/10 text-white'}\`}`;
const newBorder1 = `className={\`w-20 bg-black/40 border rounded-lg px-3 py-1.5 text-sm outline-none focus:border-blue-500 transition-colors text-center \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && !row.resolvedMismatch ? 'border-amber-500/50 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.2)]' : 'border-white/10 text-white'}\`}`;
content = content.replace(oldBorder1, newBorder1);

const oldBorder2 = `className={\`font-bold \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' ? 'text-amber-400' : 'text-white'}\`}`;
const newBorder2 = `className={\`font-bold \${row.previousMarks && row.previousMarks !== row.marksObtained && row.marksObtained !== '' && !row.resolvedMismatch ? 'text-amber-400' : 'text-white'}\`}`;
content = content.replace(oldBorder2, newBorder2);


fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log("Patched buttons");
