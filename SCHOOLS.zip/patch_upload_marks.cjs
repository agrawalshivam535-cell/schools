const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const uploadMarkRx = /const handleMarkChange = \(id: string, value: string\) => \{\s*if \(!analyzedData\) return;\s*const newData = \[\.\.\.analyzedData\];\s*const index = newData\.findIndex\(r => r\.id === id\);\s*if \(index !== -1\) \{\s*newData\[index\]\.marksObtained = value;\s*setAnalyzedData\(newData\);\s*\}\s*\};/m;

const newUploadMark = `const handleMarkChange = (id: string, value: string) => {
    if (!analyzedData) return;
    
    // Only allow empty or numbers
    if (value !== '' && !/^\\d+$/.test(value)) return;
    
    if (value !== '') {
      const num = parseInt(value, 10);
      let maxMarks = 100;
      const lowerExam = uploadExam.toLowerCase();
      if (lowerExam.includes('unit test')) maxMarks = 25;
      else if (lowerExam.includes('mid-year') || lowerExam.includes('mid term')) maxMarks = 50;
      else if (lowerExam.includes('annual') || lowerExam.includes('final')) maxMarks = 100;
      
      if (num > maxMarks) {
        alert(\`Maximum marks for \${uploadExam} is \${maxMarks}\`);
        return;
      }
    }

    const newData = [...analyzedData];
    const index = newData.findIndex(r => r.id === id);
    if (index !== -1) {
      newData[index].marksObtained = value;
      setAnalyzedData(newData);
    }
  };`;

content = content.replace(uploadMarkRx, newUploadMark);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log('Patched UploadMarks.tsx');
