import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const newNav = `        <div className="flex gap-6 border-b border-white/10 mb-8 overflow-x-auto whitespace-nowrap scrollbar-hide">
          <button
            onClick={() => setActiveTab('results')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'results' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Results
            {activeTab === 'results' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('enter')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'enter' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Enter Marks
            {activeTab === 'enter' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'upload' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Upload
            {activeTab === 'upload' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('processing')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'processing' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Processing
            {activeTab === 'processing' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'pending' ? 'text-amber-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Pending Verification
            {activeTab === 'pending' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-amber-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('processed')}
            className={\`pb-4 text-sm font-medium transition-colors relative \${
              activeTab === 'processed' ? 'text-blue-500' : 'text-gray-400 hover:text-gray-300'
            }\`}
          >
            Verified Data
            {activeTab === 'processed' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-blue-500" />
            )}
          </button>
        </div>`;

// Replace nav
code = code.replace(/<div className="flex gap-6 border-b border-white\/10 mb-8">[\s\S]*?<\/div>\s*\{activeTab === 'upload'/m, newNav + "\n\n        {activeTab === 'upload'");

// Update tab rendering content
const endContent = `
        ) : null}
        
        {activeTab === 'upload' && (
          <UploadMarks onUploadSuccess={() => setActiveTab('processing')} />
        )}
        
        {activeTab === 'processing' && (
          <ProcessingJobsList />
        )}
        
        {activeTab === 'pending' && (
          <PendingVerificationList />
        )}

        {activeTab === 'processed' && (
          <ProcessedDataList />
        )}
      </div>
    </div>
  );
`;

code = code.replace(/        \) : null\}[\s\S]*?<\/div>\s*<\/div>\s*\);\s*\}/m, endContent + "\n}");

// Remove the old {activeTab === 'upload' ? (<UploadMarks />) : activeTab === 'results' ?
code = code.replace("{activeTab === 'upload' ? (\n          <UploadMarks />\n        ) : activeTab === 'results' ?", "{activeTab === 'results' ?");

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
