const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Gender:</span>
                    <span className="text-white text-sm">{student.gender || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Address:</span>
                    <span className="text-white text-sm text-right max-w-[200px] leading-relaxed">{student.address || 'Not Provided'}</span>
                  </div>`;

const replacement = `                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Gender:</span>
                    <span className="text-white text-sm">{student.gender || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Blood Group:</span>
                    <span className="text-white text-sm">{student.bloodGroup || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Admission Date:</span>
                    <span className="text-white text-sm">{student.admissionDate || 'Not Provided'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-3">
                    <span className="text-gray-500 text-sm">Address:</span>
                    <span className="text-white text-sm text-right max-w-[200px] leading-relaxed">
                      {student.address ? \`\${student.address}\${student.city ? ', ' + student.city : ''}\${student.state ? ', ' + student.state : ''}\${student.pinCode ? ' - ' + student.pinCode : ''}\` : 'Not Provided'}
                    </span>
                  </div>`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched UI to show blood group, admission date, and full address");
