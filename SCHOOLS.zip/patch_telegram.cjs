const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

content = content.replace(
  "Total Fee: Rs. ${fees.totalFee}\\nPaid: Rs. ${fees.paidAmount}\\nBalance: Rs. ${fees.balance}\\n\\nPlease find the attached detailed ledger.",
  "Status: ${fees.status}\\nTotal Fee: Rs. ${fees.totalFee}\\nPaid: Rs. ${fees.paidAmount}\\nBalance: Rs. ${fees.balance}\\n\\nPlease find the attached detailed ledger."
);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
