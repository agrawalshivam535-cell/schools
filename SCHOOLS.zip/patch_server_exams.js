import fs from 'fs';

let serverCode = fs.readFileSync('server.ts', 'utf-8');

// Change Subjects array in api/exams/save-grid
serverCode = serverCode.replace(
  'const subjects = ["Maths", "Science", "History"];',
  'const subjects = ["Maths", "Science", "Hindi"];'
);

fs.writeFileSync('server.ts', serverCode);
console.log("server.ts patched");
