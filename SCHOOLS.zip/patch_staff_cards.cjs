const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Staff.tsx', 'utf-8');

const tableStart = `<div className="bg-[#151515] border border-white/5 rounded-2xl overflow-x-auto shadow-xl">
        <table className="w-full text-left min-w-[900px]">`;

const tableEnd = `          </tbody>
        </table>
      </div>`;

const startIndex = content.indexOf(tableStart);
if (startIndex !== -1) {
  const endIndex = content.indexOf(tableEnd, startIndex) + tableEnd.length;
  
  const cardCode = `      <div>
        {filteredStaff.length === 0 ? (
          <div className="p-12 text-center text-gray-500 bg-[#151515] border border-white/5 rounded-2xl">No staff found matching your criteria.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredStaff.map((staff) => (
              <div 
                key={staff.id} 
                className="bg-[#151515] border border-white/5 hover:border-white/10 rounded-2xl overflow-hidden transition-all group flex flex-col"
              >
                <div 
                  className="p-5 cursor-pointer relative"
                  onClick={() => setViewDetails(staff)}
                >
                  <div className="flex flex-col items-center mt-2">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                      <span className="text-2xl font-bold text-indigo-300">
                        {staff.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                      </span>
                    </div>
                    <h3 className="font-bold text-white text-lg text-center group-hover:text-indigo-400 transition-colors">{staff.name}</h3>
                    <div className="text-sm text-indigo-300 mt-1 font-medium">{staff.role}</div>
                    <div className="text-xs text-gray-400 mt-2 font-medium bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                      ID: {staff.id}
                    </div>
                  </div>
                </div>

                <div 
                  className="px-5 pb-5 cursor-pointer flex-1 flex flex-col justify-center"
                  onClick={() => setViewDetails(staff)}
                >
                  <div className="space-y-3 mt-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Dept</span>
                      <span className="text-gray-300 bg-white/5 px-2 py-0.5 rounded border border-white/10">{staff.department}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">Status</span>
                      <span className={\`px-2 py-0.5 rounded text-xs font-bold border \${
                        staff.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                        staff.status === 'On Leave' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 
                        'bg-red-500/10 text-red-400 border-red-500/20'
                      }\`}>
                        {staff.status}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-white/5">
                      <div className="flex items-center gap-2 text-xs text-gray-400 mb-1.5">
                        <Phone size={12} className="text-gray-500" /> {staff.phone}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <Mail size={12} className="text-gray-500" /> {staff.email}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t border-white/5 bg-black/20 p-3 flex justify-between items-center mt-auto">
                  <button 
                    onClick={() => setViewDetails(staff)} 
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                  >
                    <Eye size={14} /> View
                  </button>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => setEditForm(staff)} 
                      className="p-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded transition-colors"
                      title="Edit Staff"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(staff.id)} 
                      className="p-1.5 text-red-400 hover:bg-red-500/10 rounded transition-colors"
                      title="Delete Staff"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>`;
      
  const newContent = content.substring(0, startIndex) + cardCode + content.substring(endIndex);
  fs.writeFileSync('src/components/tabs/Staff.tsx', newContent);
  console.log("Patched Staff.tsx (Table to Cards)");
} else {
  console.log("Could not find table code block in Staff.tsx");
}
