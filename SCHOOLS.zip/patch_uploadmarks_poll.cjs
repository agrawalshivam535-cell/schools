const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf8');

const target1 = `      let data;
      try {
        data = await response.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }

      setIsUploading(false);
      if (onUploadSuccess) onUploadSuccess();
      return; // Skip the rest of the function since it's background processed`;

const replace1 = `      let data;
      try {
        data = await response.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }

      if (data.job && data.job.id) {
        // Poll for completion
        let isDone = false;
        let jobResult = null;
        while (!isDone) {
          await new Promise(r => setTimeout(r, 2000));
          const jobsRes = await fetch('/api/exams/jobs');
          if (jobsRes.ok) {
             const jobs = await jobsRes.json();
             const job = jobs.find((j: any) => j.id === data.job.id);
             if (job && (job.status === 'pending_verification' || job.status === 'error')) {
                isDone = true;
                jobResult = job;
             }
          }
        }
        
        if (jobResult && jobResult.status === 'pending_verification' && jobResult.records) {
           data = jobResult.records;
        } else {
           setIsUploading(false);
           alert("Failed to process document: " + (jobResult?.errorMsg || "Unknown error"));
           return;
        }
      }

      setIsUploading(false);
      // Remove the return statement so it processes the data below!
      `;

if (code.includes(target1)) {
    code = code.replace(target1, replace1);
    fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
    console.log("Successfully patched UploadMarks.tsx for polling");
} else {
    console.log("Could not find target block in UploadMarks.tsx");
}
