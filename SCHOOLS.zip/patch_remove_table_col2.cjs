const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const targetHeader = `<th className="p-5 text-xs font-bold tracking-wider text-gray-500 uppercase">Month</th>`;
content = content.replace(targetHeader, ``);

fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched to remove table column header");
