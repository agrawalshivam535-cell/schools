const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const handleDeleteFunction = `  const handleDeleteSelected = async () => {
    if (selectedIds.length === 0) return;
    if (!confirm(\`Are you sure you want to delete \${selectedIds.length} student(s)? This action cannot be undone.\`)) return;
    
    try {
      const res = await fetch('/api/students/bulk', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentIds: selectedIds })
      });
      if (res.ok) {
        setSelectedIds([]);
        fetchStudents();
      } else {
        alert('Failed to delete students');
      }
    } catch (e) {
      console.error(e);
      alert('Error deleting students');
    }
  };

`;

code = code.replace('  const renderListView = () => (', handleDeleteFunction + '  const renderListView = () => (');

const deleteBtn = `          {selectedIds.length > 0 && (
            <>
              <button 
                onClick={handleDeleteSelected}
                className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                <Trash2 size={18} /> Delete All Students
              </button>
              <button 
                onClick={() => setPromoteModal({ isOpen: true, toClass: classes[2] || classes[1], actionType: 'reassign' })}
                className="bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 px-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                Reassign Selected ({selectedIds.length})
              </button>
            </>
          )}`;

code = code.replace(/\{selectedIds\.length > 0 && \([\s\S]*?Reassign Selected[\s\S]*?<\/button>\s*\)\}/m, deleteBtn);

fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched Students.tsx with bulk delete button");
