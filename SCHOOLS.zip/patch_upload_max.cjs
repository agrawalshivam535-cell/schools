const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const uploadMarkRx = /const handleMarkChange = \(id: string, value: string\) => \{\s*if \(!analyzedData\) return;\s*\/\/ Only allow empty or numbers\s*if \(value !== '' && !\/^\d\+\$\/\.test\(value\)\) return;\s*if \(value !== ''\) \{\s*const num = parseInt\(value, 10\);\s*let maxMarks = 100;\s*const lowerExam = uploadExam\.toLowerCase\(\);\s*if \(lowerExam\.includes\('unit test'\)\) maxMarks = 25;\s*else if \(lowerExam\.includes\('mid-year'\) \|\| lowerExam\.includes\('mid term'\)\) maxMarks = 50;\s*else if \(lowerExam\.includes\('annual'\) \|\| lowerExam\.includes\('final'\)\) maxMarks = 100;\s*if \(num > maxMarks\) \{\s*alert\(\`Maximum marks for \$\{uploadExam\} is \$\{maxMarks\}\`\);\s*return;\s*\}\s*\}\s*const newData = \[\.\.\.analyzedData\];\s*const index = newData\.findIndex\(r => r\.id === id\);\s*if \(index !== -1\) \{\s*newData\[index\]\.marksObtained = value;\s*setAnalyzedData\(newData\);\s*\}\s*\};/m;

const newUploadMark = `const handleMarkChange = (id: string, value: string) => {
    if (!analyzedData) return;
    
    // Only allow empty or numbers
    if (value !== '' && !/^\\d+$/.test(value)) return;
    
    if (value !== '') {
      const num = parseInt(value, 10);
      const currentMax = parseInt(String(uploadMaxMarks), 10) || 100;
      
      if (num > currentMax) {
        alert(\`Maximum marks allowed is \${currentMax}\`);
        return;
      }
    }

    const newData = [...analyzedData];
    const index = newData.findIndex(r => r.id === id);
    if (index !== -1) {
      newData[index].marksObtained = value;
      setAnalyzedData(newData);
    }
  };`;

content = content.replace(uploadMarkRx, newUploadMark);
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log('Patched UploadMarks.tsx');
