const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Timetable.tsx', 'utf-8');

const oldHandleSave = `  const handleSaveAssign = () => {
    if (assignSlot && subject && teacher) {
      const key = assignSlot.period + '_' + assignSlot.day;
      const currentClassData = timetableData[className] || {};
      
      setTimetableData({
        ...timetableData,
        [className]: {
          ...currentClassData,
          [key]: { subject, teacher }
        }
      });
      setAssignSlot(null);
    }
  };`;

const newHandleSave = `  const handleSaveAssign = () => {
    if (assignSlot && subject && teacher) {
      const daySuffix = '_' + assignSlot.day;
      const slotKey = assignSlot.period + daySuffix;
      
      // 1. Validation: Same teacher, same subject on the same day for this class
      const currentClassData = timetableData[className] || {};
      const isAlreadyTeachingSameSubjectToday = Object.entries(currentClassData).some(([key, val]) => {
        return key.endsWith(daySuffix) && key !== slotKey && val.teacher === teacher && val.subject === subject;
      });

      if (isAlreadyTeachingSameSubjectToday) {
        alert(\`\${teacher} is already assigned to teach \${subject} on \${assignSlot.day} for this class.\`);
        return;
      }

      // 2. Validation: Is the teacher already busy in another class during the EXACT same period and day?
      for (const [clsName, clsData] of Object.entries(timetableData)) {
        if (clsName !== className && clsData[slotKey] && clsData[slotKey].teacher === teacher) {
          alert(\`\${teacher} is already taking a class in \${clsName} during Period \${assignSlot.period} on \${assignSlot.day}.\`);
          return;
        }
      }
      
      // 3. User's exact prompt literal interpretation: "If Mr. Ram is a teacher and is assigned Hindi on Monday, he should not be assigned Hindi on any other period on Monday"
      // Wait, let me also check if this literal interpretation (across ALL classes) is safer to include, just in case they meant it literally.
      // Actually, if a teacher is a Hindi teacher, they MUST teach Hindi in multiple periods on Monday to different classes. 
      // If I block it across all classes, the teacher will only be able to teach 1 period per day! So I will only block for the current class.
      
      setTimetableData({
        ...timetableData,
        [className]: {
          ...currentClassData,
          [slotKey]: { subject, teacher }
        }
      });
      setAssignSlot(null);
    }
  };`;

content = content.replace(oldHandleSave, newHandleSave);
fs.writeFileSync('src/components/tabs/Timetable.tsx', content);
console.log("Patched Timetable.tsx");
