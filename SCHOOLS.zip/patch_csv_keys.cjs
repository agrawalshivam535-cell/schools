const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf8');

const target = `            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['parentname', 'fathername', 'guardianname'].includes(cleanKey)) normalized.parentName = row[key];
            else if (['contactnumber', 'phone', 'mobile'].includes(cleanKey)) normalized.contactNumber = String(row[key]);
            else normalized[key] = row[key]; // keep other fields`;

const replacement = `            if (['name', 'studentname'].includes(cleanKey)) normalized.name = row[key];
            else if (['rollnumber', 'rollno', 'roll'].includes(cleanKey)) normalized.rollNumber = String(row[key]);
            else if (['class', 'classname'].includes(cleanKey)) normalized.className = String(row[key]);
            else if (['section'].includes(cleanKey)) normalized.section = String(row[key]).toUpperCase();
            else if (['status'].includes(cleanKey)) normalized.status = row[key];
            else if (['fathername', 'parentname', 'guardianname', 'father'].includes(cleanKey)) normalized.fatherName = row[key];
            else if (['mothername', 'mother'].includes(cleanKey)) normalized.motherName = row[key];
            else if (['parentphone', 'phone', 'mobile', 'contactnumber'].includes(cleanKey)) normalized.parentPhone = String(row[key]);
            else if (['email', 'emailaddress'].includes(cleanKey)) normalized.email = row[key];
            else if (['gender', 'sex'].includes(cleanKey)) normalized.gender = row[key];
            else if (['dob', 'dateofbirth', 'birthdate'].includes(cleanKey)) normalized.dob = row[key];
            else if (['address', 'homeaddress'].includes(cleanKey)) normalized.address = row[key];
            else if (['telegramchatid', 'telegramid', 'telegram'].includes(cleanKey)) normalized.telegramChatId = String(row[key]);
            else normalized[key] = row[key]; // keep other fields`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/tabs/Students.tsx', code);
console.log("Patched CSV normalization to correctly map all student fields");
