const fs = require('fs');
const code = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');
const lines = code.split('\n');
lines.splice(185, 6,
  "    if (action === 'preview') {",
  "      setPdfPreview({ url: doc.output('bloburl'), filename: `Result_${student.rollNumber}_${exam.examName.replace(/\\s+/g, '_')}.pdf` });",
  "    } else {",
  "      doc.save(`Result_${student.rollNumber}_${exam.examName.replace(/\\s+/g, '_')}.pdf`);",
  "    }"
);
fs.writeFileSync('src/components/tabs/Students.tsx', lines.join('\n'));
