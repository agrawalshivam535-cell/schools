const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

const oldBlock = `{exam.isBlank ? (
                            <div className="px-4 py-1.5 bg-gray-500/10 text-gray-400 rounded-full text-xs font-bold border border-gray-500/20 whitespace-nowrap text-center">
                              Not Recorded
                            </div>
                          ) : (
                            <>
                              <div className="px-4 py-1.5 bg-indigo-500/10 text-indigo-300 rounded-full text-xs font-bold border border-indigo-500/20 whitespace-nowrap text-center">
                                Total: {exam.obtained} / {exam.total} | Grade: {grade} ({percentage}%)
                              </div>
                              <button 
                                onClick={() => downloadMarksResult(exam, selectedStudent.student, 'preview')}
                                className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                                title="Preview PDF"
                              >
                                <Eye size={18} />
                              </button>
                              <button 
                                onClick={() => sendTelegramResult(exam, selectedStudent.student)}
                                disabled={sendingTelegramId === exam.examName}
                                className="p-1.5 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors disabled:opacity-50"
                                title="Send via Telegram"
                              >
                                {sendingTelegramId === exam.examName ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                              </button>
                              <button 
                                onClick={() => downloadMarksResult(exam, selectedStudent.student)}
                                className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                                title="Download PDF"
                              >
                                <Download size={18} />
                              </button>
                            </>
                          )}`;

const newBlock = `<>
                            {exam.isBlank ? (
                              <div className="px-4 py-1.5 bg-gray-500/10 text-gray-400 rounded-full text-xs font-bold border border-gray-500/20 whitespace-nowrap text-center mr-2">
                                Not Recorded
                              </div>
                            ) : (
                              <div className="px-4 py-1.5 bg-indigo-500/10 text-indigo-300 rounded-full text-xs font-bold border border-indigo-500/20 whitespace-nowrap text-center mr-2">
                                Total: {exam.obtained} / {exam.total} | Grade: {grade} ({percentage}%)
                              </div>
                            )}
                            <button 
                              onClick={() => downloadMarksResult(exam, selectedStudent.student, 'preview')}
                              className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                              title="Preview PDF"
                            >
                              <Eye size={18} />
                            </button>
                            <button 
                              onClick={() => sendTelegramResult(exam, selectedStudent.student)}
                              disabled={sendingTelegramId === exam.examName}
                              className="p-1.5 hover:bg-[#229ED9]/20 text-[#229ED9] rounded-lg transition-colors disabled:opacity-50"
                              title="Send via Telegram"
                            >
                              {sendingTelegramId === exam.examName ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                            </button>
                            <button 
                              onClick={() => downloadMarksResult(exam, selectedStudent.student)}
                              className="p-1.5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors"
                              title="Download PDF"
                            >
                              <Download size={18} />
                            </button>
                          </>`;

content = content.replace(oldBlock, newBlock);
fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched icons for all exams");
