import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

// The problematic useEffect:
//   useEffect(() => {
//     if (classes.length > 0) {
//       if (!promoteForm.fromClass) {

// The state definitions:
//   const [promoteForm, setPromoteForm] = useState({ fromClass: '', toClass: '' });
//   const [selectiveToClass, setSelectiveToClass] = useState('');

// Let's grab all state definitions and move them to the top of ClassSetup
code = code.replace(
  "  const [classes, setClasses] = useState<ClassData[]>([]);",
  `  const [classes, setClasses] = useState<ClassData[]>([]);
  const [promoteForm, setPromoteForm] = useState({ fromClass: '', toClass: '' });
  const [selectiveToClass, setSelectiveToClass] = useState('');
  const [search, setSearch] = useState('');
  const [promoteModal, setPromoteModal] = useState(false);
  const [isPromoting, setIsPromoting] = useState(false);
  const [selectedClassForPromotion, setSelectedClassForPromotion] = useState<ClassData | null>(null);
  const [classStudents, setClassStudents] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [selectivePromoteModal, setSelectivePromoteModal] = useState(false);
`
);

// Remove the old definitions
code = code.replace(/  const \[search, setSearch\] = useState\(''\);\n/g, '');
code = code.replace(/  const \[promoteModal, setPromoteModal\] = useState\(false\);\n/g, '');
code = code.replace(/  const \[promoteForm, setPromoteForm\] = useState\(\{ fromClass: '', toClass: '' \}\);\n/g, '');
code = code.replace(/  const \[isPromoting, setIsPromoting\] = useState\(false\);\n/g, '');
code = code.replace(/  const \[selectedClassForPromotion, setSelectedClassForPromotion\] = useState<ClassData \| null>\(null\);\n/g, '');
code = code.replace(/  const \[classStudents, setClassStudents\] = useState<any\[\]>\(\[\]\);\n/g, '');
code = code.replace(/  const \[selectedIds, setSelectedIds\] = useState<string\[\]>\(\[\]\);\n/g, '');
code = code.replace(/  const \[selectivePromoteModal, setSelectivePromoteModal\] = useState\(false\);\n/g, '');
code = code.replace(/  const \[selectiveToClass, setSelectiveToClass\] = useState\(''\);\n/g, '');

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', code);
console.log('patched classsetup init');
