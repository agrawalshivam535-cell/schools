const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const target1 = `      } catch (err) {
        console.error("Background processing error:", err);
        // Could set a failed status here, but for now just log it
      }`;

const replace1 = `      } catch (err: any) {
        console.error("Background processing error:", err);
        const idx = examJobs.findIndex(j => j.id === job.id);
        if (idx !== -1) {
          examJobs[idx].status = 'error';
          examJobs[idx].errorMsg = err.message || "Failed to process document";
          saveDb('examJobs.json', examJobs);
        }
      }`;

if (code.includes(target1)) {
    code = code.replace(target1, replace1);
    fs.writeFileSync('server.ts', code);
    console.log("Patched server.ts error handling");
} else {
    console.log("Could not find target1");
}
