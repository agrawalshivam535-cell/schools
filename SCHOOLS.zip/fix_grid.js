import fs from 'fs';

let code = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');

const oldGridHeaders = `<th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>`;

const newGridHeaders = `<th className="p-4 whitespace-nowrap w-24">Roll No</th>
                        <th className="p-4 whitespace-nowrap min-w-[150px]">Student Name</th>
                        <th className="p-4 whitespace-nowrap">Maths</th>
                        <th className="p-4 whitespace-nowrap">Science</th>
                        <th className="p-4 whitespace-nowrap">Hindi</th>
                        <th className="p-4 whitespace-nowrap text-emerald-400 font-bold">Total</th>`;

code = code.replace(oldGridHeaders, newGridHeaders);

const oldRow = `<td className="p-4 text-gray-300 text-sm">
                            {student.name}
                          </td>`;

const newRow = `<td className="p-4 text-gray-400 text-sm font-medium">
                            {student.rollNumber || '-'}
                          </td>
                          <td className="p-4 text-gray-300 text-sm">
                            {student.name}
                          </td>`;

code = code.replace(oldRow, newRow);

fs.writeFileSync('src/components/tabs/Exams.tsx', code);
console.log('Fixed grid headers and rows');
