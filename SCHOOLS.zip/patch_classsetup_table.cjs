const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/ClassSetup.tsx', 'utf-8');

// The row onClick was opening the students view. We need to remove it from the row and only have it on the students cell.
content = content.replace(
  /onClick=\{\(\) => fetchClassStudents\(cls\)\}\n                  className="border-b border-white\/5 hover:bg-white\/5 transition-colors cursor-pointer"/g,
  `className="border-b border-white/5 hover:bg-white/5 transition-colors"`
);

// Update class teacher column
content = content.replace(
  `<td className="p-5 text-gray-400">{cls.classTeacher}</td>`,
  `<td className="p-5 text-gray-400">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setClassForm(cls); }}
                      className="hover:text-indigo-400 transition-colors font-medium border-b border-dashed border-gray-600 hover:border-indigo-400 pb-0.5"
                    >
                      {cls.classTeacher || 'Unassigned'}
                    </button>
                  </td>`
);

// Update total students column
content = content.replace(
  `<td className="p-5 text-gray-400">{cls.totalStudents}</td>`,
  `<td className="p-5 text-gray-400">
                    <button 
                      onClick={(e) => { e.stopPropagation(); fetchClassStudents(cls); }}
                      className="hover:text-emerald-400 transition-colors font-medium border-b border-dashed border-gray-600 hover:border-emerald-400 pb-0.5 flex items-center gap-1.5"
                    >
                      <Users size={14} />
                      {cls.totalStudents}
                    </button>
                  </td>`
);

// Update the action buttons column (Remove the Students button since it's now on the total students column)
content = content.replace(
  `<button 
                        onClick={(e) => { e.stopPropagation(); fetchClassStudents(cls); }}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-indigo-400 hover:bg-indigo-500/10 rounded-lg text-sm font-bold transition-colors"
                      >
                        <Users size={16} /> Students
                      </button>`,
  ``
);

fs.writeFileSync('src/components/tabs/ClassSetup.tsx', content);
console.log("Patched ClassSetup.tsx");
