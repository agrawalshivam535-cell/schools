import fs from 'fs';

let exams = fs.readFileSync('src/components/tabs/Exams.tsx', 'utf-8');
exams = exams.replace(/Mid Term 2024/g, 'Mid-year');
exams = exams.replace(/Final Exam/g, 'Annual');
fs.writeFileSync('src/components/tabs/Exams.tsx', exams);

let upload = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');
upload = upload.replace(/Mid Term 2024/g, 'Mid-year');
upload = upload.replace(/Final Exam/g, 'Annual');
fs.writeFileSync('src/components/tabs/UploadMarks.tsx', upload);

let server = fs.readFileSync('server.ts', 'utf-8');
server = server.replace(/Mid Term 2024/g, 'Mid-year');
server = server.replace(/Final Exam/g, 'Annual');
fs.writeFileSync('server.ts', server);

console.log('Exam names updated');
