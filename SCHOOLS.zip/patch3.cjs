const fs = require('fs');
let code = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf8');

const targetStr = `setIsUploading(false);
      if (onUploadSuccess) onUploadSuccess();
      return; // Skip the rest of the function since it's background processed`;

const idx = code.indexOf(targetStr);
if (idx !== -1) {
    code = code.replace(targetStr, `
      if (data.job && data.job.id) {
        let isDone = false;
        let jobResult = null;
        while (!isDone) {
          await new Promise(r => setTimeout(r, 2000));
          const jobsRes = await fetch('/api/exams/jobs');
          if (jobsRes.ok) {
             const jobs = await jobsRes.json();
             const job = jobs.find((j: any) => j.id === data.job.id);
             if (job && (job.status === 'pending_verification' || job.status === 'error')) {
                isDone = true;
                jobResult = job;
             }
          }
        }
        
        if (jobResult && jobResult.status === 'pending_verification' && jobResult.records) {
           data = jobResult.records;
        } else {
           setIsUploading(false);
           alert("Failed to process document: " + (jobResult?.errorMsg || "Unknown error"));
           return;
        }
      }

      setIsUploading(false);
      // We removed the early return so it proceeds to populate the UI
`);
    
    // Also we need to fix the `if (response.ok && Array.isArray(data)) {` line
    code = code.replace('if (response.ok && Array.isArray(data)) {', 'if (Array.isArray(data)) {');
    
    fs.writeFileSync('src/components/tabs/UploadMarks.tsx', code);
    console.log("Patched successfully");
} else {
    console.log("Target string not found in UploadMarks.tsx");
}
