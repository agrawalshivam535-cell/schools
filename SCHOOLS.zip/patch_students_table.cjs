const fs = require('fs');
let content = fs.readFileSync('src/components/tabs/Students.tsx', 'utf-8');

// Add Unlink to imports
content = content.replace(
  "import { Search, Plus, Eye, Trash2, Edit, Calendar, IndianRupee, Activity, FileText, Download, X, Send, Loader2 } from 'lucide-react';",
  "import { Search, Plus, Eye, Trash2, Edit, Calendar, IndianRupee, Activity, FileText, Download, X, Send, Loader2, Unlink } from 'lucide-react';"
);

// Update table cell
const oldCell = `<td className="p-5 text-gray-400">{student.telegramChatId || '-'}</td>`;
const newCell = `<td className="p-5 text-gray-400">
                      <div className="flex items-center gap-2">
                        <span>{student.telegramChatId || '-'}</span>
                        {student.telegramChatId && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); disconnectTelegram(student.id); }}
                            className="p-1.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 hover:text-red-300 rounded transition-colors"
                            title="Disconnect Telegram"
                          >
                            <Unlink size={14} />
                          </button>
                        )}
                      </div>
                    </td>`;

content = content.replace(oldCell, newCell);
fs.writeFileSync('src/components/tabs/Students.tsx', content);
console.log("Patched table with quick disconnect button");
