import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

code = code.replace("  const sections = ['A', 'B'];", `
  const sections = Array.from(new Set(classes.map(c => c.split(' - ')[1] || 'A'))).sort();
`);

fs.writeFileSync('src/components/tabs/Fees.tsx', code);
console.log('Patched fees sections');
