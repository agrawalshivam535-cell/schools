const fs = require('fs');

let content = fs.readFileSync('src/components/tabs/UploadMarks.tsx', 'utf-8');

const handleSaveTarget = `            records: analyzedData`;
const handleSaveReplacement = `            records: analyzedData.filter(r => r.marksObtained !== '')`;

// Replace all instances of `records: analyzedData` in `handleSave`
content = content.split('records: analyzedData').join('records: analyzedData.filter(r => r.marksObtained !== "")');

fs.writeFileSync('src/components/tabs/UploadMarks.tsx', content);
console.log("Patched handleSave");
