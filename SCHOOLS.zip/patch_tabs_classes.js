import fs from 'fs';

const files = [
  'src/components/tabs/Timetable.tsx',
  'src/components/tabs/Attendance.tsx',
  'src/components/tabs/Fees.tsx',
  'src/components/tabs/Students.tsx',
];

files.forEach(file => {
  let code = fs.readFileSync(file, 'utf-8');
  
  if (file === 'src/components/tabs/Students.tsx') {
     code = code.replace(
       /const classes = \["All Classes",[\s\S]*?\];/,
       `const { classes: fetchedClasses } = useClasses();\n  const classes = ['All Classes', ...fetchedClasses];`
     );
  } else {
     code = code.replace(
       /const classes = \["Class 1 - A",[\s\S]*?\];/,
       `const { classes } = useClasses();`
     );
  }
  
  if (!code.includes('useClasses')) {
     console.log('Failed to patch', file);
  } else {
     // add import at top
     if (!code.includes("import { useClasses }")) {
        code = `import { useClasses } from '../../hooks/useClasses';\n` + code;
     }
  }

  // Fees.tsx state initialization issue if classes is dynamic
  // e.g. useState(classes[0])
  if (file === 'src/components/tabs/Fees.tsx') {
     code = code.replace(
       /const \[selectedClass, setSelectedClass\] = useState\(classes\[0\]\);/,
       `const [selectedClass, setSelectedClass] = useState('');
       
  import { useEffect as UseEffectAlias } from 'react';
  UseEffectAlias(() => {
    if (classes.length > 0 && !selectedClass) {
      setSelectedClass(classes[0]);
    }
  }, [classes, selectedClass]);
       `
     );
  }
  
  if (file === 'src/components/tabs/Timetable.tsx' || file === 'src/components/tabs/Attendance.tsx') {
     code = code.replace(
       /const \[selectedClass, setSelectedClass\] = useState\(classes\[0\]\);/,
       `const [selectedClass, setSelectedClass] = useState('');
       
  import { useEffect as UseEffectAlias2 } from 'react';
  UseEffectAlias2(() => {
    if (classes.length > 0 && !selectedClass) {
      setSelectedClass(classes[0]);
    }
  }, [classes, selectedClass]);
       `
     );
  }

  fs.writeFileSync(file, code);
  console.log('Patched', file);
});
