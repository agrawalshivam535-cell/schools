import fs from 'fs';
let code = fs.readFileSync('src/components/tabs/Fees.tsx', 'utf-8');

const effectCode = `
  useEffect(() => {
    if (classes.length > 0) {
      const firstClass = classes[0];
      const cls = firstClass.split(' - ')[0];
      const sec = firstClass.split(' - ')[1] || 'A';
      if (!structClass) setStructClass(cls);
      if (!structSection) setStructSection(sec);
      if (!collClass) setCollClass(cls);
      if (!collSection) setCollSection(sec);
    }
  }, [classes, structClass, structSection, collClass, collSection]);
`;

code = code.replace("  // --- STRUCTURE LOGIC ---", effectCode + "\n  // --- STRUCTURE LOGIC ---");
fs.writeFileSync('src/components/tabs/Fees.tsx', code);
console.log('Patched fees defaults');
